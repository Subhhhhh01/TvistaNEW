# Custom Agent Instructions

- **Design Constraint**: Do not change the visual design, style, layout, color scheme, typography, or UI structure of any page in the application unless explicitly requested by the user. Maintain the existing design integrity at all times.
