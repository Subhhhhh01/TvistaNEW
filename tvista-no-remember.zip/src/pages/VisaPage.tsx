import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import VisaModal, { VisaCountry } from '../components/VisaModal';
import { motion } from 'motion/react';
import { Check, Info, Clock, IndianRupee, Globe2, CheckCircle, ArrowRight, Search, X, Send } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';

export default function VisaPage() {
  const { visaCountries, addEnquiry } = useData();
  const [submitted, setSubmitted] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<VisaCountry | null>(null);

  const [consultForm, setConsultForm] = useState({
    name: '',
    email: '',
    phone: '',
    country: '',
    nationality: 'Indian Passport',
    notes: ''
  });

  const handleConsultSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addEnquiry({
      type: 'visa',
      name: consultForm.name,
      email: consultForm.email,
      phone: consultForm.phone,
      titleOrSubject: `General Visa Assistance: ${consultForm.country || 'Not specified'}`,
      details: `Nationality: ${consultForm.nationality}. Remarks: ${consultForm.notes || 'None'}`
    });
    setSubmitted(true);
  };

  const filteredCountries = visaCountries.filter(country => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      country.name.toLowerCase().includes(q) ||
      country.code.toLowerCase().includes(q) ||
      country.details.toLowerCase().includes(q) ||
      country.types.some(t => t.toLowerCase().includes(q))
    );
  });

  return (
    <div className="relative min-h-screen">
      {/* Global Background Image */}
      <div className="fixed inset-0 z-[-1] overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1507652313519-d4e9174996dd?q=80&w=2070&auto=format&fit=crop" 
          alt="Neutral Minimalist Background" 
          className="w-full h-full object-cover scale-105 blur-md brightness-95"
        />
        <div className="absolute inset-0 bg-black/10" />
      </div>

      <Navbar theme="light" />
      
      {/* Hero Section */}
      <div className="relative w-full h-[55vh] min-h-[400px] flex items-center justify-center px-6">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center max-w-3xl mt-16"
        >
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif text-[#1C1917] mb-6 leading-tight">
            Global Visa <span className="italic text-[#57534E]">Solutions</span>
          </h1>
          <p className="text-lg md:text-xl text-[#44403C] font-light max-w-2xl mx-auto">
             Seamless travel documentation. Explore visa requirements for your next destination and let our experts handle the complexity.
          </p>
        </motion.div>
      </div>

      <div className="relative z-20">
        {/* Visa Grid Section */}
        <div className="max-w-7xl mx-auto px-6 pt-12 pb-24">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-12 border-b border-[#E7E5E4] pb-6">
            <div className="flex items-center gap-3">
              <Globe2 className="w-6 h-6 text-[#57534E]" />
              <h2 className="text-2xl font-serif text-[#1C1917] tracking-wide">Destination Requirements</h2>
            </div>

            {/* Search Bar */}
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-[#78716C] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search country or visa type..."
                className="w-full bg-white/80 border border-[#E7E5E4] rounded-full pl-11 pr-9 py-2.5 text-sm text-[#1C1917] placeholder:text-[#A8A29E] focus:outline-none focus:border-[#78716C] focus:bg-white transition-all shadow-sm"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#78716C] hover:text-[#1C1917] p-1 rounded-full hover:bg-neutral-200/50 transition-colors"
                  aria-label="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {filteredCountries.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCountries.map((country, idx) => (
                <motion.div 
                  key={country.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-50px" }}
                  transition={{ delay: (idx % 3) * 0.1, duration: 0.6 }}
                  className="group relative bg-white/60 backdrop-blur-md border border-[#E7E5E4] rounded-xl p-6 transition-all duration-300 hover:border-[#D6D3D1] hover:-translate-y-1 shadow-sm hover:shadow-md"
                >
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-serif text-[#1C1917] transition-colors">{country.name}</h3>
                    <img 
                      src={`https://flagcdn.com/w80/${country.code.toLowerCase()}.png`} 
                      alt={`${country.name} flag`} 
                      className="w-8 h-6 rounded-sm object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                    />
                  </div>

                  <div className="space-y-5">
                    <div>
                      <h4 className="text-[10px] font-semibold text-neutral-500 uppercase tracking-widest mb-3">Permitted Types</h4>
                      <div className="flex flex-wrap gap-2">
                        {country.types.map(type => (
                          <span key={type} className="px-2.5 py-1 rounded bg-[#F5F5F4] text-[#44403C] text-xs font-medium border border-[#E7E5E4]">
                            {type}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 py-4 border-y border-[#E7E5E4]">
                      <div>
                        <div className="flex items-center gap-1.5 text-[#78716C] text-xs mb-1">
                          <Clock className="w-3.5 h-3.5" /> Processing
                        </div>
                        <div className="text-[#1C1917] text-sm font-medium">{country.processingTime}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 text-[#78716C] text-xs mb-1">
                          <IndianRupee className="w-3.5 h-3.5" /> Est. Fee
                        </div>
                        <div className="text-[#1C1917] text-sm font-medium">{country.fee}</div>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5 text-[#57534E] text-sm pt-1">
                      <Info className="w-4 h-4 text-[#78716C] flex-shrink-0 mt-0.5" />
                      <p className="leading-relaxed text-xs whitespace-pre-line">{country.details}</p>
                    </div>

                    {/* Enquire Now Button */}
                    <button
                      onClick={() => setSelectedCountry(country)}
                      className="w-full mt-2 bg-[#1C1917] hover:bg-[#292524] text-white font-medium rounded-lg py-2.5 px-4 text-xs tracking-wider uppercase transition-colors shadow-sm flex items-center justify-center gap-2 group/btn"
                    >
                      <span>Enquire Now</span>
                      <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white/50 backdrop-blur-md border border-[#E7E5E4] rounded-2xl p-8 shadow-sm">
              <Globe2 className="w-10 h-10 text-[#A8A29E] mx-auto mb-3" />
              <h3 className="text-xl font-serif text-[#1C1917] mb-2">No Country Found</h3>
              <p className="text-[#78716C] text-sm max-w-md mx-auto mb-6">
                No visa requirements matching "{searchQuery}". Try searching for another country name or visa type.
              </p>
              <button
                onClick={() => setSearchQuery('')}
                className="bg-[#1C1917] text-white font-medium px-6 py-2.5 rounded-full text-xs uppercase tracking-wider hover:bg-[#292524] transition-colors shadow-sm"
              >
                Clear Search
              </button>
            </div>
          )}
        </div>

        {/* Assistance Form Section */}
        <div className="border-t border-[#E7E5E4] bg-white/40 backdrop-blur-sm px-6 py-24">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-start">
            <div className="pt-8">
              <h2 className="text-3xl md:text-5xl font-serif text-[#1C1917] mb-6">Expert Advisory</h2>
              <p className="text-[#57534E] mb-12 leading-relaxed text-lg">
                Navigating visa protocols requires precision. Our dedicated team of specialists simplifies the process, providing step-by-step guidance to ensure your application is accurate and submitted on time.
              </p>
              
              <div className="space-y-8">
                {[
                  { title: 'Document Verification', desc: 'Thorough review of all your supporting documents.' },
                  { title: 'Application Assistance', desc: 'Expert help with complex online and paper forms.' },
                  { title: 'Interview Preparation', desc: 'Mock interviews and tailored tips for embassy appointments.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-5">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-white flex items-center justify-center border border-[#E7E5E4] shadow-sm">
                      <span className="text-[#1C1917] font-serif text-sm">{i + 1}</span>
                    </div>
                    <div>
                      <h4 className="text-[#1C1917] font-medium mb-1.5">{item.title}</h4>
                      <p className="text-[#57534E] text-sm">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white/75 backdrop-blur-xl border border-white/80 rounded-[2rem] p-8 lg:p-12 shadow-2xl">
              <h3 className="text-2xl font-serif text-[#1C1917] mb-2">Request Consultation</h3>
              <p className="text-[#78716C] mb-8 text-sm">Provide your details and our visa specialists will contact you.</p>
                
              {submitted ? (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-8 rounded-2xl flex flex-col items-center text-center">
                  <CheckCircle className="w-12 h-12 text-emerald-600 mb-3" />
                  <h4 className="text-2xl font-serif font-bold mb-2">Consultation Request Received!</h4>
                  <p className="text-sm text-emerald-700">Thank you for reaching out. Our visa consultation expert will contact you shortly to review your requirements.</p>
                </div>
              ) : (
                <form className="space-y-6" onSubmit={handleConsultSubmit}>
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-2">Full Name *</label>
                    <input 
                      required 
                      type="text" 
                      value={consultForm.name}
                      onChange={e => setConsultForm({ ...consultForm, name: e.target.value })}
                      className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors placeholder:text-[#A8A29E] shadow-sm" 
                      placeholder="e.g. Rahul Sharma" 
                    />
                  </div>
                  
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-2">Email Address *</label>
                    <input 
                      required 
                      type="email" 
                      value={consultForm.email}
                      onChange={e => setConsultForm({ ...consultForm, email: e.target.value })}
                      className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors placeholder:text-[#A8A29E] shadow-sm" 
                      placeholder="rahul@example.com" 
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-1.5 font-semibold">Phone Number *</label>
                      <input 
                        required 
                        type="tel" 
                        value={consultForm.phone}
                        onChange={e => setConsultForm({ ...consultForm, phone: e.target.value })}
                        className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors placeholder:text-[#A8A29E] shadow-sm" 
                        placeholder="+91 98307 12357" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-1.5 font-semibold">Destination Country *</label>
                      <select 
                        required 
                        value={consultForm.country}
                        onChange={e => setConsultForm({ ...consultForm, country: e.target.value })}
                        className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors shadow-sm"
                      >
                        <option value="">Select a country...</option>
                        {visaCountries.map(c => (
                          <option key={c.name} value={c.name}>{c.name}</option>
                        ))}
                        <option value="Other">Other Country</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-1.5 font-semibold">Passport Nationality</label>
                    <input 
                      type="text" 
                      value={consultForm.nationality}
                      onChange={e => setConsultForm({ ...consultForm, nationality: e.target.value })}
                      className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors placeholder:text-[#A8A29E] shadow-sm" 
                      placeholder="e.g. Indian Passport" 
                    />
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#78716C] mb-1.5 font-semibold">Additional Remarks</label>
                    <textarea 
                      rows={2} 
                      value={consultForm.notes}
                      onChange={e => setConsultForm({ ...consultForm, notes: e.target.value })}
                      className="w-full bg-white border border-[#E7E5E4] rounded-lg px-4 py-3 text-[#1C1917] text-sm focus:outline-none focus:border-[#A8A29E] transition-colors placeholder:text-[#A8A29E] shadow-sm resize-none" 
                      placeholder="Notes, number of applicants, or urgent requests..." 
                    />
                  </div>

                  <button className="w-full bg-[#1C1917] text-white font-medium rounded-lg py-3.5 mt-2 hover:bg-[#292524] transition-colors text-sm tracking-wide shadow-md flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" />
                    <span>Submit Visa Consultation Request</span>
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Interlinking CTA */}
          <div className="mt-20 bg-stone-900 text-white rounded-3xl p-8 lg:p-12 text-center relative overflow-hidden shadow-2xl">
            <div className="relative z-10 max-w-2xl mx-auto space-y-4">
              <h3 className="text-3xl font-serif">Looking for Complete Travel Packages?</h3>
              <p className="text-stone-300 text-sm leading-relaxed">
                Combine your visa assistance with luxury accommodations, private transfers, and curated guided tours.
              </p>
              <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/packages"
                  className="bg-white text-stone-900 font-bold px-8 py-3.5 rounded-full text-xs uppercase tracking-wider hover:bg-stone-200 transition-colors inline-flex items-center gap-2 group"
                >
                  <span>Explore Tour Packages</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/destinations"
                  className="bg-stone-800 border border-stone-700 text-white font-bold px-8 py-3.5 rounded-full text-xs uppercase tracking-wider hover:bg-stone-700 transition-colors"
                >
                  Browse Destinations
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Visa Detail / Inquiry Modal */}
      <VisaModal 
        country={selectedCountry}
        onClose={() => setSelectedCountry(null)}
      />

      <Footer theme="light" />
    </div>
  );
}
