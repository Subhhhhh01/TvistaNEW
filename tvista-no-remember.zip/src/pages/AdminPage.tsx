import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package as PackageIcon, Plane, Globe2, Plus, Edit2, Trash2, 
  Search, RefreshCw, Download, Upload, Check, X, Shield, ArrowLeft, 
  Star, ExternalLink, Filter, Eye, EyeOff, Tag, MapPin, IndianRupee, Clock, Layers, Sparkles, FileText, Calendar, AlertCircle,
  Image as ImageIcon, Link as LinkIcon, RotateCcw, Lock, Key, LogOut
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useData, AirlinePartner, VisaCountryItem } from '../context/DataContext';
import { Package, CATEGORIES } from '../data/packagesData';
import { FlightDeal } from '../components/FlightModal';
import { generateSampleFlightCsv, isFlightExpired, getTodayDateString } from '../utils/csvParser';
import TvistaLogo from '../components/TvistaLogo';
import DescriptionEditor from '../components/DescriptionEditor';
import { stripMarkdown } from '../components/RichDescription';
import AdminDestinations from '../components/admin/AdminDestinations';
import AdminHome from '../components/admin/AdminHome';
import AdminPromos from '../components/admin/AdminPromos';
import AdminNews from '../components/admin/AdminNews';
import AdminGallery from '../components/admin/AdminGallery';
import ImageUploadField from '../components/admin/ImageUploadField';

export default function AdminPage() {
  const { 
    packages, addPackage, updatePackage, deletePackage,
    flightDeals, activeFlightDeals, addFlightDeal, updateFlightDeal, deleteFlightDeal, uploadFlightCsvData, purgeExpiredFlights,
    airlinePartners, addAirlinePartner, updateAirlinePartner, deleteAirlinePartner,
    visaCountries, addVisaCountry, updateVisaCountry, deleteVisaCountry,
    destinations, promos, newsArticles, galleryItems,
    resetToDefaults, exportDataJson, importDataJson
  } = useData();

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return !!sessionStorage.getItem('tvista_admin_token') || 
             !!localStorage.getItem('tvista_admin_token');
    } catch {
      return false;
    }
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [changePasswordModal, setChangePasswordModal] = useState(false);

  const [csvAppendMode, setCsvAppendMode] = useState<boolean>(false);

  const [activeTab, setActiveTab] = useState<'packages' | 'flights' | 'airlines' | 'visas' | 'destinations' | 'home' | 'promos' | 'news' | 'gallery'>('packages');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Modal States
  const [packageModal, setPackageModal] = useState<{ open: boolean; mode: 'add' | 'edit'; data?: Package }>({ open: false, mode: 'add' });
  const [flightModal, setFlightModal] = useState<{ open: boolean; mode: 'add' | 'edit'; data?: FlightDeal }>({ open: false, mode: 'add' });
  const [airlineModal, setAirlineModal] = useState<{ open: boolean; mode: 'add' | 'edit'; data?: AirlinePartner }>({ open: false, mode: 'add' });
  const [visaModal, setVisaModal] = useState<{ open: boolean; mode: 'add' | 'edit'; data?: VisaCountryItem }>({ open: false, mode: 'add' });
  const [deleteConfirm, setDeleteConfirm] = useState<{
    open: boolean;
    type: 'package' | 'flight' | 'airline' | 'visa' | 'reset';
    id?: string | number;
    title?: string;
  }>({ open: false, type: 'package' });

  const showStatus = (text: string, type: 'success' | 'error' = 'success') => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: passwordInput })
      });
      const result = await res.json();
      if (result.success && result.token) {
        {
          sessionStorage.setItem('tvista_admin_token', result.token);
          sessionStorage.setItem('tvista_admin_session', 'active');
        }
        setIsAuthenticated(true);
        setPasswordInput('');
        showStatus('Welcome back, Administrator!');
      } else {
        setLoginError(result.message || 'Incorrect password. Please verify and try again.');
      }
    } catch (err) {
      setLoginError('Server error during authentication. Please try again.');
    }
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('tvista_admin_session');
      localStorage.removeItem('tvista_admin_token');
      sessionStorage.removeItem('tvista_admin_session');
      sessionStorage.removeItem('tvista_admin_token');
    } catch {
      // ignore
    }
    setIsAuthenticated(false);
    setPasswordInput('');
    showStatus('Signed out from Admin Portal.');
  };

  // Import JSON Handler
  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content && importDataJson(content)) {
        showStatus('Data successfully imported and synchronized!');
      } else {
        showStatus('Invalid JSON format. Import failed.', 'error');
      }
    };
    reader.readAsText(file);
  };

  // Export JSON Handler
  const handleExportJson = () => {
    const json = exportDataJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tvista_holidays_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    showStatus('Data backup downloaded successfully!');
  };

  // CSV Flight Deals Upload Handler
  const handleCsvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const csvText = event.target?.result as string;
      if (!csvText) {
        showStatus('Empty CSV file provided.', 'error');
        return;
      }

      const res = uploadFlightCsvData(csvText, csvAppendMode);
      if (res.count === 0) {
        showStatus('Failed to parse flight CSV. Ensure valid header format.', 'error');
      } else {
        showStatus(`Successfully imported ${res.count} flights (${res.activeCount} active, ${res.expiredCount} past dated removed/hidden).`);
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  // Download Sample Flights CSV
  const handleDownloadSampleCsv = () => {
    const csvContent = generateSampleFlightCsv();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `flight_deals_sample_template.csv`;
    a.click();
    showStatus('Sample Flight CSV template downloaded!');
  };

  // Purge Past Dated Flights
  const handlePurgeExpired = () => {
    const count = purgeExpiredFlights();
    if (count > 0) {
      showStatus(`Purged ${count} past dated flights from database.`);
    } else {
      showStatus('No expired flights found to purge.');
    }
  };

  // If not logged in, render white-themed login screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#FAFAF8] text-stone-900 font-sans flex flex-col justify-between items-center p-4 sm:p-6 relative selection:bg-amber-100 selection:text-stone-900">
        {/* Subtle decorative background light elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-amber-100/30 via-stone-100/20 to-transparent pointer-events-none rounded-b-full blur-3xl -z-10" />

        {/* Top bar with back to site */}
        <header className="w-full max-w-5xl flex items-center justify-between py-2">
          <Link 
            to="/" 
            className="flex items-center gap-2 text-xs uppercase tracking-wider text-stone-600 hover:text-stone-950 font-semibold transition-all bg-white hover:bg-stone-50 px-4 py-2 rounded-xl border border-stone-200 shadow-xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Website</span>
          </Link>
          <div className="flex items-center gap-1.5 text-xs text-stone-400 font-medium">
            <Shield className="w-3.5 h-3.5 text-amber-500" />
            <span>Admin Gateway</span>
          </div>
        </header>

        {/* White-Themed Login Card */}
        <main className="w-full max-w-md my-auto py-8">
          <motion.div 
            initial={{ opacity: 0, y: 15, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
            className="bg-white border border-stone-200/90 rounded-3xl shadow-xl shadow-stone-200/60 p-8 sm:p-10 relative overflow-hidden"
          >
            {/* Top gold accent line */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-400 via-[#8B0000] to-amber-500" />

            {/* Brand Logo & Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-stone-50 border border-stone-200/90 shadow-sm mb-4">
                <TvistaLogo className="h-12 w-auto object-contain" />
              </div>

              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="text-[11px] font-bold tracking-[0.2em] uppercase text-amber-700 bg-amber-50 border border-amber-200/80 px-2.5 py-0.5 rounded-full">Administrator Portal</span>
              </div>
              <h2 className="text-xl font-serif font-bold text-stone-900">Administrative Sign In</h2>
              <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto leading-relaxed">
                Enter your administrative password to manage packages, flight schedules, airlines, and visas.
              </p>
            </div>

            {/* Error Message */}
            <AnimatePresence>
              {loginError && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{loginError}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 mb-1.5">
                  Admin Passcode
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-400">
                    <Key className="w-4 h-4" />
                  </div>
                  <input 
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={passwordInput}
                    onChange={e => {
                      setPasswordInput(e.target.value);
                      if (loginError) setLoginError('');
                    }}
                    placeholder="Enter admin password..."
                    className="w-full bg-stone-50/80 border border-stone-200 rounded-xl pl-10 pr-10 py-3 text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:bg-white focus:border-stone-400 focus:ring-2 focus:ring-stone-200 transition-all font-mono"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-stone-400 hover:text-stone-700 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end text-xs pt-1">
                <span className="text-[11px] text-stone-400">Tvista Security</span>
              </div>

              <button
                type="submit"
                className="w-full bg-stone-900 hover:bg-stone-800 active:scale-[0.99] text-white font-bold text-xs uppercase tracking-wider py-3.5 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
              >
                <Shield className="w-4 h-4 text-amber-400" />
                <span>Unlock Control Panel</span>
              </button>
            </form>

            {/* Default Password Hint Pill */}
            <div className="mt-8 pt-6 border-t border-stone-100 text-center">
              <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-stone-50 border border-stone-200/80 text-[11px] text-stone-500 font-medium">
                <Shield className="w-3 h-3 text-amber-500" />
                <span>Secure Administrative Access Portal</span>
              </div>
            </div>
          </motion.div>
        </main>

        {/* Footer info */}
        <footer className="w-full max-w-5xl py-3 text-center text-xs text-stone-400">
          © {new Date().getFullYear()} Tvista Holidays. Authorized Administrator Access Only.
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F8F6] text-stone-900 font-sans selection:bg-amber-100 selection:text-stone-900">
      {/* Admin White Header Bar */}
      <header className="sticky top-0 z-40 bg-white/95 text-stone-900 border-b border-stone-200/90 shadow-xs backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link 
              to="/" 
              className="flex items-center gap-2 text-xs uppercase tracking-wider text-stone-600 hover:text-stone-900 font-semibold transition-colors bg-stone-50 hover:bg-stone-100 px-3 py-1.5 rounded-lg border border-stone-200"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Site</span>
            </Link>
            <div className="h-4 w-px bg-stone-200 hidden sm:block" />
            <div className="flex items-center gap-2">
              <div className="p-1 rounded-md bg-amber-50 border border-amber-200">
                <Shield className="w-4 h-4 text-amber-600" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-serif font-bold tracking-tight text-stone-900 leading-tight">Tvista Control Panel</h1>
                <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Authenticated
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-2.5">
            <button
              onClick={() => setChangePasswordModal(true)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-stone-950 text-xs font-semibold border border-stone-200 transition-colors"
              title="Change admin login passcode"
            >
              <Key className="w-3.5 h-3.5 text-amber-600" />
              <span>Passcode</span>
            </button>

            <button
              onClick={handleExportJson}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-stone-950 text-xs font-semibold border border-stone-200 transition-colors"
              title="Download full JSON backup"
            >
              <Download className="w-3.5 h-3.5 text-amber-600" />
              <span>Export</span>
            </button>
            
            <label className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-stone-950 text-xs font-semibold border border-stone-200 cursor-pointer transition-colors">
              <Upload className="w-3.5 h-3.5 text-amber-600" />
              <span>Import</span>
              <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
            </label>

            <button
              onClick={() => setDeleteConfirm({ open: true, type: 'reset', title: 'All data to factory defaults' })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 text-xs font-semibold transition-colors"
              title="Reset data to initial defaults"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Reset</span>
            </button>

            <div className="h-5 w-px bg-stone-200 mx-1" />

            <button
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition-all border border-stone-200"
              title="Sign out from administrative panel"
            >
              <LogOut className="w-3.5 h-3.5 text-stone-600" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Notification Banner */}
      <AnimatePresence>
        {statusMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-18 right-4 z-50 px-5 py-3 rounded-xl shadow-xl border text-xs font-semibold flex items-center gap-2 ${
              statusMessage.type === 'error' 
                ? 'bg-white text-rose-700 border-rose-300 shadow-rose-100' 
                : 'bg-white text-emerald-700 border-emerald-300 shadow-emerald-100'
            }`}
          >
            <Check className="w-4 h-4" />
            <span>{statusMessage.text}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 bg-white p-2 rounded-2xl border border-stone-200 shadow-xs">
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => { setActiveTab('packages'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'packages'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <PackageIcon className="w-4 h-4" />
              <span>Tour Packages ({packages.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('flights'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'flights'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Plane className="w-4 h-4" />
              <span>Flight Deals ({flightDeals.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('airlines'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'airlines'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Globe2 className="w-4 h-4" />
              <span>Airlines ({airlinePartners.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('visas'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'visas'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Visas ({visaCountries.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('destinations'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'destinations'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>Destinations ({destinations.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('home'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'home'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Home Page</span>
            </button>

            <button
              onClick={() => { setActiveTab('promos'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'promos'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span>Promos ({promos.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('news'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'news'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>News ({newsArticles.length})</span>
            </button>

            <button
              onClick={() => { setActiveTab('gallery'); setSearchQuery(''); }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeTab === 'gallery'
                  ? 'bg-stone-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <ImageIcon className="w-4 h-4" />
              <span>Gallery ({galleryItems.length})</span>
            </button>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder={`Search ${activeTab}...`}
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl pl-9 pr-4 py-2 text-xs text-stone-800 placeholder:text-stone-400 focus:outline-none focus:bg-white focus:border-stone-400 transition-all"
            />
          </div>
        </div>

        {/* TAB 1: TOUR PACKAGES */}
        {activeTab === 'packages' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Holiday Packages</h2>
                <p className="text-xs text-stone-500">Manage tour titles, prices, durations, locations, tags, and gallery images.</p>
              </div>
              <button
                onClick={() => setPackageModal({ open: true, mode: 'add' })}
                className="bg-stone-900 hover:bg-stone-800 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-2 uppercase tracking-wider"
              >
                <Plus className="w-4 h-4" />
                <span>Add Tour Package</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {packages
                .filter(p => !searchQuery || (p.title || '').toLowerCase().includes(searchQuery.toLowerCase()) || (p.location || '').toLowerCase().includes(searchQuery.toLowerCase()))
                .map(pkg => (
                  <div key={pkg.id} className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between group">
                    <div>
                      <div className="relative h-44 overflow-hidden bg-stone-100">
                        <img 
                          src={pkg.image || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop'} 
                          alt={pkg.title || 'Tour Package'} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-3 left-3 bg-stone-900/80 text-white text-[10px] font-bold px-2.5 py-1 rounded-full backdrop-blur-md">
                          {pkg.duration || 'Flexible'}
                        </div>
                        <div className="absolute top-3 right-3 bg-amber-400 text-stone-950 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                          <Star className="w-3 h-3 fill-stone-950" />
                          <span>{pkg.rating || 4.8}</span>
                        </div>
                      </div>

                      <div className="p-5">
                        <div className="flex items-center gap-1 text-stone-500 text-xs font-semibold uppercase tracking-wider mb-1">
                          <MapPin className="w-3.5 h-3.5 text-stone-400" />
                          <span>{pkg.location || 'Worldwide'}</span>
                        </div>
                        <h3 className="text-lg font-serif font-bold text-stone-900 line-clamp-1 mb-2">{pkg.title || 'Untitled Package'}</h3>
                        <p className="text-xs text-stone-600 line-clamp-2 mb-4 leading-relaxed">{stripMarkdown(pkg.description) || 'Custom tailored itinerary by Tvista Holidays.'}</p>
                        
                        <div className="flex flex-wrap gap-1.5 mb-4">
                          {(Array.isArray(pkg.tags) ? pkg.tags : ['Featured']).map(t => (
                            <span key={t} className="text-[10px] font-medium bg-stone-100 text-stone-600 px-2 py-0.5 rounded-md border border-stone-200">
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="px-5 py-3 bg-stone-50 border-t border-stone-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-stone-400 block uppercase font-bold">Package Fare</span>
                        <span className="text-base font-bold text-stone-900">{pkg.price || 'On Request'}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setPackageModal({ open: true, mode: 'edit', data: pkg })}
                          className="p-2 rounded-lg bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 hover:text-stone-950 transition-colors"
                          title="Edit package"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setDeleteConfirm({ open: true, type: 'package', id: pkg.id, title: pkg.title })}
                          className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-600 hover:bg-rose-100 transition-colors"
                          title="Delete package"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* TAB 2: FLIGHT DEALS */}
        {activeTab === 'flights' && (
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Flight Routes & CSV Deals Upload</h2>
                <p className="text-xs text-stone-500">Upload bulk flight CSVs, manage routes, and auto-expire past-dated flights.</p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={handleDownloadSampleCsv}
                  className="bg-stone-200 hover:bg-stone-300 text-stone-800 font-medium text-xs px-3.5 py-2.5 rounded-xl transition-all flex items-center gap-2 uppercase tracking-wider"
                  title="Download CSV sample file template"
                >
                  <Download className="w-4 h-4 text-stone-700" />
                  <span>Sample CSV</span>
                </button>
                <button
                  onClick={() => setFlightModal({ open: true, mode: 'add' })}
                  className="bg-stone-900 hover:bg-stone-800 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-2 uppercase tracking-wider"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Flight Deal</span>
                </button>
              </div>
            </div>

            {/* CSV Import Banner */}
            <div className="bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 text-white p-6 rounded-2xl shadow-lg mb-8 border border-stone-800">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-2 max-w-xl">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-amber-400/20 text-amber-300 border border-amber-400/30">
                      <FileText className="w-4 h-4" />
                    </span>
                    <h3 className="font-serif font-bold text-lg text-white">Bulk CSV Flight Management</h3>
                  </div>
                  <p className="text-xs text-stone-300 leading-relaxed">
                    Upload a CSV containing flight details (Airline, From, To, Price, FlightDate, etc.). Flights dated before today (<strong className="text-amber-300">{getTodayDateString()}</strong>) are automatically filtered out from the main website search and flight page.
                  </p>
                  
                  <div className="flex items-center gap-4 text-xs pt-1">
                    <span className="flex items-center gap-1.5 font-semibold text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800">
                      <Check className="w-3.5 h-3.5" />
                      {activeFlightDeals.length} Active Flights
                    </span>
                    <span className="flex items-center gap-1.5 font-semibold text-amber-300 bg-amber-950/60 px-3 py-1 rounded-full border border-amber-800">
                      <Clock className="w-3.5 h-3.5" />
                      {flightDeals.length - activeFlightDeals.length} Past/Expired Flights
                    </span>
                  </div>
                </div>

                <div className="bg-stone-800/90 p-4 rounded-xl border border-stone-700 space-y-3 shrink-0 lg:w-80">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-stone-300 font-medium">Upload Mode:</span>
                    <button
                      onClick={() => setCsvAppendMode(!csvAppendMode)}
                      className="text-[11px] font-bold text-amber-300 underline hover:text-amber-200"
                    >
                      {csvAppendMode ? 'Mode: Append to Existing' : 'Mode: Replace All Flights'}
                    </button>
                  </div>

                  <label className="w-full bg-amber-400 hover:bg-amber-300 text-stone-950 font-bold text-xs py-3 px-4 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider">
                    <Upload className="w-4 h-4" />
                    <span>Upload CSV File</span>
                    <input 
                      type="file" 
                      accept=".csv,text/csv" 
                      onChange={handleCsvUpload} 
                      className="hidden" 
                    />
                  </label>

                  {flightDeals.length - activeFlightDeals.length > 0 && (
                    <button
                      onClick={handlePurgeExpired}
                      className="w-full bg-rose-950/80 hover:bg-rose-900 border border-rose-800/80 text-rose-200 text-xs font-semibold py-2 rounded-lg transition-all flex items-center justify-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Purge {flightDeals.length - activeFlightDeals.length} Past Flights</span>
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {flightDeals
                .filter(f => !searchQuery || f.airline.toLowerCase().includes(searchQuery.toLowerCase()) || f.from.toLowerCase().includes(searchQuery.toLowerCase()) || f.to.toLowerCase().includes(searchQuery.toLowerCase()))
                .map(deal => {
                  const expired = isFlightExpired(deal.flightDate);
                  return (
                    <div key={deal.id} className={`bg-white border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between ${expired ? 'border-amber-200 bg-amber-50/20' : 'border-stone-200'}`}>
                      <div>
                        <div className="relative h-40 bg-stone-100 overflow-hidden">
                          <img src={deal.image} alt={deal.airline} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
                          
                          <div className="absolute top-3 left-3 flex items-center gap-2">
                            {expired ? (
                              <span className="text-[10px] font-bold uppercase tracking-wider bg-rose-500 text-white px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                <span>Past Dated (Hidden)</span>
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500 text-white px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1">
                                <Check className="w-3 h-3" />
                                <span>Active (Live)</span>
                              </span>
                            )}
                          </div>

                          {deal.flightDate && (
                            <div className="absolute top-3 right-3 bg-stone-900/90 text-amber-300 text-[10px] font-bold px-2.5 py-1 rounded-full backdrop-blur-md border border-stone-700 flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>{deal.flightDate}</span>
                            </div>
                          )}

                          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white">
                            <div className="flex items-center gap-2">
                              {deal.airlineLogo && (
                                <img src={deal.airlineLogo} alt="" className="w-6 h-6 rounded bg-white p-0.5 object-contain" />
                              )}
                              <span className="font-bold text-sm">{deal.airline}</span>
                            </div>
                            <span className="text-xs bg-white/20 backdrop-blur-md px-2 py-0.5 rounded-full font-semibold">{deal.type}</span>
                          </div>
                        </div>

                        <div className="p-5">
                          <div className="flex items-center justify-between mb-3 bg-stone-50 p-3 rounded-xl border border-stone-100">
                            <div>
                              <span className="text-[10px] text-stone-400 font-bold block">{deal.fromCode}</span>
                              <span className="font-bold text-stone-900 text-sm">{deal.from}</span>
                            </div>
                            <div className="flex flex-col items-center">
                              <span className="text-[10px] text-stone-500">{deal.duration}</span>
                              <Plane className="w-4 h-4 text-stone-400 rotate-90 my-0.5" />
                            </div>
                            <div className="text-right">
                              <span className="text-[10px] text-stone-400 font-bold block">{deal.toCode}</span>
                              <span className="font-bold text-stone-900 text-sm">{deal.to}</span>
                            </div>
                          </div>

                          {deal.popularTags && (
                            <div className="flex flex-wrap gap-1">
                              {deal.popularTags.map(t => (
                                <span key={t} className="text-[10px] bg-amber-50 text-amber-800 border border-amber-200/80 px-2 py-0.5 rounded-md font-medium">
                                  {t}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="px-5 py-3 bg-stone-50 border-t border-stone-100 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-stone-400 block uppercase font-bold">Fares From</span>
                          <span className="text-base font-bold text-stone-900">{deal.price}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setFlightModal({ open: true, mode: 'edit', data: deal })}
                            className="p-2 rounded-lg bg-white border border-stone-200 text-stone-700 hover:bg-stone-100 transition-colors"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirm({ open: true, type: 'flight', id: deal.id, title: `${deal.from} to ${deal.to}` })}
                            className="p-2 rounded-lg bg-rose-50 border border-rose-200 text-rose-600 hover:bg-rose-100 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* TAB 3: AIRLINE PARTNERS */}
        {activeTab === 'airlines' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Airline Partners</h2>
                <p className="text-xs text-stone-500">Manage airline logos, ratings, global regions, and partner privileges.</p>
              </div>
              <button
                onClick={() => setAirlineModal({ open: true, mode: 'add' })}
                className="bg-stone-900 hover:bg-stone-800 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-2 uppercase tracking-wider"
              >
                <Plus className="w-4 h-4" />
                <span>Add Airline Partner</span>
              </button>
            </div>

            <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-sm">
              <table className="w-full text-left text-xs text-stone-700">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-4">Airline</th>
                    <th className="p-4">Country & Region</th>
                    <th className="p-4">Rating</th>
                    <th className="p-4">Partner Perks</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {airlinePartners
                    .filter(a => !searchQuery || a.name.toLowerCase().includes(searchQuery.toLowerCase()) || a.country.toLowerCase().includes(searchQuery.toLowerCase()))
                    .map(partner => (
                      <tr key={partner.name} className="hover:bg-stone-50/80 transition-colors">
                        <td className="p-4 font-bold text-stone-900 flex items-center gap-3">
                          <img 
                            src={partner.logo} 
                            alt="" 
                            className="w-7 h-7 rounded border border-stone-200 object-contain p-0.5 bg-white shrink-0" 
                          />
                          <div>
                            <span className="block">{partner.name}</span>
                            <span className="text-[10px] text-stone-400 font-normal">{partner.domain}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="font-semibold block text-stone-800">{partner.country}</span>
                          <span className="text-[10px] text-stone-500">{partner.region}</span>
                        </td>
                        <td className="p-4 font-bold text-amber-600">{partner.rating}</td>
                        <td className="p-4 text-stone-600 max-w-xs truncate">{partner.perks}</td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              onClick={() => setAirlineModal({ open: true, mode: 'edit', data: partner })}
                              className="p-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirm({ open: true, type: 'airline', title: partner.name })}
                              className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 4: VISA COUNTRIES */}
        {activeTab === 'visas' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Visa Services Directory</h2>
                <p className="text-xs text-stone-500">Manage country visa specifications, processing lead times, fee structures, and categories.</p>
              </div>
              <button
                onClick={() => setVisaModal({ open: true, mode: 'add' })}
                className="bg-stone-900 hover:bg-stone-800 text-white font-medium text-xs px-4 py-2.5 rounded-xl transition-all shadow-md flex items-center gap-2 uppercase tracking-wider"
              >
                <Plus className="w-4 h-4" />
                <span>Add Visa Country</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {visaCountries
                .filter(v => !searchQuery || v.name.toLowerCase().includes(searchQuery.toLowerCase()) || v.code.toLowerCase().includes(searchQuery.toLowerCase()))
                .map(visa => (
                  <div key={visa.code} className="bg-white border border-stone-200 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <img 
                            src={`https://flagcdn.com/w80/${visa.code.toLowerCase()}.png`} 
                            alt={visa.name} 
                            className="w-8 h-5 rounded object-cover shadow-xs border border-stone-200"
                          />
                          <div>
                            <h3 className="font-serif font-bold text-stone-900 text-lg leading-none">{visa.name}</h3>
                            <span className="text-[10px] uppercase tracking-widest text-stone-400 font-bold">{visa.code}</span>
                          </div>
                        </div>
                        <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200/80">
                          {visa.fee}
                        </span>
                      </div>

                      <div className="text-xs text-stone-600 mb-4 bg-stone-50 p-3 rounded-xl border border-stone-100 space-y-1">
                        <div className="flex items-center gap-1.5 text-stone-700 font-semibold">
                          <Clock className="w-3.5 h-3.5 text-stone-400" />
                          <span>Processing Time: {visa.processingTime}</span>
                        </div>
                        <p className="text-stone-500 line-clamp-2 pt-1">{visa.details}</p>
                      </div>

                      <div className="flex flex-wrap gap-1 mb-4">
                        {visa.types.map(t => (
                          <span key={t} className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded font-medium border border-stone-200">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-2">
                      <button
                        onClick={() => setVisaModal({ open: true, mode: 'edit', data: visa })}
                        className="px-3 py-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => setDeleteConfirm({ open: true, type: 'visa', id: visa.code, title: visa.name })}
                        className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* TAB 5: DESTINATIONS */}
        {activeTab === 'destinations' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Destination Management</h2>
                <p className="text-xs text-stone-500">Curate luxury holiday destinations, countries, duration, pricing, and visual showcase cards.</p>
              </div>
            </div>
            <AdminDestinations />
          </div>
        )}

        {/* TAB 6: HOME PAGE */}
        {activeTab === 'home' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Homepage Content & Visuals</h2>
                <p className="text-xs text-stone-500">Control hero banner marketing copy, 3D rotating carousel cards, and featured seasonal journeys.</p>
              </div>
            </div>
            <AdminHome />
          </div>
        )}

        {/* TAB 7: PROMOS */}
        {activeTab === 'promos' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Promos & Discount Offers</h2>
                <p className="text-xs text-stone-500">Manage coupon codes, percentage/flat discounts, validity periods, and minimum booking requirements.</p>
              </div>
            </div>
            <AdminPromos />
          </div>
        )}

        {/* TAB 8: NEWS & PRESS */}
        {activeTab === 'news' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">News & Editorial Press</h2>
                <p className="text-xs text-stone-500">Publish luxury travel features, aviation updates, destination insights, and editorial stories.</p>
              </div>
            </div>
            <AdminNews />
          </div>
        )}

        {/* TAB 9: GALLERY */}
        {activeTab === 'gallery' && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-serif font-bold text-stone-900">Showcase Photo Gallery</h2>
                <p className="text-xs text-stone-500">Curate high-resolution destination photography, captions, and visual travel inspiration.</p>
              </div>
            </div>
            <AdminGallery />
          </div>
        )}
      </div>

      {/* PACKAGE EDIT / ADD MODAL */}
      {packageModal.open && (
        <PackageEditModal 
          mode={packageModal.mode} 
          initialData={packageModal.data} 
          onClose={() => setPackageModal({ open: false, mode: 'add' })}
          onSave={(pkgData) => {
            if (packageModal.mode === 'add') {
              addPackage(pkgData);
              showStatus('New tour package created!');
            } else if (packageModal.data) {
              updatePackage(packageModal.data.id, pkgData);
              showStatus('Tour package updated!');
            }
            setPackageModal({ open: false, mode: 'add' });
          }}
        />
      )}

      {/* FLIGHT EDIT / ADD MODAL */}
      {flightModal.open && (
        <FlightEditModal 
          mode={flightModal.mode}
          initialData={flightModal.data}
          onClose={() => setFlightModal({ open: false, mode: 'add' })}
          onSave={(dealData) => {
            if (flightModal.mode === 'add') {
              addFlightDeal(dealData);
              showStatus('Flight deal added!');
            } else if (flightModal.data) {
              updateFlightDeal(flightModal.data.id, dealData);
              showStatus('Flight deal updated!');
            }
            setFlightModal({ open: false, mode: 'add' });
          }}
        />
      )}

      {/* AIRLINE EDIT / ADD MODAL */}
      {airlineModal.open && (
        <AirlineEditModal 
          mode={airlineModal.mode}
          initialData={airlineModal.data}
          onClose={() => setAirlineModal({ open: false, mode: 'add' })}
          onSave={(partnerData) => {
            if (airlineModal.mode === 'add') {
              addAirlinePartner(partnerData);
              showStatus('Airline partner added!');
            } else if (airlineModal.data) {
              updateAirlinePartner(airlineModal.data.name, partnerData);
              showStatus('Airline partner updated!');
            }
            setAirlineModal({ open: false, mode: 'add' });
          }}
        />
      )}

      {/* VISA EDIT / ADD MODAL */}
      {visaModal.open && (
        <VisaEditModal 
          mode={visaModal.mode}
          initialData={visaModal.data}
          onClose={() => setVisaModal({ open: false, mode: 'add' })}
          onSave={(visaData) => {
            if (visaModal.mode === 'add') {
              addVisaCountry(visaData);
              showStatus('Visa country added!');
            } else if (visaModal.data) {
              updateVisaCountry(visaModal.data.code, visaData);
              showStatus('Visa country updated!');
            }
            setVisaModal({ open: false, mode: 'add' });
          }}
        />
      )}

      {/* DELETE / RESET CONFIRMATION MODAL */}
      {deleteConfirm.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4 text-stone-900"
          >
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2 bg-rose-100 rounded-xl">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="font-serif font-bold text-lg">Confirm Action</h3>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Are you sure you want to {deleteConfirm.type === 'reset' ? 'reset' : 'delete'} <strong className="text-stone-900">{deleteConfirm.title || 'this item'}</strong>? This action will immediately update your system database.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm({ open: false, type: 'package' })}
                className="px-4 py-2.5 rounded-xl bg-stone-100 text-stone-700 text-xs font-semibold hover:bg-stone-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (deleteConfirm.type === 'package' && deleteConfirm.id !== undefined) {
                    deletePackage(deleteConfirm.id);
                    showStatus('Package deleted successfully');
                  } else if (deleteConfirm.type === 'flight' && deleteConfirm.id !== undefined) {
                    deleteFlightDeal(String(deleteConfirm.id));
                    showStatus('Flight deal deleted');
                  } else if (deleteConfirm.type === 'airline' && deleteConfirm.title) {
                    deleteAirlinePartner(deleteConfirm.title);
                    showStatus('Airline partner deleted');
                  } else if (deleteConfirm.type === 'visa' && deleteConfirm.id) {
                    deleteVisaCountry(String(deleteConfirm.id));
                    showStatus('Visa country deleted');
                  } else if (deleteConfirm.type === 'reset') {
                    resetToDefaults();
                    showStatus('System reset to original factory data');
                  }
                  setDeleteConfirm({ open: false, type: 'package' });
                }}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-md"
              >
                Confirm
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* CHANGE PASSCODE MODAL */}
      {changePasswordModal && (
        <ChangePasswordModal 
          onClose={() => setChangePasswordModal(false)}
        />
      )}
    </div>
  );
}

// ---------------- SUB-COMPONENTS: EDIT MODALS ----------------

function ChangePasswordModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white border border-stone-200 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative text-stone-900"
      >
        <button 
          onClick={onClose} 
          className="absolute top-5 right-5 p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-700">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-serif font-bold text-stone-900">Passcode Note</h3>
            <p className="text-xs text-stone-500">Security & Credentials Management</p>
          </div>
        </div>

        <p className="text-xs text-stone-600 leading-relaxed">
          The administrative passcode is managed securely on the server via environment variables in your hosting settings (defined in <code className="bg-stone-100 px-1 py-0.5 rounded text-rose-600 font-mono">ADMIN_PASSWORD</code>). 
        </p>
        <p className="text-xs text-stone-600 leading-relaxed mt-2">
          To update your passcode, modify your deployment configuration's environment variables.
        </p>

        <div className="pt-4 flex justify-end">
          <button 
            type="button" 
            onClick={onClose} 
            className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold text-xs"
          >
            Close
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function PackageEditModal({ mode, initialData, onClose, onSave }: {
  mode: 'add' | 'edit';
  initialData?: Package;
  onClose: () => void;
  onSave: (pkg: Omit<Package, 'id'>) => void;
}) {
  const [formData, setFormData] = useState<Omit<Package, 'id'>>({
    title: initialData?.title || '',
    location: initialData?.location || '',
    image: initialData?.image || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop',
    duration: initialData?.duration || '5 Days / 4 Nights',
    price: initialData?.price || '₹45,000',
    rating: initialData?.rating || 4.8,
    reviews: initialData?.reviews || 120,
    tags: initialData?.tags || ['Luxury', 'International'],
    description: initialData?.description || ''
  });

  const [tagsInput, setTagsInput] = useState((formData.tags || []).join(', '));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    // Non-mandatory fields: provide sensible, production-ready fallbacks if left empty
    const finalizedPackage: Omit<Package, 'id'> = {
      title: formData.title.trim() || 'Custom Tour Package',
      location: formData.location.trim() || 'Worldwide Destination',
      image: formData.image.trim() || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop',
      duration: formData.duration.trim() || 'Flexible Duration',
      price: formData.price.trim() || 'Price on Request',
      rating: formData.rating ? Number(formData.rating) : 4.8,
      reviews: formData.reviews ? Number(formData.reviews) : 50,
      tags: parsedTags.length > 0 ? parsedTags : ['Curated', 'Luxury'],
      description: formData.description.trim() || 'Exclusive personalized journey tailored by Tvista Holidays. Inquire with our team for customized itineraries.'
    };

    onSave(finalizedPackage);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative my-8 text-stone-800 border border-stone-100 max-h-[90vh] overflow-y-auto">
        <button 
          onClick={onClose} 
          className="absolute top-5 right-5 p-2 rounded-full hover:bg-stone-100 transition-colors"
          type="button"
        >
          <X className="w-5 h-5 text-stone-500" />
        </button>

        <div className="mb-6">
          <h3 className="text-2xl font-serif font-bold text-stone-900">
            {mode === 'add' ? 'Add New Tour Package' : `Edit Package #${initialData?.id}`}
          </h3>
          <p className="text-xs text-stone-500 mt-1">
            Fill in the details below. All fields are optional and will automatically use curated defaults if left blank.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 text-xs">
          
          {/* IMAGE UPLOAD SECTION */}
          <div className="bg-stone-50/80 border border-stone-200/90 rounded-2xl p-4 sm:p-5">
            <ImageUploadField
              theme="light"
              label="Package Cover Photo"
              value={formData.image}
              onChange={val => setFormData(prev => ({ ...prev, image: val }))}
              placeholder="https://images.unsplash.com/..."
              helperText="Upload a vibrant landscape tour photo from your device or paste an image URL."
            />
          </div>

          {/* TITLE & LOCATION */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Package Title <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <input 
                type="text" 
                value={formData.title} 
                onChange={e => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
                placeholder="e.g. Bali Tropical Escape" 
              />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Location <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <input 
                type="text" 
                value={formData.location} 
                onChange={e => setFormData({ ...formData, location: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
                placeholder="e.g. Bali, Indonesia" 
              />
            </div>
          </div>

          {/* PRICE, DURATION, RATING */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Price <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <input 
                type="text" 
                value={formData.price} 
                onChange={e => setFormData({ ...formData, price: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
                placeholder="e.g. ₹54,999" 
              />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Duration <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <input 
                type="text" 
                value={formData.duration} 
                onChange={e => setFormData({ ...formData, duration: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
                placeholder="e.g. 6 Days / 5 Nights" 
              />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">
                Rating (1-5) <span className="text-stone-400 font-normal">(Optional)</span>
              </label>
              <input 
                type="number" 
                step="0.1" 
                min="1" 
                max="5"
                value={formData.rating} 
                onChange={e => setFormData({ ...formData, rating: parseFloat(e.target.value) || 4.8 })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
              />
            </div>
          </div>

          {/* TAGS */}
          <div>
            <label className="block font-bold text-stone-700 mb-1">
              Tags <span className="text-stone-400 font-normal">(Optional - Comma-separated)</span>
            </label>
            <input 
              type="text" 
              value={tagsInput} 
              onChange={e => setTagsInput(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-stone-900 focus:bg-white focus:outline-none focus:border-stone-400"
              placeholder="Honeymoon, Beach, Luxury, Adventure" 
            />
          </div>

          {/* DESCRIPTION WITH RICH FORMATTING CONTROLS */}
          <div>
            <label className="block font-bold text-stone-700 mb-1.5 flex items-center justify-between">
              <span>Package Description & Itinerary Details</span>
              <span className="text-[11px] text-amber-700 font-normal">Format with Headings, Bold, Lists & Itinerary Days</span>
            </label>
            <DescriptionEditor 
              value={formData.description} 
              onChange={newVal => setFormData(prev => ({ ...prev, description: newVal }))}
              rows={6}
              placeholder="Provide the journey overview, highlights, and day-by-day itinerary (e.g. ### Day 1: ...)..."
            />
          </div>

          {/* FORM BUTTONS */}
          <div className="pt-3 border-t border-stone-100 flex items-center justify-end gap-3">
            <button 
              type="button" 
              onClick={onClose} 
              className="px-5 py-2.5 rounded-xl border border-stone-200 text-stone-700 font-semibold hover:bg-stone-100 transition-colors"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="px-6 py-2.5 rounded-xl bg-stone-900 text-white font-bold hover:bg-stone-800 shadow-md transition-all"
            >
              Save Package
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function FlightEditModal({ mode, initialData, onClose, onSave }: {
  mode: 'add' | 'edit';
  initialData?: FlightDeal;
  onClose: () => void;
  onSave: (deal: Omit<FlightDeal, 'id'>) => void;
}) {
  const [formData, setFormData] = useState<Omit<FlightDeal, 'id'>>({
    airline: initialData?.airline || '',
    airlineLogo: initialData?.airlineLogo || '',
    from: initialData?.from || '',
    fromCode: initialData?.fromCode || 'DEL',
    to: initialData?.to || '',
    toCode: initialData?.toCode || 'DXB',
    price: initialData?.price || '₹24,999*',
    duration: initialData?.duration || '3h 45m',
    type: initialData?.type || 'Non-stop',
    flightDate: initialData?.flightDate || getTodayDateString(),
    image: initialData?.image || 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=800&auto=format&fit=crop',
    popularTags: initialData?.popularTags || ['Popular Fare']
  });

  const [tagsInput, setTagsInput] = useState((formData.popularTags || []).join(', '));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
    onSave({ ...formData, popularTags: parsedTags });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative my-8 text-stone-800">
        <button onClick={onClose} className="absolute top-5 right-5 p-2 rounded-full hover:bg-stone-100">
          <X className="w-5 h-5 text-stone-500" />
        </button>
        <h3 className="text-2xl font-serif font-bold text-stone-900 mb-6">
          {mode === 'add' ? 'Add Flight Deal' : 'Edit Flight Deal'}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Airline *</label>
              <input 
                required 
                type="text" 
                value={formData.airline} 
                onChange={e => setFormData({ ...formData, airline: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-stone-900 focus:bg-white focus:outline-none" 
              />
            </div>
            <div>
              <ImageUploadField
                theme="light"
                compact
                label="Airline Carrier Logo"
                value={formData.airlineLogo || ''}
                onChange={val => setFormData({ ...formData, airlineLogo: val })}
                placeholder="https://logo.clearbit.com/emirates.com"
                helperText="Upload carrier logo or paste image URL."
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Origin City *</label>
              <input required type="text" value={formData.from} onChange={e => setFormData({ ...formData, from: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Origin Code (e.g. DEL) *</label>
              <input required type="text" value={formData.fromCode} onChange={e => setFormData({ ...formData, fromCode: e.target.value.toUpperCase() })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 uppercase" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Destination City *</label>
              <input required type="text" value={formData.to} onChange={e => setFormData({ ...formData, to: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Destination Code (e.g. DXB) *</label>
              <input required type="text" value={formData.toCode} onChange={e => setFormData({ ...formData, toCode: e.target.value.toUpperCase() })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 uppercase" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Starting Price *</label>
              <input required type="text" value={formData.price} onChange={e => setFormData({ ...formData, price: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Duration *</label>
              <input required type="text" value={formData.duration} onChange={e => setFormData({ ...formData, duration: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Flight Type *</label>
              <input required type="text" value={formData.type} onChange={e => setFormData({ ...formData, type: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="Non-stop / 1 Stop" />
            </div>
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Flight Departure Date *</label>
            <input required type="date" value={formData.flightDate || ''} onChange={e => setFormData({ ...formData, flightDate: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-stone-900" />
          </div>

          <div>
            <ImageUploadField
              theme="light"
              label="Flight Destination Cover Photo"
              value={formData.image || ''}
              onChange={val => setFormData({ ...formData, image: val })}
              placeholder="https://images.unsplash.com/..."
              helperText="Upload destination banner image or paste an image URL."
            />
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Popular Tags (Comma-separated)</label>
            <input type="text" value={tagsInput} onChange={e => setTagsInput(e.target.value)} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <button type="button" onClick={onClose} className="px-5 py-2 rounded-xl border border-stone-200 font-bold">Cancel</button>
            <button type="submit" className="px-6 py-2 rounded-xl bg-stone-900 text-white font-bold shadow-md">Save Flight</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AirlineEditModal({ mode, initialData, onClose, onSave }: {
  mode: 'add' | 'edit';
  initialData?: AirlinePartner;
  onClose: () => void;
  onSave: (partner: AirlinePartner) => void;
}) {
  const [formData, setFormData] = useState<AirlinePartner>({
    name: initialData?.name || '',
    country: initialData?.country || '',
    rating: initialData?.rating || '4.8 ★',
    logo: initialData?.logo || 'https://logo.clearbit.com/emirates.com',
    domain: initialData?.domain || '',
    region: initialData?.region || 'Middle East',
    perks: initialData?.perks || 'Luxury Suites & Chauffeur'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative text-stone-800">
        <button onClick={onClose} className="absolute top-5 right-5 p-2 rounded-full hover:bg-stone-100">
          <X className="w-5 h-5 text-stone-500" />
        </button>
        <h3 className="text-xl font-serif font-bold text-stone-900 mb-4">
          {mode === 'add' ? 'Add Airline Partner' : 'Edit Airline Partner'}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div>
            <label className="block font-bold text-stone-700 mb-1">Airline Name *</label>
            <input required type="text" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Country *</label>
              <input required type="text" value={formData.country} onChange={e => setFormData({ ...formData, country: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Region *</label>
              <select value={formData.region} onChange={e => setFormData({ ...formData, region: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2">
                <option value="Middle East">Middle East</option>
                <option value="Asia Pacific">Asia Pacific</option>
                <option value="Europe & Americas">Europe & Americas</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Rating</label>
              <input type="text" value={formData.rating} onChange={e => setFormData({ ...formData, rating: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Website Domain</label>
              <input type="text" value={formData.domain} onChange={e => setFormData({ ...formData, domain: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="emirates.com" />
            </div>
          </div>

          <ImageUploadField
            theme="light"
            label="Airline Carrier Logo"
            value={formData.logo}
            onChange={val => setFormData({ ...formData, logo: val })}
            placeholder="https://logo.clearbit.com/emirates.com"
            helperText="Upload carrier logo (PNG/SVG/WebP) or paste logo URL."
            compact
          />

          <div>
            <label className="block font-bold text-stone-700 mb-1">Partner Perks</label>
            <input type="text" value={formData.perks} onChange={e => setFormData({ ...formData, perks: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
          </div>

          <div className="pt-3 flex justify-end gap-2">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-xl border border-stone-200 font-bold">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold">Save Airline</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function VisaEditModal({ mode, initialData, onClose, onSave }: {
  mode: 'add' | 'edit';
  initialData?: VisaCountryItem;
  onClose: () => void;
  onSave: (visa: VisaCountryItem) => void;
}) {
  const [formData, setFormData] = useState<VisaCountryItem>({
    name: initialData?.name || '',
    code: initialData?.code || 'us',
    types: initialData?.types || ['Tourist Visa'],
    processingTime: initialData?.processingTime || '2-3 Weeks',
    fee: initialData?.fee || 'From ₹8,500',
    details: initialData?.details || ''
  });

  const [typesInput, setTypesInput] = useState(formData.types.join(', '));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTypes = typesInput.split(',').map(t => t.trim()).filter(Boolean);
    onSave({ ...formData, types: parsedTypes });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative text-stone-800">
        <button onClick={onClose} className="absolute top-5 right-5 p-2 rounded-full hover:bg-stone-100">
          <X className="w-5 h-5 text-stone-500" />
        </button>
        <h3 className="text-xl font-serif font-bold text-stone-900 mb-4">
          {mode === 'add' ? 'Add Visa Country' : `Edit Visa Info: ${initialData?.name}`}
        </h3>

        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Country Name *</label>
              <input required type="text" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">2-Letter ISO Code *</label>
              <input required type="text" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="e.g. US, GB, JP" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-stone-700 mb-1">Processing Time *</label>
              <input required type="text" value={formData.processingTime} onChange={e => setFormData({ ...formData, processingTime: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="e.g. 3-5 Days" />
            </div>
            <div>
              <label className="block font-bold text-stone-700 mb-1">Starting Fee *</label>
              <input required type="text" value={formData.fee} onChange={e => setFormData({ ...formData, fee: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="e.g. From ₹6,500" />
            </div>
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Visa Types (Comma-separated)</label>
            <input type="text" value={typesInput} onChange={e => setTypesInput(e.target.value)} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2" placeholder="Tourist, Business, Student" />
          </div>

          <div>
            <label className="block font-bold text-stone-700 mb-1">Requirements & Instructions</label>
            <textarea rows={6} value={formData.details} onChange={e => setFormData({ ...formData, details: e.target.value })} className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 resize-y whitespace-pre-wrap" placeholder={"Important requirements...\n- Passport valid 6 months\n- 2 photos"} />
          </div>

          <div className="pt-3 flex justify-end gap-2">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-xl border border-stone-200 font-bold">Cancel</button>
            <button type="submit" className="px-5 py-2 rounded-xl bg-stone-900 text-white font-bold">Save Visa Info</button>
          </div>
        </form>
      </div>
    </div>
  );
}
