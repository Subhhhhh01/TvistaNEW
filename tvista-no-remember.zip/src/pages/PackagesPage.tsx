import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import PackageCard from '../components/PackageCard';
import PackageFilter from '../components/PackageFilter';
import PackageModal from '../components/PackageModal';
import { CATEGORIES, Package } from '../data/packagesData';
import { useData } from '../context/DataContext';

export default function PackagesPage() {
  const { packages } = useData();
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category');
  const [activeCategory, setActiveCategory] = useState(
    categoryParam && CATEGORIES.includes(categoryParam) ? categoryParam : 'All'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPkg, setSelectedPkg] = useState<Package | null>(null);

  useEffect(() => {
    if (categoryParam && CATEGORIES.includes(categoryParam)) {
      setActiveCategory(categoryParam);
    } else if (!categoryParam) {
      setActiveCategory('All');
    }
  }, [categoryParam]);

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
    if (category === 'All') {
      setSearchParams({});
    } else {
      setSearchParams({ category });
    }
  };

  const filteredPackages = packages.filter(pkg => {
    const query = searchQuery.toLowerCase().trim();
    const tags = Array.isArray(pkg.tags) ? pkg.tags : [];
    const title = pkg.title || '';
    const location = pkg.location || '';
    const description = pkg.description || '';
    const matchesCategory = activeCategory === 'All' ? true : tags.includes(activeCategory);
    const matchesSearch = !query || 
      title.toLowerCase().includes(query) || 
      location.toLowerCase().includes(query) ||
      description.toLowerCase().includes(query) ||
      tags.some(tag => tag.toLowerCase().includes(query));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="relative min-h-screen text-stone-900 selection:bg-amber-200 selection:text-amber-950 font-sans">
      {/* Global Background Image - High-Clarity Visible Tropical & Scenic Backdrop */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop" 
          alt="Luxury Tropical Coastline Background" 
          className="w-full h-full object-cover scale-105" 
        />
        {/* Soft, luminous light atmospheric veil so the scenic image is clearly visible, not black */}
        <div className="absolute inset-0 bg-white/45 backdrop-blur-[0.5px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/70 via-stone-50/20 to-white/75" />
      </div>

      <Navbar theme="light" />
      
      {/* Hero Section */}
      <div className="relative z-10 pt-32 sm:pt-36 pb-16 sm:pb-20 px-6 sm:px-12 lg:px-20 text-stone-900 min-h-[45vh] flex flex-col items-center justify-center text-center">
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 text-center w-full max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100 border border-amber-300/80 text-amber-900 text-xs font-semibold tracking-widest uppercase mb-6 shadow-xs backdrop-blur-md">
            <Star className="w-3.5 h-3.5 text-amber-600" fill="currentColor" />
            Curated Experiences
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif text-stone-900 mb-6 drop-shadow-xs leading-tight tracking-tight">
            Discover Your Next <span className="italic font-light text-amber-700">Journey</span>
          </h1>
          <p className="text-base sm:text-lg md:text-xl text-stone-700 max-w-2xl mx-auto font-normal leading-relaxed drop-shadow-xs">
            Expertly crafted travel packages combining luxury, adventure, and unforgettable moments around the globe.
          </p>
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-20 pb-24">
        {/* Filters */}
        <PackageFilter 
          categories={CATEGORIES}
          activeCategory={activeCategory}
          onSelectCategory={handleCategoryChange}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          theme="light"
        />

        {/* Grid or Empty State */}
        {filteredPackages.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPackages.map((pkg, index) => (
              <PackageCard 
                key={pkg.id}
                pkg={pkg}
                index={index}
                onSelect={setSelectedPkg}
                theme="light"
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white/85 border border-stone-200/90 backdrop-blur-xl rounded-[2.5rem] p-8 shadow-sm">
            <h3 className="text-2xl font-serif text-stone-900 mb-2">No Escapes Found</h3>
            <p className="text-stone-600 text-sm max-w-md mx-auto mb-6">
              We couldn't find any packages matching "{searchQuery}". Try searching for another destination or clearing filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                handleCategoryChange('All');
              }}
              className="bg-stone-900 text-white font-bold px-6 py-3 rounded-full text-xs uppercase tracking-wider hover:bg-amber-600 transition-colors shadow-md"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Package Details / Enquiry Modal */}
      <PackageModal 
        packageData={selectedPkg}
        onClose={() => setSelectedPkg(null)}
      />

      <Footer theme="light" />
    </div>
  );
}
