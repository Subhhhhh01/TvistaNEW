import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import FlightModal, { FlightDeal } from '../components/FlightModal';
import { motion } from 'motion/react';
import { 
  Plane, Calendar, User, Search, ArrowRight, CheckCircle, Clock, 
  ShieldCheck, Globe2, Sparkles, Send, RefreshCw, Award, HeartHandshake, Headphones
} from 'lucide-react';
import { useData } from '../context/DataContext';

export default function FlightPage() {
  const { activeFlightDeals, flightDeals, airlinePartners } = useData();
  const [tripType, setTripType] = useState<'round' | 'oneWay' | 'multi'>('round');
  const [fromCity, setFromCity] = useState('');
  const [toCity, setToCity] = useState('');
  const [departDate, setDepartDate] = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [passengers, setPassengers] = useState('1');
  const [cabinClass, setCabinClass] = useState('Economy');
  const [selectedFlight, setSelectedFlight] = useState<FlightDeal | null>(null);
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [hasSearched, setHasSearched] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const filteredPartners = selectedRegion === 'All'
    ? airlinePartners
    : airlinePartners.filter(p => p.region === selectedRegion);

  // Search filtering logic
  const displayedDeals = React.useMemo(() => {
    if (!hasSearched && !fromCity.trim() && !toCity.trim()) {
      return activeFlightDeals;
    }

    const fromQuery = fromCity.toLowerCase().trim();
    const toQuery = toCity.toLowerCase().trim();

    return activeFlightDeals.filter(deal => {
      const matchFrom = !fromQuery || 
        deal.from.toLowerCase().includes(fromQuery) || 
        deal.fromCode.toLowerCase().includes(fromQuery);
      
      const matchTo = !toQuery || 
        deal.to.toLowerCase().includes(toQuery) || 
        deal.toCode.toLowerCase().includes(toQuery);

      const matchDate = !departDate || !deal.flightDate || deal.flightDate === departDate;

      return matchFrom && matchTo && matchDate;
    });
  }, [activeFlightDeals, fromCity, toCity, departDate, hasSearched]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    // Scroll smoothly to results section
    const resultsElement = document.getElementById('flight-results-section');
    if (resultsElement) {
      resultsElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const clearSearch = () => {
    setFromCity('');
    setToCity('');
    setDepartDate('');
    setReturnDate('');
    setHasSearched(false);
  };

  return (
    <div className="relative min-h-screen font-sans text-[#1C1917] selection:bg-amber-200 selection:text-amber-950">
      {/* Global Atmospheric Flight Background Image */}
      <div className="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1506012787146-f92b2d7d6d96?q=80&w=2069&auto=format&fit=crop" 
          alt="Flight Sky View Background" 
          className="w-full h-full object-cover scale-105"
        />
        <div className="absolute inset-0 bg-stone-900/35 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-stone-950/60 via-stone-900/20 to-stone-950/50" />
      </div>

      <Navbar theme="light" />

      {/* Main Content */}
      <div className="pt-28 pb-20 px-6 sm:px-12 lg:px-20 max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-white/90 shadow-sm text-xs font-bold uppercase tracking-widest text-stone-800 mb-4 backdrop-blur-md"
          >
            <Plane className="w-3.5 h-3.5 text-stone-800" />
            <span>Airline Ticketing &amp; Global Reservations</span>
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-serif text-white tracking-tight leading-tight mb-4 drop-shadow-md font-bold"
          >
            Seamless Global Flights
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-base sm:text-lg text-stone-200 font-light leading-relaxed drop-shadow-xs max-w-2xl mx-auto"
          >
            Unlock special negotiated airfares, direct GDS seats, group discounts, and 24/7 flight concierge assistance with Tvista Holidays.
          </motion.p>
        </div>

        {/* Flight Search Engine Container - White Blurry Frosted Glass Theme */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/75 backdrop-blur-2xl border border-white/90 rounded-[2.5rem] p-6 sm:p-8 lg:p-10 shadow-2xl mb-16"
        >
          {/* Trip Type Tabs */}
          <div className="flex items-center gap-2 mb-6 border-b border-stone-200/80 pb-4 overflow-x-auto">
            <button
              onClick={() => setTripType('round')}
              className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                tripType === 'round' 
                  ? 'bg-[#1C1917] text-white shadow-md' 
                  : 'bg-white/60 text-stone-600 hover:bg-white hover:text-stone-900 border border-stone-200'
              }`}
            >
              Round Trip
            </button>
            <button
              onClick={() => setTripType('oneWay')}
              className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                tripType === 'oneWay' 
                  ? 'bg-[#1C1917] text-white shadow-md' 
                  : 'bg-white/60 text-stone-600 hover:bg-white hover:text-stone-900 border border-stone-200'
              }`}
            >
              One Way
            </button>
            <button
              onClick={() => setTripType('multi')}
              className={`px-5 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all ${
                tripType === 'multi' 
                  ? 'bg-[#1C1917] text-white shadow-md' 
                  : 'bg-white/60 text-stone-600 hover:bg-white hover:text-stone-900 border border-stone-200'
              }`}
            >
              Multi-City / Group Fare
            </button>
          </div>

          <form onSubmit={handleSearchSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Departure */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">From City / Airport *</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    value={fromCity}
                    onChange={e => setFromCity(e.target.value)}
                    placeholder="e.g. New Delhi (DEL)"
                    className="w-full bg-white/80 border border-stone-200/90 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm"
                  />
                  <Plane className="w-4 h-4 text-stone-400 absolute right-3.5 top-3.5" />
                </div>
              </div>

              {/* Destination */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">To City / Airport *</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    value={toCity}
                    onChange={e => setToCity(e.target.value)}
                    placeholder="e.g. London (LHR)"
                    className="w-full bg-white/80 border border-stone-200/90 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm"
                  />
                  <Plane className="w-4 h-4 text-stone-400 absolute right-3.5 top-3.5 rotate-90" />
                </div>
              </div>

              {/* Depart Date */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">Departure Date *</label>
                <div className="relative">
                  <input
                    required
                    type="date"
                    value={departDate}
                    onChange={e => setDepartDate(e.target.value)}
                    className="w-full bg-white/80 border border-stone-200/90 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm"
                  />
                </div>
              </div>

              {/* Return Date */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">
                  {tripType === 'oneWay' ? 'Return Date (Optional)' : 'Return Date *'}
                </label>
                <div className="relative">
                  <input
                    disabled={tripType === 'oneWay'}
                    required={tripType === 'round'}
                    type="date"
                    value={returnDate}
                    onChange={e => setReturnDate(e.target.value)}
                    className={`w-full border rounded-xl px-4 py-3 text-sm transition-all shadow-sm ${
                      tripType === 'oneWay' 
                        ? 'bg-stone-100/50 border-stone-200 text-stone-400 cursor-not-allowed' 
                        : 'bg-white/80 border-stone-200/90 text-[#1C1917] focus:outline-none focus:border-stone-800 focus:bg-white'
                    }`}
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              {/* Passengers */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">Passengers</label>
                <select
                  value={passengers}
                  onChange={e => setPassengers(e.target.value)}
                  className="w-full bg-white/80 border border-stone-200/90 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm"
                >
                  <option value="1">1 Adult</option>
                  <option value="2">2 Adults</option>
                  <option value="3">3 Adults</option>
                  <option value="family">Family (2 Adults + Kids)</option>
                  <option value="group">Group Booking (9+ Travelers)</option>
                </select>
              </div>

              {/* Cabin Class */}
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 font-bold mb-1.5">Cabin Class</label>
                <select
                  value={cabinClass}
                  onChange={e => setCabinClass(e.target.value)}
                  className="w-full bg-white/80 border border-stone-200/90 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm"
                >
                  <option value="Economy">Economy Class</option>
                  <option value="Premium Economy">Premium Economy</option>
                  <option value="Business">Business Class</option>
                  <option value="First Class">First Class</option>
                </select>
              </div>

              {/* Search Button */}
              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full bg-[#1C1917] hover:bg-[#292524] text-white font-medium py-3.5 rounded-xl transition-all text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2 group"
                >
                  <Search className="w-4 h-4" />
                  <span>Search Flight Quotes</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </form>
        </motion.div>

        {/* Popular Flight Deals Grid */}
        <div id="flight-results-section" className="mb-20 scroll-mt-24">
          <div className="bg-white/90 backdrop-blur-2xl border border-white/90 rounded-[2rem] p-6 sm:p-8 lg:p-10 shadow-xl mb-8 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
            {/* Ambient subtle glow */}
            <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-200/40 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10 max-w-xl">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-stone-900 text-amber-300 text-xs font-bold uppercase tracking-wider mb-3 shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{hasSearched ? 'Search Flight Deals' : 'Handpicked Active Fares'}</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-950 tracking-tight leading-tight">
                {hasSearched ? `Flight Search Results (${displayedDeals.length})` : 'Popular International Routes'}
              </h2>
            </div>
            
            <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center gap-3">
              {hasSearched && (
                <button
                  onClick={clearSearch}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-bold uppercase tracking-wider transition-all"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Show All Deals</span>
                </button>
              )}
              <div className="bg-stone-100/90 border border-stone-200/80 p-4 rounded-2xl max-w-xs shadow-xs">
                <p className="text-xs text-stone-800 font-medium leading-relaxed">
                  Active flights updated via Admin Panel. Past dated flights are automatically filtered out.
                </p>
              </div>
            </div>
          </div>

          {displayedDeals.length === 0 ? (
            <div className="bg-white/90 backdrop-blur-xl border border-white/90 rounded-3xl p-10 text-center shadow-lg max-w-2xl mx-auto">
              <Plane className="w-12 h-12 text-stone-400 mx-auto mb-4" />
              <h3 className="text-2xl font-serif font-bold text-stone-900 mb-2">No Specific Uploaded Flights Found</h3>
              <p className="text-stone-600 text-sm mb-6 leading-relaxed">
                We do not have a pre-listed deal matching <strong className="text-stone-900">{fromCity || 'your departure'}</strong> to <strong className="text-stone-900">{toCity || 'your destination'}</strong> for the selected date. Request a custom fare quote below and our team will find the best rate!
              </p>
              <button
                onClick={() => {
                  const customDeal: FlightDeal = {
                    id: 'custom-quote-req',
                    airline: 'Custom Reservation Quote',
                    from: fromCity || 'Departure City',
                    fromCode: fromCity.substring(0, 3).toUpperCase() || 'DEP',
                    to: toCity || 'Destination City',
                    toCode: toCity.substring(0, 3).toUpperCase() || 'DEST',
                    price: 'Special Fare Quote',
                    duration: 'Best Route Options',
                    type: tripType === 'round' ? 'Round Trip' : 'One Way',
                    image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=800&auto=format&fit=crop'
                  };
                  setSelectedFlight(customDeal);
                }}
                className="inline-flex items-center gap-2 bg-[#1C1917] hover:bg-[#292524] text-white px-6 py-3 rounded-full text-xs uppercase font-bold tracking-wider shadow-md transition-all"
              >
                <Send className="w-4 h-4" />
                <span>Request Custom Fare Quote</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {displayedDeals.map((deal, idx) => (
                <motion.div
                  key={deal.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="bg-white/95 backdrop-blur-xl border border-stone-200/80 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-4 md:gap-6 group"
                >
                  {/* Left: Airline Name & Logo */}
                  <div className="flex items-center gap-3.5 min-w-[200px] shrink-0">
                    <div className="w-10 h-10 rounded-xl bg-stone-50 border border-stone-100 flex items-center justify-center p-1.5 shadow-xs shrink-0">
                      {deal.airlineLogo ? (
                        <img 
                          src={deal.airlineLogo} 
                          alt={deal.airline} 
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            const target = e.currentTarget;
                            const cleanDomain = deal.airline.toLowerCase().replaceAll(' ', '');
                            target.src = "https://www.google.com/s2/favicons?domain=" + cleanDomain + ".com&sz=128";
                          }}
                          className="w-full h-full object-contain" 
                        />
                      ) : (
                        <Plane className="w-5 h-5 text-stone-600" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-stone-900 tracking-tight leading-none mb-1">{deal.airline}</h4>
                      <span className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider">
                        {deal.type} • {deal.duration}
                      </span>
                    </div>
                  </div>

                  {/* Middle: Route Info */}
                  <div className="flex items-center gap-4 grow">
                    <div className="text-left shrink-0">
                      <span className="text-base sm:text-lg font-serif font-bold text-stone-900 block leading-tight">{deal.from}</span>
                      <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-stone-500">{deal.fromCode}</span>
                    </div>
                    
                    <div className="flex flex-col items-center justify-center grow max-w-[120px] text-stone-400">
                      <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-stone-400">Non-stop</span>
                      <div className="w-full flex items-center gap-1.5">
                        <div className="h-[1.5px] bg-stone-200 grow" />
                        <Plane className="w-3.5 h-3.5 text-stone-400 shrink-0 rotate-90" />
                        <div className="h-[1.5px] bg-stone-200 grow" />
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-base sm:text-lg font-serif font-bold text-stone-900 block leading-tight">{deal.to}</span>
                      <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-stone-500">{deal.toCode}</span>
                    </div>
                  </div>

                  {/* Date Column */}
                  <div className="flex items-center gap-3 shrink-0">
                    {deal.flightDate && (
                      <span className="text-[11px] font-bold uppercase tracking-wider px-3 py-1 rounded-full bg-stone-100 text-stone-700 border border-stone-200 flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-stone-500" />
                        <span>{deal.flightDate}</span>
                      </span>
                    )}
                  </div>

                  {/* Pricing and Action */}
                  <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 pt-3 md:pt-0 border-t border-dashed border-stone-200 md:border-none w-full md:w-auto">
                    <div className="text-left md:text-right shrink-0">
                      <span className="text-[10px] uppercase tracking-wider text-stone-400 block">Starting From</span>
                      <span className="text-xl font-serif font-bold text-stone-950">{deal.price}</span>
                    </div>

                    <button
                      onClick={() => setSelectedFlight(deal)}
                      className="px-5 py-2.5 bg-[#1C1917] hover:bg-stone-800 text-white font-semibold rounded-full transition-all text-xs uppercase tracking-wider shadow-sm flex items-center justify-center gap-2 group shrink-0"
                    >
                      <span>Enquire</span>
                      <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
      </div>

        {/* Airline Partners */}
        <div className="bg-white/75 backdrop-blur-2xl border border-white/90 rounded-[2.5rem] p-6 sm:p-10 lg:p-12 shadow-2xl mb-20 relative overflow-hidden">
          {/* Ambient background blur elements */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-amber-200/20 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-stone-200/40 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-8 border-b border-stone-200/70">
              <div>
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-stone-900/5 border border-stone-900/10 text-stone-800 text-xs font-semibold uppercase tracking-wider mb-3">
                  <Globe2 className="w-3.5 h-3.5 text-stone-700" />
                  <span>Global Aviation Network</span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-serif text-[#1C1917]">Our Partner Airlines</h2>
                <p className="text-stone-600 text-sm sm:text-base font-light mt-2 max-w-xl leading-relaxed">
                  Direct partnership with 12+ world-renowned 5-Star full-service carriers ensuring guaranteed GDS rates, flexible seat allocation & luxury baggage privileges.
                </p>
              </div>

              {/* Region Filter Pills */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                {['All', 'Middle East', 'Asia Pacific', 'Europe & Americas'].map((region) => (
                  <button
                    key={region}
                    onClick={() => setSelectedRegion(region)}
                    className={`px-4 py-2 rounded-xl text-xs font-medium transition-all shadow-xs ${
                      selectedRegion === region
                        ? 'bg-[#1C1917] text-white shadow-md'
                        : 'bg-white/80 hover:bg-white text-stone-600 border border-stone-200/80 hover:text-stone-900'
                    }`}
                  >
                    {region}
                  </button>
                ))}
              </div>
            </div>

            {/* Partner Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredPartners.map((partner) => (
                <div
                  key={partner.name}
                  onClick={() => {
                    const partnerDeal: FlightDeal = {
                      id: `partner-${partner.name.toLowerCase().replaceAll(' ', '-')}`,
                      airline: partner.name,
                      airlineLogo: partner.logo,
                      from: 'Major Indian Departure Cities',
                      fromCode: 'DEL / BOM / BLR',
                      to: `${partner.country} & International Network`,
                      toCode: 'INTL',
                      price: 'Exclusive Partner Rates',
                      duration: 'Direct & Express Transit',
                      type: partner.region,
                      popularTags: [partner.perks, `${partner.rating} Rated`],
                      image: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=800&auto=format&fit=crop'
                    };
                    setSelectedFlight(partnerDeal);
                  }}
                  className="group relative bg-white/90 hover:bg-white border border-stone-200/80 hover:border-stone-400 rounded-2xl p-5 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer flex flex-col justify-between gap-4 hover:-translate-y-1 overflow-hidden"
                >
                  {/* Top Row: Logo + Badges */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="w-14 h-14 rounded-2xl bg-stone-50 border border-stone-200/80 p-2.5 flex items-center justify-center shadow-xs group-hover:scale-105 group-hover:border-stone-300 transition-all shrink-0">
                      <img
                        src={partner.logo}
                        alt={`${partner.name} logo`}
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          const target = e.currentTarget;
                          target.src = "https://www.google.com/s2/favicons?domain=" + partner.domain + "&sz=128";
                        }}
                        className="w-full h-full object-contain"
                      />
                    </div>
                    
                    <div className="flex flex-col items-end gap-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-md">
                        <span>{partner.rating}</span>
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-stone-500 tracking-wider">
                        {partner.country}
                      </span>
                    </div>
                  </div>

                  {/* Middle: Name & Perks */}
                  <div>
                    <h3 className="font-semibold text-base text-[#1C1917] group-hover:text-amber-900 transition-colors leading-tight mb-1">
                      {partner.name}
                    </h3>
                    <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                      {partner.perks}
                    </p>
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600 font-medium group-hover:text-stone-900 transition-colors">
                    <span className="flex items-center gap-1.5 text-[11px] text-stone-500">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>GDS Direct Fare</span>
                    </span>
                    <span className="inline-flex items-center gap-1 font-semibold text-[#1C1917] group-hover:translate-x-0.5 transition-transform">
                      <span>Enquire</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Section Bottom Banner Note */}
            <div className="mt-8 pt-6 border-t border-stone-200/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 text-center sm:text-left">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Certified IATA Ticketing Agent • Official Carrier Discounts Applied Automatically</span>
              </div>
              <div className="font-medium text-stone-700">
                Need custom group or corporate fares?{' '}
                <button 
                  onClick={() => setSelectedFlight({
                    id: 'group-booking',
                    airline: 'Group & Corporate Flight Booking',
                    airlineLogo: '',
                    from: 'Multiple Departure Cities',
                    fromCode: 'GRP',
                    to: 'Global Destination Network',
                    toCode: 'INTL',
                    price: 'Corporate Discounted Fare',
                    duration: 'Custom Itinerary',
                    type: 'Group Booking',
                    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?q=80&w=800&auto=format&fit=crop'
                  })} 
                  className="underline font-semibold hover:text-black transition-colors"
                >
                  Request Group Quote
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Why Book Flights with Tvista Holidays */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          <div className="bg-white/75 backdrop-blur-xl border border-white/80 rounded-3xl p-8 shadow-lg">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-[#1C1917] flex items-center justify-center mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-serif font-bold text-[#1C1917] mb-2">Best Fare Price Guarantee</h3>
            <p className="text-stone-600 text-sm font-light leading-relaxed">
              We compare GDS global inventory to provide corporate and leisure fares often lower than standard public web portals.
            </p>
          </div>

          <div className="bg-white/75 backdrop-blur-xl border border-white/80 rounded-3xl p-8 shadow-lg">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-[#1C1917] flex items-center justify-center mb-4">
              <Headphones className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-serif font-bold text-[#1C1917] mb-2">24/7 Travel Desk Concierge</h3>
            <p className="text-stone-600 text-sm font-light leading-relaxed">
              Instant human support for flight delays, seat re-assignments, web check-ins, or emergency itinerary changes.
            </p>
          </div>

          <div className="bg-white/75 backdrop-blur-xl border border-white/80 rounded-3xl p-8 shadow-lg">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-[#1C1917] flex items-center justify-center mb-4">
              <RefreshCw className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-serif font-bold text-[#1C1917] mb-2">Flexible Rebooking Policies</h3>
            <p className="text-stone-600 text-sm font-light leading-relaxed">
              Option for flexible ticket protection, date changes without hefty penalties, and instant refund processing.
            </p>
          </div>
        </div>

        {/* Custom Flight Consultation Form - White Blurry Theme */}
        <div className="bg-white/75 backdrop-blur-xl border border-white/80 rounded-[2.5rem] p-8 lg:p-12 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-5">
              <span className="text-xs font-bold uppercase tracking-widest text-stone-500 block mb-2">Personalized Assistance</span>
              <h3 className="text-3xl font-serif text-[#1C1917] mb-4">Need Corporate or Custom Group Flight Booking?</h3>
              <p className="text-stone-600 text-sm font-light leading-relaxed mb-6">
                Planning a destination wedding, corporate incentive trip, or multi-destination worldwide itinerary? Contact our flight desk for personalized fare quotes.
              </p>
              <div className="space-y-3 text-xs text-stone-700 font-medium">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Exclusive group seat blocks for 10+ passengers</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Business class & premium cabin upgrades</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>GST invoice support for business travel</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-7">
              {formSubmitted ? (
                <div className="bg-emerald-50/90 border border-emerald-200 text-emerald-900 p-8 rounded-2xl flex flex-col items-center text-center backdrop-blur-md shadow-sm">
                  <CheckCircle className="w-12 h-12 text-emerald-600 mb-3" />
                  <h4 className="text-2xl font-serif font-bold mb-2 text-[#1C1917]">Consultation Request Received</h4>
                  <p className="text-sm text-stone-600 leading-relaxed">
                    Thank you for submitting your flight requirements. Our senior flight agent will contact you shortly with customized flight options.
                  </p>
                </div>
              ) : (
                <form onSubmit={e => { e.preventDefault(); setFormSubmitted(true); }} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Full Name *</label>
                      <input required type="text" placeholder="e.g. Rahul Sharma" className="w-full bg-white/70 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm" />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Email Address *</label>
                      <input required type="email" placeholder="rahul@example.com" className="w-full bg-white/70 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Phone Number *</label>
                      <input required type="tel" placeholder="+91 98307 12357" className="w-full bg-white/70 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm" />
                    </div>
                    <div>
                      <label className="block text-xs uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Flight Route / Sector</label>
                      <input type="text" placeholder="e.g. DEL - LHR or Multi-city" className="w-full bg-white/70 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all shadow-sm" />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Flight Requirements / Notes</label>
                    <textarea rows={3} placeholder="Provide details like travel dates, preferred airlines, baggage requirements, or group size..." className="w-full bg-white/70 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-stone-800 focus:bg-white transition-all resize-none shadow-sm" />
                  </div>

                  <button type="submit" className="w-full bg-[#1C1917] hover:bg-[#292524] text-white font-medium py-3.5 rounded-xl transition-all text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" />
                    <span>Submit Flight Request</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Flight Detail Modal */}
      <FlightModal 
        flight={selectedFlight}
        onClose={() => setSelectedFlight(null)}
      />

      <Footer theme="light" />
    </div>
  );
}
