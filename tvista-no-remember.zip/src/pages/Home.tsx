/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import Destinations from '../components/Destinations';
import Featured from '../components/Featured';
import Testimonials from '../components/Testimonials';
import Footer from '../components/Footer';

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end']
  });

  // Physical spring physics to smooth out mouse wheel ticks and touch steps
  const smoothProgress = useSpring(scrollYProgress, {
    damping: 30,
    stiffness: 90,
    mass: 0.25,
    restDelta: 0.0001
  });

  // Page 1 (Hero) transitions
  const page1Opacity = useTransform(smoothProgress, [0, 0.12, 0.18], [1, 1, 0]);
  const page1Y = useTransform(smoothProgress, [0, 0.12, 0.18], [0, 0, -40]);
  const page1Scale = useTransform(smoothProgress, [0, 0.12, 0.18], [1, 1, 0.96]);

  // Page 2 (Destinations) transitions
  const page2Opacity = useTransform(smoothProgress, [0.15, 0.20, 0.42, 0.46], [0, 1, 1, 0]);
  const page2Y = useTransform(smoothProgress, [0.15, 0.20, 0.42, 0.46], [50, 0, 0, -50]);
  const page2Scale = useTransform(smoothProgress, [0.15, 0.20, 0.42, 0.46], [0.96, 1, 1, 0.96]);

  // Page 3 (Featured) transitions
  const page3Opacity = useTransform(smoothProgress, [0.44, 0.48, 0.70, 0.74], [0, 1, 1, 0]);
  const page3Y = useTransform(smoothProgress, [0.44, 0.48, 0.70, 0.74], [50, 0, 0, -50]);
  const page3Scale = useTransform(smoothProgress, [0.44, 0.48, 0.70, 0.74], [0.96, 1, 1, 0.96]);

  // Page 4 (Testimonials) transitions
  const page4Opacity = useTransform(smoothProgress, [0.72, 0.76, 1.0], [0, 1, 1]);
  const page4Y = useTransform(smoothProgress, [0.72, 0.76, 1.0], [50, 0, 0]);
  const page4Scale = useTransform(smoothProgress, [0.72, 0.76, 1.0], [0.96, 1, 1]);

  // Interactive pointer events
  const page1Pointer = useTransform(smoothProgress, (v) => v < 0.16 ? "auto" : "none");
  const page2Pointer = useTransform(smoothProgress, (v) => v >= 0.18 && v < 0.44 ? "auto" : "none");
  const page3Pointer = useTransform(smoothProgress, (v) => v >= 0.46 && v < 0.72 ? "auto" : "none");
  const page4Pointer = useTransform(smoothProgress, (v) => v >= 0.74 ? "auto" : "none");

  // Normalized progress for Destinations places revealing one by one (0 to 1)
  const destinationsProgress = useTransform(smoothProgress, [0.20, 0.42], [0, 1]);
  // Normalized progress for Featured escapes revealing one by one (0 to 1)
  const featuredProgress = useTransform(smoothProgress, [0.48, 0.70], [0, 1]);
  // Normalized progress for Testimonials revealing one by one (0 to 1)
  const testimonialsProgress = useTransform(smoothProgress, [0.76, 0.98], [0, 1]);

  const pageIndexRef = useRef(0);
  const isAnimatingRef = useRef(false);

  useEffect(() => {
    const progressTargets = [
      0.0,    // Hero (Slide 0)
      0.200,  // Destinations - Kyoto (Slide 1)
      0.244,  // Destinations - Amalfi (Slide 2)
      0.288,  // Destinations - Paris (Slide 3)
      0.332,  // Destinations - Swiss Alps (Slide 4)
      0.376,  // Destinations - Santorini (Slide 5)
      0.420,  // Destinations - Banff (Slide 6)
      0.480,  // Featured - Bali (Slide 7)
      0.590,  // Featured - Santorini (Slide 8)
      0.700,  // Featured - Kyoto (Slide 9)
      0.760,  // Testimonials - Elena & Marcus (Slide 10)
      0.870,  // Testimonials - Dr. Aris Thorne (Slide 11)
      0.980   // Testimonials - Sophia & Julian (Slide 12)
    ];

    const handleWheel = (e: WheelEvent) => {
      if (isAnimatingRef.current) {
        e.preventDefault();
        return;
      }

      const deltaY = e.deltaY;
      if (Math.abs(deltaY) < 15) return; // filter noise

      let nextIndex = pageIndexRef.current;
      if (deltaY > 0) {
        if (pageIndexRef.current < progressTargets.length - 1) {
          nextIndex = pageIndexRef.current + 1;
        }
      } else {
        if (pageIndexRef.current > 0) {
          nextIndex = pageIndexRef.current - 1;
        }
      }

      if (nextIndex !== pageIndexRef.current) {
        e.preventDefault();
        pageIndexRef.current = nextIndex;
        isAnimatingRef.current = true;

        const maxScroll = containerRef.current
          ? containerRef.current.scrollHeight - window.innerHeight
          : 0;

        const targetY = maxScroll * progressTargets[nextIndex];

        window.scrollTo({
          top: targetY,
          behavior: 'smooth'
        });

        setTimeout(() => {
          isAnimatingRef.current = false;
        }, 1000); // 1s lock ensures the smooth scroll animation completes cleanly
      }
    };

    let touchStartY = 0;
    const handleTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0].clientY;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      if (isAnimatingRef.current) return;

      const touchEndY = e.changedTouches[0].clientY;
      const diffY = touchStartY - touchEndY; // swipe up (positive) is scroll down

      if (Math.abs(diffY) < 40) return;

      let nextIndex = pageIndexRef.current;
      if (diffY > 0) {
        if (pageIndexRef.current < progressTargets.length - 1) {
          nextIndex = pageIndexRef.current + 1;
        }
      } else {
        if (pageIndexRef.current > 0) {
          nextIndex = pageIndexRef.current - 1;
        }
      }

      if (nextIndex !== pageIndexRef.current) {
        pageIndexRef.current = nextIndex;
        isAnimatingRef.current = true;

        const maxScroll = containerRef.current
          ? containerRef.current.scrollHeight - window.innerHeight
          : 0;

        const targetY = maxScroll * progressTargets[nextIndex];

        window.scrollTo({
          top: targetY,
          behavior: 'smooth'
        });

        setTimeout(() => {
          isAnimatingRef.current = false;
        }, 1000);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (isAnimatingRef.current) {
        e.preventDefault();
        return;
      }

      let nextIndex = pageIndexRef.current;
      if (e.key === 'ArrowDown' || e.key === ' ' || e.key === 'PageDown') {
        if (pageIndexRef.current < progressTargets.length - 1) {
          nextIndex = pageIndexRef.current + 1;
          e.preventDefault();
        }
      } else if (e.key === 'ArrowUp' || e.key === 'PageUp') {
        if (pageIndexRef.current > 0) {
          nextIndex = pageIndexRef.current - 1;
          e.preventDefault();
        }
      }

      if (nextIndex !== pageIndexRef.current) {
        pageIndexRef.current = nextIndex;
        isAnimatingRef.current = true;

        const maxScroll = containerRef.current
          ? containerRef.current.scrollHeight - window.innerHeight
          : 0;

        const targetY = maxScroll * progressTargets[nextIndex];

        window.scrollTo({
          top: targetY,
          behavior: 'smooth'
        });

        setTimeout(() => {
          isAnimatingRef.current = false;
        }, 1000);
      }
    };

    const handleScroll = () => {
      if (isAnimatingRef.current) return;

      const maxScroll = containerRef.current
        ? containerRef.current.scrollHeight - window.innerHeight
        : 0;

      if (maxScroll <= 0) return;

      const currentScroll = window.scrollY;
      const currentProgress = currentScroll / maxScroll;

      let closestIndex = 0;
      let minDiff = Infinity;
      for (let i = 0; i < progressTargets.length; i++) {
        const diff = Math.abs(currentProgress - progressTargets[i]);
        if (diff < minDiff) {
          minDiff = diff;
          closestIndex = i;
        }
      }

      pageIndexRef.current = closestIndex;
    };

    window.addEventListener('wheel', handleWheel, { passive: false });
    window.addEventListener('touchstart', handleTouchStart, { passive: true });
    window.addEventListener('touchend', handleTouchEnd, { passive: true });
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('wheel', handleWheel);
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchend', handleTouchEnd);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div className="bg-neutral-950 min-h-screen relative">
      {/* Ambient background for blurry glass effects */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-25">
        <img 
          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop" 
          alt="" 
          className="w-full h-full object-cover filter blur-3xl scale-125"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/60 via-transparent to-neutral-950/80" />
      </div>

      <div className="relative z-10">
        <Navbar theme="light" />
        
        {/* Pinned 1000vh Interactive Scroll Experience on all devices */}
        <div ref={containerRef} className="h-[1000vh] relative">
          <div className="sticky top-0 h-screen w-full overflow-hidden">
            
            {/* Page 1 (Hero) */}
            <motion.div 
              style={{ 
                opacity: page1Opacity, 
                y: page1Y, 
                scale: page1Scale,
                pointerEvents: page1Pointer 
              }} 
              className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden will-change-[transform,opacity]"
            >
              <Hero />
            </motion.div>

            {/* Page 2 (Destinations) */}
            <motion.div 
              style={{ 
                opacity: page2Opacity, 
                y: page2Y,
                scale: page2Scale,
                pointerEvents: page2Pointer 
              }} 
              className="absolute inset-0 w-full h-full flex flex-col justify-center overflow-hidden will-change-[transform,opacity]"
            >
               <Destinations progress={destinationsProgress} />
            </motion.div>

            {/* Page 3 (Featured) */}
            <motion.div 
              style={{ 
                opacity: page3Opacity, 
                y: page3Y,
                scale: page3Scale,
                pointerEvents: page3Pointer 
              }} 
              className="absolute inset-0 w-full h-full flex flex-col justify-center overflow-hidden will-change-[transform,opacity]"
            >
              <Featured progress={featuredProgress} />
            </motion.div>

            {/* Page 4 (Testimonials) */}
            <motion.div 
              style={{ 
                opacity: page4Opacity, 
                y: page4Y,
                scale: page4Scale,
                pointerEvents: page4Pointer 
              }} 
              className="absolute inset-0 w-full h-full flex flex-col justify-center overflow-hidden will-change-[transform,opacity]"
            >
              <Testimonials progress={testimonialsProgress} />
            </motion.div>
            
          </div>
        </div>

        <Footer theme="dark" />
      </div>
    </div>
  );
}
