import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import DestinationsGrid from '../components/DestinationsGrid';
import { motion } from 'motion/react';
import { MapPin, ArrowDown, Compass, Sparkles, Wind, ArrowRight, Calendar, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function DestinationsPage() {
  return (
    <div className="relative min-h-screen text-white selection:bg-white/30 selection:text-white">
      {/* Global Background Image */}
      <div className="fixed inset-0 z-[-1]">
        <img 
          src="https://images.unsplash.com/photo-1473116763249-2faaef81ccda?q=80&w=2096&auto=format&fit=crop" 
          alt="Mountains Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-neutral-950/60 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/80 via-transparent to-neutral-950/90" />
      </div>

      <Navbar theme="light" />
      
      {/* Hero Section */}
      <div className="relative h-[70vh] min-h-[600px] flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0" style={{ maskImage: 'linear-gradient(to bottom, black 60%, transparent 100%)', WebkitMaskImage: 'linear-gradient(to bottom, black 60%, transparent 100%)' }}>
          <motion.img 
            initial={{ scale: 1.1 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            src="https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?q=80&w=2070&auto=format&fit=crop" 
            alt="Beautiful coastal destination" 
            className="w-full h-full object-cover opacity-80 mix-blend-luminosity"
          />
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-transparent" />
        </div>

        <div className="relative z-10 pt-32 pb-8 px-6 sm:px-12 lg:px-20 flex flex-col items-center justify-center text-center mt-12">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-4xl mx-auto"
          >
            <span className="inline-block py-1 px-3 border border-white/40 rounded-full text-white/90 text-xs font-semibold tracking-[0.2em] uppercase mb-6 backdrop-blur-sm">
              Discover the World
            </span>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif mb-6 text-white leading-[1.1] tracking-tight drop-shadow-sm">
              Explore The <span className="italic text-white/90">Unseen</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 font-medium max-w-2xl mx-auto mb-12 drop-shadow-sm leading-relaxed">
              Unlock extraordinary destinations and create memories that will last a lifetime, curated specifically for the discerning traveler.
            </p>
            
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
              className="w-12 h-12 rounded-full border border-white/30 flex items-center justify-center mx-auto text-white shadow-sm backdrop-blur-sm"
            >
              <ArrowDown className="w-5 h-5" />
            </motion.div>
          </motion.div>
        </div>
      </div>
      
      {/* Grid Section */}
      <div className="relative z-20 pb-16 pt-8">
        <DestinationsGrid theme="dark" />
      </div>

      {/* Editorial Section */}
      <div className="relative z-10 px-6 sm:px-12 lg:px-20 py-24 sm:py-32 lg:py-36 max-w-[1440px] mx-auto">
        <div className="space-y-24 sm:space-y-28 lg:space-y-32">
          
          {/* Signature Escapes Showcase - Four Perspectives of Travel */}
          <div className="space-y-8 sm:space-y-10">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-white/15">
              <div>
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-white/60 block mb-2">
                  Signature Collections
                </span>
                <h3 className="text-3xl sm:text-4xl lg:text-5xl font-serif text-white">
                  Four Perspectives of Travel
                </h3>
              </div>
              <p className="text-white/70 text-sm sm:text-base max-w-md font-light">
                Hand-selected themes tailored for romantic getaways, cultural voyages, and restorative alpine retreats.
              </p>
            </div>

            {/* Refined Compact Alternating Luxury Magazine Showcase Layout */}
            <div className="max-w-5xl mx-auto space-y-5 sm:space-y-6">
              
              {/* Escape 1 - Image Left, Story Right */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="group rounded-xl sm:rounded-2xl overflow-hidden border border-white/15 hover:border-white/30 bg-neutral-900/80 backdrop-blur-md shadow-lg hover:shadow-black/50 transition-all duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch h-full">
                  {/* Visual Stage */}
                  <div className="relative lg:col-span-5 h-[230px] sm:h-[260px] lg:h-[410px] xl:h-[380px] w-full overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=1986&auto=format&fit=crop" 
                      alt="Riviera & Coastal Cliffs" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#15223c] via-transparent to-black/35 lg:bg-gradient-to-r lg:from-transparent lg:via-black/20 lg:to-[#182642]" />
                    
                    {/* Top Bar Floating Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-amber-300/40 text-[10px] font-bold uppercase tracking-wider text-amber-300 shadow-md">
                        Mediterranean Escapes
                      </span>
                      <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[10px] text-white/90 font-medium shadow-md">
                        <Calendar className="w-3 h-3 text-white/70" />
                        <span>May — Oct</span>
                      </div>
                    </div>

                    {/* Geographic Tag */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white/90 text-[11px] font-medium tracking-wide drop-shadow-md bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                      <MapPin className="w-3 h-3 text-amber-300 shrink-0" />
                      <span>Amalfi &amp; Cyclades</span>
                    </div>
                  </div>

                  {/* Editorial Body */}
                  <div className="lg:col-span-7 p-6 sm:p-7 lg:p-7 xl:p-8 flex flex-col justify-between space-y-4 lg:h-[410px] xl:h-[380px] bg-gradient-to-br from-[#182642] via-[#131d33] to-[#0d1627] border-t lg:border-t-0 lg:border-l border-amber-400/20">
                    <div className="space-y-3.5">
                      {/* Clean Eyebrow and Sequence Indicator */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                          <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-300">
                            Amalfi Coast &amp; Cyclades
                          </span>
                        </div>
                        <span className="text-white/20 font-serif text-xl font-light tracking-widest select-none">
                          01
                        </span>
                      </div>

                      {/* Headline */}
                      <h4 className="text-xl sm:text-2xl lg:text-[25px] xl:text-[26px] font-serif text-white tracking-tight leading-snug group-hover:text-amber-100 transition-colors">
                        Riviera &amp; Coastal Cliffs
                      </h4>

                      {/* Narrative */}
                      <p className="text-zinc-200 text-[14.5px] sm:text-[15.5px] lg:text-[16px] xl:text-[16.5px] leading-relaxed font-normal opacity-95">
                        Sail azure Mediterranean waters aboard private vintage yachts, navigating dramatic cliffsides from Positano to Santorini. Savor sommelier-guided vineyard tastings at sunset, retire to secluded clifftop sanctuaries, and indulge in Michelin-calibrated seafood dining beneath candlelit lemon arbors overlooking panoramic seascapes.
                      </p>
                    </div>

                    {/* Curated Highlights Chips */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Private Yacht Charter
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Cliffside Dining
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Boutique Villa Stays
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Sommelier Tastings
                      </span>
                    </div>

                    {/* Professional Footer Bar with Action */}
                    <div className="pt-3.5 border-t border-white/10 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <Clock className="w-3.5 h-3.5 text-amber-400/70" />
                        <span className="font-medium">8 — 12 Days Journey</span>
                      </div>
                      <Link 
                        to="/packages" 
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-white text-neutral-950 hover:bg-amber-100 text-xs font-bold tracking-wide shadow-sm hover:shadow-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <span>Explore Itineraries</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </Link>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Escape 2 - Story Left, Image Right */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="group rounded-xl sm:rounded-2xl overflow-hidden border border-white/15 hover:border-white/30 bg-neutral-900/80 backdrop-blur-md shadow-lg hover:shadow-black/50 transition-all duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch h-full">
                  {/* Editorial Body (First on Desktop) */}
                  <div className="order-2 lg:order-1 lg:col-span-7 p-6 sm:p-7 lg:p-7 xl:p-8 flex flex-col justify-between space-y-4 lg:h-[410px] xl:h-[380px] bg-gradient-to-br from-[#1f224a] via-[#17193b] to-[#101229] border-t lg:border-t-0 lg:border-r border-sky-400/20">
                    <div className="space-y-3.5">
                      {/* Clean Eyebrow and Sequence Indicator */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                          <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.18em] text-sky-300">
                            Paris, Vienna &amp; Florence
                          </span>
                        </div>
                        <span className="text-white/20 font-serif text-xl font-light tracking-widest select-none">
                          02
                        </span>
                      </div>

                      {/* Headline */}
                      <h4 className="text-xl sm:text-2xl lg:text-[25px] xl:text-[26px] font-serif text-white tracking-tight leading-snug group-hover:text-sky-100 transition-colors">
                        Historic Grand Capitals
                      </h4>

                      {/* Narrative */}
                      <p className="text-zinc-200 text-[14.5px] sm:text-[15.5px] lg:text-[16px] xl:text-[16.5px] leading-relaxed font-normal opacity-95">
                        Immerse yourself in timeless European grandeur with private after-hours museum viewings, VIP opera boxes, and bespoke palace suite residencies. Journey through historic cobblestone quarters with master historians, savoring world-renowned gastronomic tables and private chauffeured transfers across storied cultural capitals.
                      </p>
                    </div>

                    {/* Curated Highlights Chips */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        After-Hours Access
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Palace Hotel Suites
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Curator-Led Tours
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Private Chauffeur
                      </span>
                    </div>

                    {/* Professional Footer Bar with Action */}
                    <div className="pt-3.5 border-t border-white/10 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <Clock className="w-3.5 h-3.5 text-sky-400/70" />
                        <span className="font-medium">7 — 14 Days Journey</span>
                      </div>
                      <Link 
                        to="/packages" 
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-white text-neutral-950 hover:bg-sky-100 text-xs font-bold tracking-wide shadow-sm hover:shadow-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <span>Explore Itineraries</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </Link>
                    </div>
                  </div>

                  {/* Visual Stage */}
                  <div className="order-1 lg:order-2 relative lg:col-span-5 h-[230px] sm:h-[260px] lg:h-[410px] xl:h-[380px] w-full overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=2070&auto=format&fit=crop" 
                      alt="Historic Grand Capitals" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#1d2044] via-transparent to-black/35 lg:bg-gradient-to-l lg:from-transparent lg:via-black/20 lg:to-[#1f224a]" />
                    
                    {/* Top Bar Floating Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-sky-300/40 text-[10px] font-bold uppercase tracking-wider text-sky-300 shadow-md">
                        Urban Heritage
                      </span>
                      <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[10px] text-white/90 font-medium shadow-md">
                        <Calendar className="w-3 h-3 text-white/70" />
                        <span>Year-Round</span>
                      </div>
                    </div>

                    {/* Geographic Tag */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white/90 text-[11px] font-medium tracking-wide drop-shadow-md bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                      <MapPin className="w-3 h-3 text-sky-300 shrink-0" />
                      <span>Paris, Vienna &amp; Florence</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Escape 3 - Image Left, Story Right */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="group rounded-xl sm:rounded-2xl overflow-hidden border border-white/15 hover:border-white/30 bg-neutral-900/80 backdrop-blur-md shadow-lg hover:shadow-black/50 transition-all duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch h-full">
                  {/* Visual Stage */}
                  <div className="relative lg:col-span-5 h-[230px] sm:h-[260px] lg:h-[410px] xl:h-[380px] w-full overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1974&auto=format&fit=crop" 
                      alt="Glacial Valleys & Peaks" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#10372b] via-transparent to-black/35 lg:bg-gradient-to-r lg:from-transparent lg:via-black/20 lg:to-[#123d30]" />
                    
                    {/* Top Bar Floating Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-emerald-300/40 text-[10px] font-bold uppercase tracking-wider text-emerald-300 shadow-md">
                        Alpine &amp; Peaks
                      </span>
                      <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[10px] text-white/90 font-medium shadow-md">
                        <Calendar className="w-3 h-3 text-white/70" />
                        <span>Dec — Sep</span>
                      </div>
                    </div>

                    {/* Geographic Tag */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white/90 text-[11px] font-medium tracking-wide drop-shadow-md bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                      <MapPin className="w-3 h-3 text-emerald-300 shrink-0" />
                      <span>Swiss Alps &amp; Dolomites</span>
                    </div>
                  </div>

                  {/* Editorial Body */}
                  <div className="lg:col-span-7 p-6 sm:p-7 lg:p-7 xl:p-8 flex flex-col justify-between space-y-4 lg:h-[410px] xl:h-[380px] bg-gradient-to-br from-[#123d30] via-[#0c2e23] to-[#082018] border-t lg:border-t-0 lg:border-l border-emerald-400/20">
                    <div className="space-y-3.5">
                      {/* Clean Eyebrow and Sequence Indicator */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-300">
                            Swiss Alps &amp; Dolomites
                          </span>
                        </div>
                        <span className="text-white/20 font-serif text-xl font-light tracking-widest select-none">
                          03
                        </span>
                      </div>

                      {/* Headline */}
                      <h4 className="text-xl sm:text-2xl lg:text-[25px] xl:text-[26px] font-serif text-white tracking-tight leading-snug group-hover:text-emerald-100 transition-colors">
                        Glacial Valleys &amp; Peaks
                      </h4>

                      {/* Narrative */}
                      <p className="text-zinc-200 text-[14.5px] sm:text-[15.5px] lg:text-[16px] xl:text-[16.5px] leading-relaxed font-normal opacity-95">
                        Traverse pristine alpine valleys on panoramic cogwheel trains and private helicopter glacier expeditions across towering snowcapped peaks. Unwind in heated cedar infinity baths overlooking dramatic summits, savor fireside gourmet alpine cuisine, and explore secluded trails with certified private mountain guides.
                      </p>
                    </div>

                    {/* Curated Highlights Chips */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Panoramic Rail
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Glacier Heli-Flights
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Alpine Spas
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Private Mountain Guide
                      </span>
                    </div>

                    {/* Professional Footer Bar with Action */}
                    <div className="pt-3.5 border-t border-white/10 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <Clock className="w-3.5 h-3.5 text-emerald-400/70" />
                        <span className="font-medium">6 — 10 Days Journey</span>
                      </div>
                      <Link 
                        to="/packages" 
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-white text-neutral-950 hover:bg-emerald-100 text-xs font-bold tracking-wide shadow-sm hover:shadow-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <span>Explore Itineraries</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </Link>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Escape 4 - Story Left, Image Right */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="group rounded-xl sm:rounded-2xl overflow-hidden border border-white/15 hover:border-white/30 bg-neutral-900/80 backdrop-blur-md shadow-lg hover:shadow-black/50 transition-all duration-300"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch h-full">
                  {/* Editorial Body (First on Desktop) */}
                  <div className="order-2 lg:order-1 lg:col-span-7 p-6 sm:p-7 lg:p-7 xl:p-8 flex flex-col justify-between space-y-4 lg:h-[410px] xl:h-[380px] bg-gradient-to-br from-[#103d42] via-[#0b2d31] to-[#072023] border-t lg:border-t-0 lg:border-r border-teal-400/20">
                    <div className="space-y-3.5">
                      {/* Clean Eyebrow and Sequence Indicator */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                          <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-[0.18em] text-teal-300">
                            Costa Rica &amp; Bali
                          </span>
                        </div>
                        <span className="text-white/20 font-serif text-xl font-light tracking-widest select-none">
                          04
                        </span>
                      </div>

                      {/* Headline */}
                      <h4 className="text-xl sm:text-2xl lg:text-[25px] xl:text-[26px] font-serif text-white tracking-tight leading-snug group-hover:text-teal-100 transition-colors">
                        Canopy &amp; Island Retreats
                      </h4>

                      {/* Narrative */}
                      <p className="text-zinc-200 text-[14.5px] sm:text-[15.5px] lg:text-[16px] xl:text-[16.5px] leading-relaxed font-normal opacity-95">
                        Recharge within architecturally stunning eco-villas nestled high above biodiverse rainforest canopies and tranquil sacred coastlines. Experience restorative open-air thermal spring therapies, private naturalist-guided wildlife treks, and regenerative farm-to-table culinary journeys designed for deep rejuvenation.
                      </p>
                    </div>

                    {/* Curated Highlights Chips */}
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Naturalist Safaris
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Canopy Treehouses
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Thermal Springs
                      </span>
                      <span className="px-3 py-1 rounded-full bg-white/[0.05] border border-white/10 text-[10.5px] lg:text-[11px] text-neutral-300 font-normal">
                        Regenerative Dining
                      </span>
                    </div>

                    {/* Professional Footer Bar with Action */}
                    <div className="pt-3.5 border-t border-white/10 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-neutral-400">
                        <Clock className="w-3.5 h-3.5 text-teal-400/70" />
                        <span className="font-medium">9 — 14 Days Journey</span>
                      </div>
                      <Link 
                        to="/packages" 
                        className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full bg-white text-neutral-950 hover:bg-teal-100 text-xs font-bold tracking-wide shadow-sm hover:shadow-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <span>Explore Itineraries</span>
                        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                      </Link>
                    </div>
                  </div>

                  {/* Visual Stage */}
                  <div className="order-1 lg:order-2 relative lg:col-span-5 h-[230px] sm:h-[260px] lg:h-[410px] xl:h-[380px] w-full overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1507608616759-54f48f0af0ee?q=80&w=1974&auto=format&fit=crop" 
                      alt="Canopy & Island Retreats" 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0e373c] via-transparent to-black/35 lg:bg-gradient-to-l lg:from-transparent lg:via-black/20 lg:to-[#103d42]" />
                    
                    {/* Top Bar Floating Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-teal-300/40 text-[10px] font-bold uppercase tracking-wider text-teal-300 shadow-md">
                        Eco Sanctuaries
                      </span>
                      <div className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[10px] text-white/90 font-medium shadow-md">
                        <Calendar className="w-3 h-3 text-white/70" />
                        <span>Nov — May</span>
                      </div>
                    </div>

                    {/* Geographic Tag */}
                    <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white/90 text-[11px] font-medium tracking-wide drop-shadow-md bg-black/60 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/15">
                      <MapPin className="w-3 h-3 text-teal-300 shrink-0" />
                      <span>Costa Rica &amp; Bali</span>
                    </div>
                  </div>
                </div>
              </motion.div>

            </div>
          </div>

          {/* Our Philosophy & Three Pillars Bento Grid */}
          <div className="space-y-12 sm:space-y-16 pt-10 border-t border-white/15">
            {/* Section Header & Philosophy */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="text-center max-w-3xl mx-auto space-y-6"
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-bold uppercase tracking-[0.2em] text-white/90 shadow-sm">
                <Compass className="w-3.5 h-3.5 text-white/80" />
                <span>Our Philosophy</span>
              </div>
              
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-serif text-white tracking-tight leading-[1.15]">
                Curated for the <span className="italic text-white/60">curious soul.</span>
              </h2>
              
              <p className="text-white/80 text-base sm:text-lg lg:text-xl leading-relaxed font-light">
                We traverse the globe to discover hidden sanctuaries and timeless landmarks, meticulously crafting bespoke itineraries that balance transcendent wonder with uncompromised ease.
              </p>
            </motion.div>

            {/* Three Pillars Bento Grid */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8"
            >
              {/* Pillar 1 */}
              <div className="group bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/25 rounded-[2rem] p-8 sm:p-10 shadow-2xl hover:bg-white/[0.07] transition-all duration-500 flex flex-col justify-between">
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center mb-6 group-hover:scale-105 group-hover:bg-white/15 transition-all duration-300">
                    <Compass className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-serif text-white mb-3 tracking-tight">Expertly Guided</h3>
                  <p className="text-white/70 leading-relaxed text-sm sm:text-base font-light">
                    Vetted resident specialists offer rare cultural access, historical mastery, and privileged perspectives unavailable in ordinary travel.
                  </p>
                </div>
                <div className="pt-6 mt-6 border-t border-white/10 flex items-center text-xs font-semibold uppercase tracking-wider text-white/50 group-hover:text-white/90 transition-colors">
                  <span>Authentic Perspective</span>
                </div>
              </div>

              {/* Pillar 2 */}
              <div className="group bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/25 rounded-[2rem] p-8 sm:p-10 shadow-2xl hover:bg-white/[0.07] transition-all duration-500 flex flex-col justify-between">
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center mb-6 group-hover:scale-105 group-hover:bg-white/15 transition-all duration-300">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-serif text-white mb-3 tracking-tight">Unforgettable Moments</h3>
                  <p className="text-white/70 leading-relaxed text-sm sm:text-base font-light">
                    From after-hours museum galleries to private catamaran charters on secluded coves, each encounter is designed as a lifelong memory.
                  </p>
                </div>
                <div className="pt-6 mt-6 border-t border-white/10 flex items-center text-xs font-semibold uppercase tracking-wider text-white/50 group-hover:text-white/90 transition-colors">
                  <span>VIP &amp; Secluded Access</span>
                </div>
              </div>

              {/* Pillar 3 */}
              <div className="group bg-white/[0.04] backdrop-blur-xl border border-white/10 hover:border-white/25 rounded-[2rem] p-8 sm:p-10 shadow-2xl hover:bg-white/[0.07] transition-all duration-500 flex flex-col justify-between">
                <div>
                  <div className="w-14 h-14 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-center mb-6 group-hover:scale-105 group-hover:bg-white/15 transition-all duration-300">
                    <Wind className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-2xl font-serif text-white mb-3 tracking-tight">Seamless Travel</h3>
                  <p className="text-white/70 leading-relaxed text-sm sm:text-base font-light">
                    Direct flight bookings, expedited visa paperwork, and chauffeured transfers are orchestrated flawlessly so you can simply unwind.
                  </p>
                </div>
                <div className="pt-6 mt-6 border-t border-white/10 flex items-center text-xs font-semibold uppercase tracking-wider text-white/50 group-hover:text-white/90 transition-colors">
                  <span>End-to-End Concierge</span>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>

      {/* Interlinking CTA Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-20 pb-24">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-[2.5rem] p-8 md:p-14 text-center text-white relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl mx-auto space-y-6">
            <span className="inline-block px-4 py-1.5 rounded-full bg-white/20 text-xs font-bold uppercase tracking-widest text-white/90">
              Your Next Journey Awaits
            </span>
            <h2 className="text-3xl md:text-5xl font-serif">Ready to Explore These Escapes?</h2>
            <p className="text-white/80 text-base md:text-lg leading-relaxed">
              Discover our all-inclusive tour packages or request custom visa assistance tailored for your next destination.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
              <Link
                to="/packages"
                className="bg-white text-neutral-950 font-bold px-8 py-4 rounded-full text-xs uppercase tracking-wider hover:bg-white/90 transition-all shadow-lg flex items-center gap-2 group"
              >
                <span>View Tour Packages</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                to="/visa"
                className="bg-white/10 border border-white/30 text-white font-bold px-8 py-4 rounded-full text-xs uppercase tracking-wider hover:bg-white/20 transition-all"
              >
                Check Visa Requirements
              </Link>
              <Link
                to="/contact"
                className="bg-white/10 border border-white/30 text-white font-bold px-8 py-4 rounded-full text-xs uppercase tracking-wider hover:bg-white/20 transition-all"
              >
                Inquire Directly
              </Link>
            </div>
          </div>
        </div>
      </div>

      <Footer theme="dark" />
    </div>
  );
}
