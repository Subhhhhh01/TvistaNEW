import React, { useState, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'motion/react';
import { Camera, MapPin, Maximize2, X, Compass, Wind, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useData } from '../context/DataContext';

type GalleryItemType = {
  id: number;
  title: string;
  location: string;
  desc: string;
  image: string;
};

const GALLERY_ITEMS: GalleryItemType[] = [
  {
    id: 1,
    title: 'Oceanfront Overwater Villa',
    location: 'Maldives',
    desc: 'Step directly from your private deck into crystal clear turquoise waters. The ultimate tropical luxury and relaxation.',
    image: 'https://images.unsplash.com/photo-1439066615861-d1af74d74000?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 2,
    title: 'Alpine Sanctuary',
    location: 'Swiss Alps, Switzerland',
    desc: 'A luxurious mountain retreat offering breathtaking views. Warm up by the stone fireplace after a day exploring the peaks.',
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?q=80&w=2071&auto=format&fit=crop',
  },
  {
    id: 3,
    title: 'Lakeside Manor',
    location: 'Lake Como, Italy',
    desc: 'Experience classic European elegance by the lake. Featuring sprawling gardens and exquisite views of the water.',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 4,
    title: 'Misty Highland Estate',
    location: 'Scottish Highlands, UK',
    desc: 'Discover the raw beauty of the highlands. A historic estate surrounded by rolling hills, deep lochs, and a dramatic, moody sky.',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 5,
    title: 'Cliffside Village',
    location: 'Cinque Terre, Italy',
    desc: 'Wander through vibrant, pastel-colored houses perched precariously on the rugged cliffs overlooking the Mediterranean Sea.',
    image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=1986&auto=format&fit=crop',
  },
  {
    id: 6,
    title: 'Urban Penthouse',
    location: 'New York, USA',
    desc: 'Experience the city from above. A modern, glass-walled penthouse offering unparalleled, panoramic views of the iconic skyline.',
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 7,
    title: 'Santorini Sunset',
    location: 'Oia, Greece',
    desc: 'Breathtaking sunsets, pristine white architecture, and the deep blue of the Aegean Sea. A timeless Mediterranean dream.',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1974&auto=format&fit=crop',
  },
  {
    id: 8,
    title: 'Jungle Retreat',
    location: 'Bali, Indonesia',
    desc: 'A hidden sanctuary nestled deeply within the lush tropical rainforest. Reconnect with nature in absolute tranquility.',
    image: 'https://images.unsplash.com/photo-1507608616759-54f48f0af0ee?q=80&w=1974&auto=format&fit=crop',
  },
  {
    id: 9,
    title: 'Historic Canal House',
    location: 'Amsterdam, Netherlands',
    desc: 'Step back in time in a beautifully restored canal house. Experience the charm, history, and unique architecture of the city.',
    image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 10,
    title: 'Desert Luxury Pavilion',
    location: 'Dubai, UAE',
    desc: 'Modern marvels meeting golden desert dunes. An exclusive, luxury pavilion offering both seclusion and opulence.',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 11,
    title: 'Winter Wonderland Igloo',
    location: 'Lapland, Finland',
    desc: 'Cozy up in a glass igloo and watch the spectacular Northern Lights dance across the arctic sky from the comfort of your bed.',
    image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 12,
    title: 'Machu Picchu Ruins',
    location: 'Cusco Region, Peru',
    desc: 'Explore the ancient Incan citadel set high in the Andes Mountains. A testament to historical engineering and natural beauty.',
    image: 'https://images.unsplash.com/photo-1526392060635-9d6019884377?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 13,
    title: 'Cherry Blossom Gardens',
    location: 'Kyoto, Japan',
    desc: 'Wander through serene temples surrounded by beautiful, blooming sakura trees during the spring season.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 14,
    title: 'Bora Bora Overwater Bungalows',
    location: 'French Polynesia',
    desc: 'Wake up to the gentle sound of waves in a luxurious overwater bungalow, surrounded by vibrant coral reefs.',
    image: 'https://images.unsplash.com/photo-1502507858907-8840b17b686d?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 15,
    title: 'Serengeti Safari',
    location: 'Tanzania',
    desc: 'Experience the thrill of a lifetime observing majestic wildlife in their natural habitat across the vast African plains.',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=2068&auto=format&fit=crop',
  },
  {
    id: 16,
    title: 'Glacier National Park',
    location: 'Montana, USA',
    desc: 'Discover breathtaking alpine scenery, pristine lakes, and abundant wildlife in the heart of the Rocky Mountains.',
    image: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 17,
    title: 'Victoria Falls',
    location: 'Zambia/Zimbabwe',
    desc: 'Witness the raw power and spectacular beauty of one of the largest and most famous waterfalls in the world.',
    image: 'https://images.unsplash.com/photo-1603201236596-eb1a63eb0ede?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 18,
    title: 'Banff National Park',
    location: 'Alberta, Canada',
    desc: 'Marvel at turquoise glacial lakes, rugged mountain peaks, and dense pine forests in this picturesque national park.',
    image: 'https://images.unsplash.com/photo-1542614947-640a45e4e73b?q=80&w=2070&auto=format&fit=crop',
  }
];

const InteractiveGalleryItem: React.FC<{ item: GalleryItemType, index: number, onImageClick: (item: GalleryItemType) => void }> = ({ item, index, onImageClick }) => {
  const ref = useRef<HTMLDivElement>(null);
  
  // Create varying aspect ratios for masonry effect
  const aspectRatios = [
    "aspect-[4/5]",
    "aspect-[3/4]",
    "aspect-[4/6]",
    "aspect-square",
    "aspect-[3/5]"
  ];
  
  const aspectRatio = aspectRatios[index % aspectRatios.length];

  return (
    <motion.div 
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className={`relative overflow-hidden cursor-pointer group/image rounded-2xl w-full inline-block break-inside-avoid mb-8 ${aspectRatio}`}
      onClick={() => onImageClick(item)}
    >
      <img 
        src={item.image} 
        alt={item.title} 
        className="w-full h-full object-cover group-hover/image:scale-110 transition-transform duration-[2s] ease-out"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-80 group-hover/image:opacity-100 transition-opacity duration-700" />
      
      <div className="absolute inset-x-0 bottom-0 p-8 flex flex-col justify-end transform translate-y-4 group-hover/image:translate-y-0 transition-transform duration-700 ease-out">
        <div className="flex items-center gap-2 text-white/80 font-medium text-[10px] uppercase tracking-[0.2em] mb-3 opacity-0 group-hover/image:opacity-100 transition-opacity duration-700 delay-100">
          <MapPin className="w-3.5 h-3.5 text-white" />
          {item.location}
        </div>
        
        <h2 className="text-2xl md:text-3xl font-serif text-white mb-2 leading-tight">
          {item.title}
        </h2>
        
        <div className="h-0 overflow-hidden group-hover/image:h-auto transition-all duration-700">
          <p className="text-white/70 leading-relaxed text-sm mt-3 line-clamp-2 opacity-0 group-hover/image:opacity-100 transition-opacity duration-700 delay-200">
            {item.desc}
          </p>
        </div>
      </div>
      
      <div className="absolute top-6 right-6 opacity-0 group-hover/image:opacity-100 transition-opacity duration-700 delay-100">
        <div className="bg-white/20 backdrop-blur-md p-3 rounded-full text-white transform scale-90 group-hover/image:scale-100 transition-all duration-700">
          <Maximize2 className="w-5 h-5" />
        </div>
      </div>
    </motion.div>
  );
};

export default function GalleryPage() {
  const { galleryItems } = useData();
  const itemsToDisplay = galleryItems && galleryItems.length > 0 ? galleryItems : GALLERY_ITEMS;
  const [selectedImage, setSelectedImage] = useState<GalleryItemType | null>(null);

  return (
    <div className="relative min-h-screen selection:bg-neutral-200">
      {/* Global Background Image */}
      <div className="fixed inset-0 z-[-1]">
        <img 
          src="https://images.unsplash.com/photo-1500382017468-9049fed747ef?q=80&w=2064&auto=format&fit=crop" 
          alt="Beautiful Sunrise Background" 
          className="w-full h-full object-cover opacity-90"
        />
        <div className="absolute inset-0 bg-white/30 backdrop-blur-sm" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/50 via-white/10 to-white/70" />
      </div>

      <Navbar theme="light" />
      
      {/* Hero Section */}
      <div className="relative pt-32 pb-20 px-6 sm:px-12 lg:px-20 text-[#1C1917] min-h-[70vh] flex flex-col items-center justify-center overflow-hidden">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 text-center max-w-4xl mx-auto flex flex-col items-center"
        >
          <span className="inline-block py-1.5 px-4 border border-neutral-300 rounded-full text-neutral-600 text-xs font-semibold tracking-[0.2em] uppercase mb-8 bg-white/40 backdrop-blur-sm shadow-sm">
            Visual Journey
          </span>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif mb-8 text-[#1C1917] tracking-tight leading-[1.1]">
            Curated <span className="italic text-[#57534E]">Perspectives</span>
          </h1>
          <p className="text-lg md:text-xl text-[#44403C] mx-auto font-normal leading-relaxed max-w-2xl">
            A visual journey through the world's most spectacular landscapes and architectural wonders. Discover the beauty of our featured destinations.
          </p>
        </motion.div>
      </div>

      {/* Gallery Grid */}
      <div className="max-w-[1600px] mx-auto px-6 sm:px-12 lg:px-20 pb-32">
        <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8 mt-12">
          {itemsToDisplay.map((item, index) => (
            <InteractiveGalleryItem 
              key={item.id} 
              item={item} 
              index={index} 
              onImageClick={setSelectedImage} 
            />
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-neutral-950/95 backdrop-blur-xl p-4 sm:p-8"
            onClick={() => setSelectedImage(null)}
          >
            <button 
              className="absolute top-6 right-6 z-10 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 p-4 rounded-full transition-colors"
              onClick={() => setSelectedImage(null)}
            >
              <X className="w-6 h-6" />
            </button>
            <motion.div 
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="relative max-w-7xl w-full max-h-[90vh] flex flex-col lg:flex-row bg-neutral-900 rounded-[2rem] overflow-hidden shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
               <div className="w-full lg:w-[70%] h-[50vh] lg:h-[85vh] relative">
                 <img src={selectedImage.image} alt={selectedImage.title} className="w-full h-full object-cover" />
                 <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-neutral-900"></div>
               </div>
               <div className="w-full lg:w-[30%] p-8 lg:p-12 flex flex-col justify-center bg-neutral-900 text-neutral-300">
                 <div className="flex items-center gap-3 text-neutral-500 font-medium text-xs uppercase tracking-[0.2em] mb-6">
                    <MapPin className="w-4 h-4 text-neutral-400" />
                    {selectedImage.location}
                  </div>
                  <h2 className="text-3xl lg:text-5xl font-serif text-white mb-6 leading-tight">
                    {selectedImage.title}
                  </h2>
                  <p className="text-neutral-400 leading-relaxed text-lg mb-12">
                    {selectedImage.desc}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-6 pt-8 border-t border-neutral-800 mb-8">
                    <div>
                       <p className="text-neutral-500 text-xs uppercase tracking-widest mb-1">Duration</p>
                       <p className="text-white font-medium">Available Year-round</p>
                    </div>
                    <div>
                       <p className="text-neutral-500 text-xs uppercase tracking-widest mb-1">Category</p>
                       <p className="text-white font-medium">Signature Collection</p>
                    </div>
                  </div>

                  <Link
                    to={`/contact?destination=${encodeURIComponent(selectedImage.title)}`}
                    className="w-full inline-flex items-center justify-center gap-2 bg-white text-neutral-950 font-bold py-3.5 px-6 rounded-full text-xs uppercase tracking-wider hover:bg-neutral-200 transition-colors shadow-lg group"
                  >
                    <span>Inquire About This Location</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </Link>
               </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer theme="light" />
    </div>
  );
}
