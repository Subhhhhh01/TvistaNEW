import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Newspaper, 
  Calendar, 
  Clock, 
  ArrowRight, 
  Search, 
  Tag, 
  Share2, 
  Check, 
  X, 
  BookOpen, 
  Sparkles, 
  Send, 
  Compass, 
  Globe2,
  ExternalLink,
  BookmarkCheck
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { NEWS_ARTICLES, NEWS_CATEGORIES, NewsArticle } from '../data/newsData';
import { useData } from '../context/DataContext';

export default function NewsPage() {
  const { newsArticles } = useData();
  const allArticles = newsArticles && newsArticles.length > 0 ? newsArticles : NEWS_ARTICLES;

  const [selectedCategory, setSelectedCategory] = useState<string>('All News');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeArticle, setActiveArticle] = useState<NewsArticle | null>(null);
  const [newsletterEmail, setNewsletterEmail] = useState<string>('');
  const [newsletterSuccess, setNewsletterSuccess] = useState<boolean>(false);
  const [copiedShare, setCopiedShare] = useState<boolean>(false);

  const filteredArticles = useMemo(() => {
    return allArticles.filter(article => {
      const matchesCategory = selectedCategory === 'All News' || article.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q ||
        article.title.toLowerCase().includes(q) ||
        article.excerpt.toLowerCase().includes(q) ||
        article.tags.some(t => t.toLowerCase().includes(q)) ||
        article.category.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [allArticles, selectedCategory, searchQuery]);

  // Separate featured article if available
  const featuredArticle = useMemo(() => {
    return allArticles.find(a => a.featured) || allArticles[0];
  }, [allArticles]);

  const handleShare = (article: NewsArticle) => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSuccess(true);
    setTimeout(() => {
      setNewsletterEmail('');
    }, 2000);
  };

  return (
    <div className="relative min-h-screen text-stone-900 selection:bg-sky-200 selection:text-sky-950 font-sans">
      {/* Global Background Image - High clarity visible journal backdrop */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?q=80&w=2070&auto=format&fit=crop" 
          alt="Travel Journal Background" 
          className="w-full h-full object-cover scale-105" 
        />
        {/* Luminous light atmosphere, clearly visible scenic image */}
        <div className="absolute inset-0 bg-white/45 backdrop-blur-[0.5px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/70 via-stone-50/25 to-white/75" />
      </div>

      <Navbar theme="light" />

      {/* Hero Section */}
      <div className="relative z-10 pt-32 sm:pt-36 pb-14 sm:pb-16 px-6 sm:px-12 lg:px-20 text-center flex flex-col items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sky-100 border border-sky-300/80 text-sky-900 text-xs font-semibold uppercase tracking-widest mb-6 shadow-xs backdrop-blur-md">
            <Newspaper className="w-3.5 h-3.5 text-sky-700" />
            <span>Tvista Travel Gazette &amp; Global Intelligence</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif text-stone-900 tracking-tight leading-[1.15] mb-5">
            Travel News &amp; <span className="italic font-light text-sky-800">Editorial Insights</span>
          </h1>

          <p className="text-base sm:text-lg md:text-xl text-stone-700 max-w-2xl mx-auto font-normal leading-relaxed">
            Stay informed with verified Schengen visa policy changes, airline developments, seasonal foliage forecasts, and insider destination guides curated by our global travel editors.
          </p>
        </motion.div>
      </div>

      {/* Main Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-20 pb-28">

        {/* Lead Featured Story Card */}
        {featuredArticle && !searchQuery && selectedCategory === 'All News' && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-14 rounded-2xl overflow-hidden border border-stone-200/90 bg-white/90 backdrop-blur-xl shadow-lg hover:border-sky-400/80 transition-all duration-300 hover:shadow-2xl hover:shadow-stone-900/10"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
              <div className="relative lg:col-span-7 h-72 sm:h-96 lg:h-auto min-h-[320px] overflow-hidden">
                <img 
                  src={featuredArticle.coverImage} 
                  alt={featuredArticle.title} 
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-700 ease-out" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-black/20" />
                
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 rounded-full bg-sky-600 text-white font-bold text-xs uppercase tracking-wider shadow-md">
                    Featured Story
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 flex items-center gap-2 text-xs text-white bg-stone-900/70 backdrop-blur-md px-3 py-1 rounded-full border border-white/20">
                  <Globe2 className="w-3.5 h-3.5 text-sky-300" />
                  <span>{featuredArticle.relatedDestination}</span>
                </div>
              </div>

              <div className="lg:col-span-5 p-6 sm:p-8 lg:p-10 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-xs text-stone-500">
                    <span className="text-sky-700 font-bold uppercase tracking-wider">
                      {featuredArticle.category}
                    </span>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{featuredArticle.date}</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{featuredArticle.readTime}</span>
                    </div>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-serif text-stone-900 leading-snug">
                    {featuredArticle.title}
                  </h2>

                  <p className="text-sm text-stone-600 leading-relaxed">
                    {featuredArticle.excerpt}
                  </p>

                  {/* Highlights preview */}
                  <div className="pt-2 space-y-1.5">
                    {featuredArticle.keyHighlights.slice(0, 2).map((highlight, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-stone-700">
                        <BookmarkCheck className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2.5">
                    <img 
                      src={featuredArticle.author.avatar} 
                      alt={featuredArticle.author.name} 
                      className="w-8 h-8 rounded-full object-cover border border-stone-300"
                    />
                    <div>
                      <span className="text-xs font-semibold text-stone-900 block">{featuredArticle.author.name}</span>
                      <span className="text-[10px] text-stone-500">{featuredArticle.author.role}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveArticle(featuredArticle)}
                    className="px-4 py-2 rounded-full bg-stone-900 text-white hover:bg-sky-700 text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-sm shrink-0"
                  >
                    <span>Read Article</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* Search & Category Filter */}
        <div className="space-y-6 mb-12">
          {/* Search Input */}
          <div className="max-w-md mx-auto relative">
            <input 
              type="text"
              placeholder="Search news, visa rules, or destinations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-3 rounded-full bg-white/90 border border-stone-300 text-stone-900 placeholder-stone-400 text-sm focus:outline-none focus:border-sky-500 focus:bg-white transition-all shadow-xs backdrop-blur-md"
            />
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5">
            {NEWS_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all ${
                    isActive
                      ? 'bg-sky-600 text-white font-bold shadow-md shadow-sky-600/20 scale-105'
                      : 'bg-white/85 text-stone-700 hover:text-stone-950 hover:bg-white border border-stone-200/90 shadow-xs'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Articles Grid */}
        {filteredArticles.length === 0 ? (
          <div className="text-center py-20 bg-white/80 border border-stone-200/90 rounded-2xl p-8 max-w-xl mx-auto shadow-sm">
            <Compass className="w-12 h-12 text-stone-400 mx-auto mb-4" />
            <h3 className="text-xl font-serif text-stone-900 mb-2">No articles matched your criteria</h3>
            <p className="text-stone-600 text-sm mb-6">
              Try searching with another keyword or explore all categories.
            </p>
            <button
              onClick={() => { setSelectedCategory('All News'); setSearchQuery(''); }}
              className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-xs font-bold uppercase tracking-wider hover:bg-sky-700 transition-colors shadow-sm"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article, index) => (
              <motion.article
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="group rounded-2xl overflow-hidden border border-stone-200/90 hover:border-sky-400/80 bg-white/90 backdrop-blur-xl shadow-md hover:shadow-xl hover:shadow-stone-900/10 flex flex-col justify-between transition-all duration-300"
              >
                {/* Visual Image */}
                <div className="relative h-52 w-full overflow-hidden">
                  <img 
                    src={article.coverImage} 
                    alt={article.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-black/20" />

                  <div className="absolute top-3.5 left-3.5">
                    <span className="px-2.5 py-0.5 rounded-full bg-stone-900/80 backdrop-blur-md border border-white/20 text-[11px] font-semibold text-sky-200 uppercase tracking-wider">
                      {article.category}
                    </span>
                  </div>

                  <div className="absolute bottom-3.5 right-3.5">
                    <span className="px-2 py-0.5 rounded-md bg-stone-900/70 backdrop-blur-md text-[10px] text-white">
                      {article.readTime}
                    </span>
                  </div>
                </div>

                {/* Body Text */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2.5">
                    <div className="flex items-center gap-2 text-[11px] text-stone-500">
                      <Calendar className="w-3 h-3 text-sky-600" />
                      <span>{article.date}</span>
                    </div>

                    <h3 className="text-xl font-serif text-stone-900 group-hover:text-sky-800 transition-colors leading-snug line-clamp-2">
                      {article.title}
                    </h3>

                    <p className="text-xs sm:text-sm text-stone-600 leading-relaxed line-clamp-3">
                      {article.excerpt}
                    </p>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {article.tags.slice(0, 3).map((tag, tIdx) => (
                      <span key={tIdx} className="px-2 py-0.5 rounded-full bg-stone-100 border border-stone-200 text-[10px] text-stone-600">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  {/* Card Footer */}
                  <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img 
                        src={article.author.avatar} 
                        alt={article.author.name} 
                        className="w-6 h-6 rounded-full object-cover border border-stone-300"
                      />
                      <span className="text-xs text-stone-700 font-medium truncate max-w-[120px]">
                        {article.author.name}
                      </span>
                    </div>

                    <button
                      onClick={() => setActiveArticle(article)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-sky-700 hover:text-sky-900 group-hover:translate-x-0.5 transition-all"
                    >
                      <span>Read Story</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>
        )}

        {/* Newsletter Subscription Gazette */}
        <div className="mt-20 p-8 sm:p-12 rounded-2xl bg-gradient-to-br from-white/95 via-sky-50/70 to-stone-50/90 border border-sky-300/80 backdrop-blur-xl shadow-lg relative overflow-hidden">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center mx-auto border border-sky-300">
              <Newspaper className="w-6 h-6" />
            </div>

            <h3 className="text-2xl sm:text-3xl font-serif text-stone-900">
              Subscribe to the Tvista Travel Gazette
            </h3>

            <p className="text-sm text-stone-600 leading-relaxed">
              Receive monthly dossiers on changing visa policies, seasonal private itinerary releases, and unadvertised promotional deals directly to your inbox.
            </p>

            {newsletterSuccess ? (
              <div className="p-4 rounded-xl bg-emerald-100 border border-emerald-300 text-emerald-800 text-sm flex items-center justify-center gap-2">
                <Check className="w-4 h-4" />
                <span>Thank you! You are now subscribed to our private travel dispatch.</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto pt-2">
                <input 
                  type="email"
                  required
                  placeholder="Enter your email address..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-full bg-white border border-stone-300 text-stone-900 placeholder-stone-400 text-sm focus:outline-none focus:border-sky-500 shadow-xs"
                />
                <button
                  type="submit"
                  className="px-6 py-3 rounded-full bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs uppercase tracking-wider shadow-sm transition-all active:scale-[0.98] shrink-0"
                >
                  Subscribe
                </button>
              </form>
            )}

            <span className="text-[11px] text-stone-500 block">
              We respect your privacy. Unsubscribe at any time with one click.
            </span>
          </div>
        </div>

      </div>

      {/* Full Article Reader Modal */}
      <AnimatePresence>
        {activeArticle && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveArticle(null)}
              className="fixed inset-0 bg-stone-950/60 backdrop-blur-sm"
            />

            <motion.div
              initial={{ scale: 0.96, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 20 }}
              className="relative z-10 w-full max-w-3xl bg-white border border-stone-200 rounded-2xl shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col text-stone-900"
            >
              {/* Header Cover */}
              <div className="relative h-64 sm:h-72 w-full shrink-0">
                <img 
                  src={activeArticle.coverImage} 
                  alt={activeArticle.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/30" />
                
                <button
                  onClick={() => setActiveArticle(null)}
                  className="absolute top-4 right-4 text-white p-2 rounded-full bg-stone-900/60 hover:bg-stone-900/90 backdrop-blur-md transition-colors"
                  aria-label="Close reader"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="absolute bottom-4 left-6 right-6">
                  <span className="px-3 py-1 rounded-full bg-sky-600 text-white font-bold text-xs uppercase tracking-wider mb-2 inline-block shadow-sm">
                    {activeArticle.category}
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-serif text-white drop-shadow-md">
                    {activeArticle.title}
                  </h2>
                </div>
              </div>

              {/* Scrollable Reader Content */}
              <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
                
                {/* Meta info */}
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-stone-200 text-xs text-stone-500">
                  <div className="flex items-center gap-3">
                    <img 
                      src={activeArticle.author.avatar} 
                      alt={activeArticle.author.name} 
                      className="w-10 h-10 rounded-full object-cover border border-stone-300"
                    />
                    <div>
                      <span className="text-sm font-semibold text-stone-900 block">{activeArticle.author.name}</span>
                      <span className="text-xs text-stone-500">{activeArticle.author.role}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-sky-600" />
                      <span>{activeArticle.date}</span>
                    </div>
                    <span>•</span>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-sky-600" />
                      <span>{activeArticle.readTime}</span>
                    </div>
                    <button
                      onClick={() => handleShare(activeArticle)}
                      className="p-1.5 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                      title="Share Article"
                      aria-label="Share"
                    >
                      {copiedShare ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Key Highlights Callout */}
                <div className="p-4 sm:p-5 rounded-xl bg-sky-50 border border-sky-200 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-sky-800 uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                    <span>Executive Summary &amp; Key Highlights</span>
                  </div>
                  <ul className="space-y-1.5 text-xs sm:text-sm text-stone-700">
                    {activeArticle.keyHighlights.map((point, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="text-sky-600 font-bold">•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Excerpt Lead */}
                <p className="text-base sm:text-lg text-stone-800 font-serif italic leading-relaxed border-l-3 border-sky-600 pl-4 py-1">
                  "{activeArticle.excerpt}"
                </p>

                {/* Formatted Article Body */}
                <div className="prose max-w-none text-sm sm:text-[15px] leading-relaxed text-stone-700 space-y-4">
                  {activeArticle.content.trim().split('\n\n').map((paragraph, pIdx) => {
                    if (paragraph.startsWith('### ')) {
                      return (
                        <h4 key={pIdx} className="text-xl font-serif text-stone-900 pt-3 pb-1">
                          {paragraph.replace('### ', '')}
                        </h4>
                      );
                    }
                    if (paragraph.startsWith('> ')) {
                      return (
                        <blockquote key={pIdx} className="p-4 rounded-lg bg-amber-50/80 border-l-4 border-amber-500 text-sm text-amber-950 italic my-3">
                          {paragraph.replace('> ', '')}
                        </blockquote>
                      );
                    }
                    if (paragraph.startsWith('1. ') || paragraph.startsWith('- ')) {
                      return (
                        <div key={pIdx} className="pl-4 space-y-1 text-sm text-stone-700">
                          {paragraph.split('\n').map((line, lIdx) => (
                            <p key={lIdx}>{line}</p>
                          ))}
                        </div>
                      );
                    }
                    return (
                      <p key={pIdx} className="leading-relaxed">
                        {paragraph}
                      </p>
                    );
                  })}
                </div>

                {/* Article Footer & Actions */}
                <div className="pt-6 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex flex-wrap gap-1.5">
                    {activeArticle.tags.map((tag, tIdx) => (
                      <span key={tIdx} className="px-3 py-1 rounded-full bg-stone-100 border border-stone-200 text-xs text-stone-600">
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-3 w-full sm:w-auto">
                    <Link
                      to="/packages"
                      onClick={() => setActiveArticle(null)}
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-full bg-stone-900 text-white font-bold text-xs uppercase tracking-wider hover:bg-sky-700 transition-colors text-center shadow-xs"
                    >
                      View Holiday Packages
                    </Link>
                    <a
                      href="https://wa.me/919830712357?text=Hello%20Tvista%20Holidays!%20I%20read%20your%20latest%20article%20and%20would%20like%20to%20inquire%20about%20travel%20options."
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 sm:flex-initial px-5 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition-colors text-center shadow-xs"
                    >
                      Ask Concierge
                    </a>
                  </div>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Footer theme="light" />
    </div>
  );
}
