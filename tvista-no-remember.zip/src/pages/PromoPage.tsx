import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Tag, 
  Sparkles, 
  Clock, 
  Copy, 
  Check, 
  ArrowRight, 
  ShieldCheck, 
  Send, 
  Gift, 
  Compass, 
  MapPin, 
  Info, 
  X, 
  Calendar, 
  CheckCircle2,
  PhoneCall
} from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { PROMO_OFFERS, PROMO_CATEGORIES, PromoOffer } from '../data/promosData';
import { useData } from '../context/DataContext';

export default function PromoPage() {
  const { promos } = useData();
  const allOffers = promos && promos.length > 0 ? promos : PROMO_OFFERS;

  const [selectedCategory, setSelectedCategory] = useState<string>('All Offers');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [activeModalOffer, setActiveModalOffer] = useState<PromoOffer | null>(null);
  
  // Claim form state
  const [claimName, setClaimName] = useState('');
  const [claimPhone, setClaimPhone] = useState('');
  const [claimTravelDate, setClaimTravelDate] = useState('');
  const [claimGuests, setClaimGuests] = useState('2');
  const [claimSuccess, setClaimSuccess] = useState(false);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => {
      setCopiedCode(null);
    }, 2500);
  };

  const filteredOffers = useMemo(() => {
    return allOffers.filter(offer => {
      const matchesCategory = selectedCategory === 'All Offers' || offer.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesQuery = !q || 
        offer.title.toLowerCase().includes(q) || 
        offer.destination.toLowerCase().includes(q) || 
        offer.country.toLowerCase().includes(q) ||
        offer.code.toLowerCase().includes(q) ||
        offer.overview.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [allOffers, selectedCategory, searchQuery]);

  const handleOpenClaimModal = (offer: PromoOffer) => {
    setActiveModalOffer(offer);
    setClaimSuccess(false);
  };

  const handleClaimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeModalOffer) return;
    
    // Construct WhatsApp message
    const message = `Hello Tvista Holidays! I would like to claim the promotional offer:\n\n*${activeModalOffer.title}*\nPromo Code: *${activeModalOffer.code}*\nDiscount: *${activeModalOffer.discountBadge}*\nName: ${claimName}\nPhone: ${claimPhone}\nTravel Date: ${claimTravelDate}\nGuests: ${claimGuests}\n\nPlease share the detailed customized itinerary and booking procedure.`;
    
    const whatsappUrl = `https://wa.me/919830712357?text=${encodeURIComponent(message)}`;
    
    setClaimSuccess(true);
    setTimeout(() => {
      window.open(whatsappUrl, '_blank');
      setActiveModalOffer(null);
      setClaimSuccess(false);
      setClaimName('');
      setClaimPhone('');
      setClaimTravelDate('');
    }, 1200);
  };

  return (
    <div className="relative min-h-screen text-stone-900 selection:bg-amber-200 selection:text-amber-950 font-sans">
      {/* Global Background Image - High-Clarity Visible Tropical & Scenic Backdrop */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <img 
          src="https://images.unsplash.com/photo-1506929562872-bb421503ef21?q=80&w=2068&auto=format&fit=crop" 
          alt="Luxury Resort Scenic Background" 
          className="w-full h-full object-cover scale-105" 
        />
        {/* Soft, luminous translucent veil so the scenic image is clearly visible, not black */}
        <div className="absolute inset-0 bg-white/45 backdrop-blur-[0.5px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-white/65 via-stone-50/20 to-white/75" />
      </div>

      <Navbar theme="light" />

      {/* Hero Section */}
      <div className="relative z-10 pt-32 sm:pt-36 pb-14 sm:pb-18 px-6 sm:px-12 lg:px-20 text-center flex flex-col items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 max-w-4xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100 border border-amber-300/80 text-amber-900 text-xs font-semibold uppercase tracking-widest mb-6 shadow-xs backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Exclusive Seasonal Privileges &amp; Savings</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-serif text-stone-900 tracking-tight leading-[1.15] mb-5">
            Curated Promos &amp; <span className="italic font-light text-amber-700">Bespoke Offers</span>
          </h1>

          <p className="text-base sm:text-lg md:text-xl text-stone-700 max-w-2xl mx-auto font-normal leading-relaxed">
            Enjoy guaranteed seasonal discounts, complimentary seaplane transfers, private villa upgrades, and zero-fee visa handling on our most celebrated global departures.
          </p>
        </motion.div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-12 lg:px-20 pb-28">
        
        {/* Search & Filter Controls */}
        <div className="space-y-6 mb-12">
          
          {/* Search Input */}
          <div className="max-w-md mx-auto relative">
            <input 
              type="text"
              placeholder="Search by country, destination or promo code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-4 pr-10 py-3 rounded-full bg-white/90 border border-stone-300 text-stone-900 placeholder-stone-400 text-sm focus:outline-none focus:border-amber-500 focus:bg-white transition-all shadow-xs backdrop-blur-md"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs p-1"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-2.5">
            {PROMO_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold tracking-wide transition-all ${
                    isActive
                      ? 'bg-amber-500 text-stone-950 font-bold shadow-md shadow-amber-500/20 scale-105'
                      : 'bg-white/85 text-stone-700 hover:text-stone-950 hover:bg-white border border-stone-200/90 shadow-xs'
                  }`}
                >
                  {category}
                </button>
              );
            })}
          </div>
        </div>

        {/* Offers Grid */}
        {filteredOffers.length === 0 ? (
          <div className="text-center py-20 bg-white/80 border border-stone-200/90 rounded-2xl p-8 max-w-xl mx-auto shadow-sm">
            <Compass className="w-12 h-12 text-stone-400 mx-auto mb-4" />
            <h3 className="text-xl font-serif text-stone-900 mb-2">No active promotions found</h3>
            <p className="text-stone-600 text-sm mb-6">
              Try adjusting your search criteria or switch to another category filter.
            </p>
            <button
              onClick={() => { setSelectedCategory('All Offers'); setSearchQuery(''); }}
              className="px-5 py-2.5 rounded-full bg-stone-900 text-white text-xs font-bold uppercase tracking-wider hover:bg-amber-600 transition-colors shadow-sm"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredOffers.map((offer, idx) => (
              <motion.div
                key={offer.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.05 }}
                className="group rounded-2xl overflow-hidden border border-stone-200/90 hover:border-amber-400/80 bg-white/90 backdrop-blur-xl shadow-md hover:shadow-xl hover:shadow-stone-900/10 flex flex-col justify-between transition-all duration-300"
              >
                {/* Visual Cover Stage */}
                <div className="relative h-64 sm:h-72 w-full overflow-hidden">
                  <img 
                    src={offer.image} 
                    alt={offer.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/30" />

                  {/* Top Badges */}
                  <div className="absolute top-4 left-4 right-4 flex items-center justify-between gap-2 z-10">
                    <span className="px-3 py-1 rounded-full bg-red-600 text-white font-bold text-xs uppercase tracking-wider shadow-md border border-red-400/30">
                      {offer.discountBadge}
                    </span>
                    
                    <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900/80 backdrop-blur-md border border-white/20 text-xs text-amber-300 font-medium shadow-sm">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{offer.daysRemaining} days left</span>
                    </div>
                  </div>

                  {/* Destination Geographic Tag */}
                  <div className="absolute bottom-4 left-4 flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900/70 backdrop-blur-md border border-white/20 text-white text-xs font-medium">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>{offer.destination}, {offer.country}</span>
                  </div>

                  <div className="absolute bottom-4 right-4">
                    <span className="text-[11px] font-semibold uppercase tracking-wider px-2.5 py-0.5 rounded-md bg-white/25 text-white backdrop-blur-md border border-white/25">
                      {offer.category}
                    </span>
                  </div>
                </div>

                {/* Offer Content */}
                <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between space-y-5">
                  <div>
                    <h3 className="text-2xl font-serif text-stone-900 group-hover:text-amber-800 transition-colors mb-1.5 leading-snug">
                      {offer.title}
                    </h3>
                    <p className="text-xs sm:text-[13px] text-amber-800 font-semibold mb-3">
                      {offer.subtitle}
                    </p>
                    <p className="text-sm text-stone-600 leading-relaxed line-clamp-2">
                      {offer.overview}
                    </p>
                  </div>

                  {/* Pricing Bar */}
                  <div className="pt-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl sm:text-3xl font-serif font-bold text-stone-950">
                        {offer.promoPrice}
                      </span>
                      <span className="text-sm text-stone-400 line-through">
                        {offer.originalPrice}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-emerald-700">
                      {offer.savings}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="pt-2">
                    <button
                      onClick={() => handleOpenClaimModal(offer)}
                      className="w-full py-3.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-sm shadow-amber-500/20"
                    >
                      <Gift className="w-4 h-4" />
                      <span>Claim This Promo</span>
                    </button>
                  </div>

                  {/* Validity Disclaimer */}
                  <div className="text-[11px] text-stone-500 pt-1">
                    <span>Valid until {offer.validUntil}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* VIP Concierge Banner */}
        <div className="mt-20 p-8 sm:p-10 rounded-2xl bg-gradient-to-r from-amber-50 via-white to-sky-50 border border-amber-300/80 backdrop-blur-xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left max-w-2xl">
            <span className="inline-block text-xs font-bold tracking-[0.2em] uppercase text-amber-800">
              Personalized Corporate &amp; Family Booking
            </span>
            <h3 className="text-2xl sm:text-3xl font-serif text-stone-900">
              Planning for a Group of 6 or More?
            </h3>
            <p className="text-sm text-stone-700">
              Unlock unpublished private flight charters, customized luxury coach itineraries, and personalized group discounts with our Senior Travel Concierge.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 shrink-0">
            <a 
              href="https://wa.me/919830712357?text=Hello%20Tvista%20Holidays!%20I%20am%20interested%20in%20a%20private%20customized%20group%20booking%20and%20exclusive%20promotions." 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-6 py-3.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98]"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Talk to Concierge</span>
            </a>
            <Link
              to="/contact"
              className="px-6 py-3.5 rounded-full bg-stone-900 hover:bg-stone-800 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-sm"
            >
              <span>Submit Request</span>
            </Link>
          </div>
        </div>

        {/* How to Redeem Step-by-Step */}
        <div className="mt-20 pt-12 border-t border-stone-200/80">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl sm:text-3xl font-serif text-stone-900 mb-3">
              How to Redeem Your Travel Promo
            </h3>
            <p className="text-sm text-stone-600">
              Four simple steps from selecting your dream voyage to boarding your flight.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-xl bg-white/85 border border-stone-200/90 shadow-sm">
              <span className="w-8 h-8 rounded-full bg-amber-100 text-amber-800 font-serif font-bold flex items-center justify-center text-sm mb-4 border border-amber-300">
                1
              </span>
              <h4 className="text-base font-serif text-stone-900 mb-2">Select Your Offer</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                Browse our seasonal promotions and copy the dedicated promotional coupon code.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-white/85 border border-stone-200/90 shadow-sm">
              <span className="w-8 h-8 rounded-full bg-sky-100 text-sky-800 font-serif font-bold flex items-center justify-center text-sm mb-4 border border-sky-300">
                2
              </span>
              <h4 className="text-base font-serif text-stone-900 mb-2">Click "Claim Promo"</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                Provide your preferred departure dates and contact details to lock in your reservation rate.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-white/85 border border-stone-200/90 shadow-sm">
              <span className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-serif font-bold flex items-center justify-center text-sm mb-4 border border-emerald-300">
                3
              </span>
              <h4 className="text-base font-serif text-stone-900 mb-2">Concierge Consultation</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                A dedicated holiday designer personalizes resort villas, flights, and complimentary inclusions.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-white/85 border border-stone-200/90 shadow-sm">
              <span className="w-8 h-8 rounded-full bg-purple-100 text-purple-800 font-serif font-bold flex items-center justify-center text-sm mb-4 border border-purple-300">
                4
              </span>
              <h4 className="text-base font-serif text-stone-900 mb-2">Enjoy Zero-Stress Travel</h4>
              <p className="text-xs text-stone-600 leading-relaxed">
                Receive visa documents, e-tickets, luxury vouchers, and 24/7 on-tour WhatsApp support.
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Claim Promo Interactive Modal */}
      <AnimatePresence>
        {activeModalOffer && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveModalOffer(null)}
              className="fixed inset-0 bg-stone-950/60 backdrop-blur-sm"
            />

            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="relative z-10 w-full max-w-lg bg-white border border-stone-200 rounded-2xl shadow-2xl p-6 sm:p-8 overflow-hidden my-8 text-stone-900"
            >
              {/* Close Button */}
              <button
                onClick={() => setActiveModalOffer(null)}
                className="absolute top-4 right-4 text-stone-400 hover:text-stone-800 p-1.5 rounded-full bg-stone-100 hover:bg-stone-200 transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 text-amber-700 text-xs font-bold uppercase tracking-wider mb-2">
                <Tag className="w-3.5 h-3.5" />
                <span>Promo Code: {activeModalOffer.code}</span>
              </div>

              <h3 className="text-2xl font-serif text-stone-900 mb-1">
                Claim: {activeModalOffer.title}
              </h3>

              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-2xl font-serif font-bold text-stone-950">
                  {activeModalOffer.promoPrice}
                </span>
                <span className="text-sm text-stone-400 line-through">
                  {activeModalOffer.originalPrice}
                </span>
                <span className="text-xs font-bold text-emerald-700 ml-2">
                  ({activeModalOffer.discountBadge})
                </span>
              </div>

              <p className="text-xs text-stone-600 mb-6 leading-relaxed">
                Fill in your travel preferences below. Our booking desk will immediately prepare your personalized voucher and verify availability.
              </p>

              {claimSuccess ? (
                <div className="py-8 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto border border-emerald-300">
                    <Check className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-serif text-stone-900 font-bold">Inquiry Sent Successfully!</h4>
                  <p className="text-xs text-stone-600">
                    Redirecting to WhatsApp to chat with our travel concierge...
                  </p>
                </div>
              ) : (
                <form onSubmit={handleClaimSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Full Name</label>
                    <input 
                      type="text"
                      required
                      placeholder="e.g. Ananya Roy"
                      value={claimName}
                      onChange={(e) => setClaimName(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">WhatsApp / Phone</label>
                      <input 
                        type="tel"
                        required
                        placeholder="+91 98300 00000"
                        value={claimPhone}
                        onChange={(e) => setClaimPhone(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-stone-700 mb-1">Tentative Travel Month</label>
                      <input 
                        type="text"
                        placeholder="e.g. November 2026"
                        value={claimTravelDate}
                        onChange={(e) => setClaimTravelDate(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-amber-500 focus:bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Number of Travelers</label>
                    <select
                      value={claimGuests}
                      onChange={(e) => setClaimGuests(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-xl bg-stone-50 border border-stone-300 text-stone-900 text-sm focus:outline-none focus:border-amber-500"
                    >
                      <option value="1">Solo Traveler (1 Person)</option>
                      <option value="2">Couple (2 Persons)</option>
                      <option value="3-4">Small Family (3 to 4 Persons)</option>
                      <option value="5+">Group (5+ Persons)</option>
                    </select>
                  </div>

                  {/* Terms Highlight */}
                  <div className="p-3 rounded-lg bg-stone-50 border border-stone-200 text-[11px] text-stone-600 space-y-1">
                    <div className="flex items-center gap-1.5 font-semibold text-stone-800">
                      <Info className="w-3.5 h-3.5 text-amber-600" />
                      <span>Terms &amp; Conditions</span>
                    </div>
                    {activeModalOffer.terms.map((term, i) => (
                      <p key={i}>• {term}</p>
                    ))}
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 active:scale-[0.98]"
                  >
                    <Send className="w-4 h-4" />
                    <span>Confirm &amp; Message on WhatsApp</span>
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <Footer theme="light" />
    </div>
  );
}
