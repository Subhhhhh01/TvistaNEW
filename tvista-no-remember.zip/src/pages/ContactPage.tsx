import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, MessageCircle } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { buildGeneralWhatsAppMessage, openWhatsAppChat, TVISTA_WHATSAPP_NUMBER, TVISTA_WHATSAPP_DISPLAY } from '../utils/whatsapp';

export default function ContactPage() {
  const [searchParams] = useSearchParams();
  const destinationParam = searchParams.get('destination');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (destinationParam) {
      setMessage(`Hello, I am interested in planning a journey to ${destinationParam}. Please provide me with customized itinerary options and availability.`);
    }
  }, [destinationParam]);

  const handleWhatsAppDirect = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const fullName = `${firstName} ${lastName}`.trim() || 'Guest Traveler';
    const waMsg = buildGeneralWhatsAppMessage({
      name: fullName,
      phone: phone,
      email: email,
      message: message || 'Hello Tvista Holidays! I would like to inquire about customized travel packages.'
    });

    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, waMsg);
  };

  return (
    <div className="relative min-h-screen selection:bg-white/30 selection:text-white">
      {/* Global Background Image */}
      <div className="fixed inset-0 z-[-1]">
        <img 
          src="https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=2020&auto=format&fit=crop" 
          alt="Paris Sunset Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-neutral-950/60 backdrop-blur-[2px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/80 via-transparent to-neutral-950/90" />
      </div>

      <Navbar theme="dark" />
      
      {/* Hero Section */}
      <div className="relative pt-32 pb-16 px-6 sm:px-12 lg:px-20 text-white min-h-[45vh] flex flex-col items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 text-center max-w-4xl mx-auto flex flex-col items-center"
        >
          <span className="inline-block py-1.5 px-4 border border-white/20 rounded-full text-white/80 text-xs font-semibold tracking-[0.2em] uppercase mb-8 bg-black/20 backdrop-blur-sm shadow-sm">
            Contact
          </span>
          <h1 className="text-5xl md:text-7xl font-serif mb-6 text-white tracking-tight leading-[1.1]">
            Get in <span className="italic text-white/70">Touch</span>
          </h1>
          <p className="text-lg md:text-xl text-white/80 mx-auto font-normal leading-relaxed max-w-2xl">
            We're here to help you plan your next unforgettable journey. Reach out to our team of dedicated travel experts or chat on WhatsApp.
          </p>
        </motion.div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pb-32">
        <div className="grid lg:grid-cols-3 gap-12 lg:gap-16">
          
          {/* Contact Details */}
          <div className="lg:col-span-1 space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-emerald-950/40 backdrop-blur-xl border border-emerald-500/30 rounded-2xl p-6 shadow-2xl hover:bg-emerald-950/60 transition-all group relative overflow-hidden"
            >
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                <MessageCircle className="w-6 h-6 text-emerald-400 fill-emerald-400" />
              </div>
              <span className="text-[10px] uppercase tracking-widest text-emerald-400 font-bold block mb-1">Instant Messaging</span>
              <h3 className="text-xl font-serif text-white mb-2">WhatsApp Desk</h3>
              <p className="text-white/70 text-xs mb-4">Connect directly with our senior travel planner for quick fare quotes and itineraries.</p>
              <button
                onClick={handleWhatsAppDirect}
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 px-4 rounded-xl transition-all text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Chat on WhatsApp ({TVISTA_WHATSAPP_DISPLAY})</span>
              </button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-neutral-950/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl hover:bg-neutral-950/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-white/10 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                <Phone className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-serif text-white mb-1">Call Us</h3>
              <p className="text-white/60 text-xs mb-3">Mon-Sat from 9:30am to 7:00pm IST.</p>
              <p className="text-white font-medium text-sm">+91 98307 12357</p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-neutral-950/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl hover:bg-neutral-950/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-white/10 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-serif text-white mb-1">Email Us</h3>
              <p className="text-white/60 text-xs mb-3">Our friendly team is here to help.</p>
              <p className="text-white font-medium text-sm">support@tvistaholidays.com</p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-neutral-950/40 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl hover:bg-neutral-950/50 transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-white/10 border border-white/10 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500">
                <MapPin className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-lg font-serif text-white mb-1">Visit Us</h3>
              <p className="text-white/60 text-xs mb-3">Come say hello at our Kolkata office.</p>
              <p className="text-white font-medium text-xs leading-relaxed">7, Ganpat Bagla Road, Swastik Enclave<br/>Block- B, 2nd Floor, Kolkata 700007, India</p>
            </motion.div>
          </div>
          
          {/* Contact Form / Instant WhatsApp Launcher */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2 bg-neutral-950/50 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 lg:p-14 shadow-2xl"
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-3xl font-serif text-white">Send Message on WhatsApp</h3>
                <p className="text-white/60 text-xs mt-1">Compose your query and click below to open directly in WhatsApp ({TVISTA_WHATSAPP_DISPLAY}).</p>
              </div>
              <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Live WhatsApp Desk
              </span>
            </div>
            
            <form className="space-y-6" onSubmit={handleWhatsAppDirect}>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/60 mb-2 font-semibold">First Name (Optional)</label>
                  <input 
                    type="text" 
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3.5 text-white text-sm focus:outline-none focus:border-emerald-500 focus:bg-white/10 transition-colors placeholder:text-white/30 shadow-inner" 
                    placeholder="Rahul" 
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/60 mb-2 font-semibold">Last Name (Optional)</label>
                  <input 
                    type="text" 
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3.5 text-white text-sm focus:outline-none focus:border-emerald-500 focus:bg-white/10 transition-colors placeholder:text-white/30 shadow-inner" 
                    placeholder="Sharma" 
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/60 mb-2 font-semibold">Email Address (Optional)</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3.5 text-white text-sm focus:outline-none focus:border-emerald-500 focus:bg-white/10 transition-colors placeholder:text-white/30 shadow-inner" 
                    placeholder="rahul@example.com" 
                  />
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-wider text-white/60 mb-2 font-semibold">Phone Number / Contact</label>
                  <input 
                    type="tel" 
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3.5 text-white text-sm focus:outline-none focus:border-emerald-500 focus:bg-white/10 transition-colors placeholder:text-white/30 shadow-inner" 
                    placeholder="+91 98307 12357" 
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs uppercase tracking-wider text-white/60 mb-2 font-semibold">Message / Travel Request</label>
                <textarea 
                  rows={5} 
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-3.5 text-white text-sm focus:outline-none focus:border-emerald-500 focus:bg-white/10 transition-colors placeholder:text-white/30 shadow-inner resize-none" 
                  placeholder="How can we help you plan your journey?"
                ></textarea>
              </div>
              
              <button 
                type="submit" 
                className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-4 rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-xl w-full flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                <span>Launch WhatsApp Chat</span>
              </button>
            </form>
          </motion.div>
          
        </div>
      </div>

      <Footer theme="dark" />
    </div>
  );
}
