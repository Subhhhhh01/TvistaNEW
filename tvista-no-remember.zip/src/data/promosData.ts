export interface PromoOffer {
  id: string;
  title: string;
  subtitle: string;
  code: string;
  discountBadge: string;
  category: 'Early Bird' | 'Luxury Beach' | 'Honeymoon' | 'Alpine & Winter' | 'Cultural Heritage' | 'Family Specials';
  destination: string;
  country: string;
  image: string;
  originalPrice: string;
  promoPrice: string;
  savings: string;
  validUntil: string;
  daysRemaining: number;
  featured?: boolean;
  inclusions: string[];
  terms: string[];
  overview: string;
  packageSlugOrCategory?: string;
}

export const PROMO_CATEGORIES = [
  'All Offers',
  'Early Bird',
  'Luxury Beach',
  'Honeymoon',
  'Alpine & Winter',
  'Cultural Heritage',
  'Family Specials'
] as const;

export const PROMO_OFFERS: PromoOffer[] = [
  {
    id: 'promo-maldives-bliss',
    title: 'Maldives Overwater Lagoon Retreat',
    subtitle: 'Luxury Private Pool Villa with Complimentary Return Seaplane Transfers',
    code: 'MALDIVES25',
    discountBadge: '25% OFF',
    category: 'Luxury Beach',
    destination: 'North Malé Atoll',
    country: 'Maldives',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹2,60,000',
    promoPrice: '₹1,95,000',
    savings: 'Save ₹65,000 per couple',
    validUntil: '30 October 2026',
    daysRemaining: 14,
    featured: true,
    inclusions: [
      'Round-trip scenic seaplane transfers included (worth ₹45,000)',
      'All-inclusive gourmet dining & premium beverages across 4 pavilions',
      'One sunset dolphin cruise aboard a traditional handcrafted dhoni',
      'Complimentary 60-minute couple marine spa treatment'
    ],
    terms: [
      'Valid for bookings made at least 15 days prior to arrival',
      'Blackout dates apply during peak holiday weeks',
      'Applicable on 4 Nights / 5 Days stay minimum'
    ],
    overview: 'Experience ultimate Indian Ocean seclusion in an overwater villa suspended above turquoise crystal lagoons. Indulge in floating breakfasts, private coral reef snorkeling, and world-class spa pampering.',
    packageSlugOrCategory: 'Beach'
  },
  {
    id: 'promo-swiss-alps-earlybird',
    title: 'Swiss Alps & Glacier Express Grand Voyage',
    subtitle: 'First-Class Scenic Rail, 5-Star Alpine Spas & Zermatt Matterhorn Panoramas',
    code: 'ALPINE45',
    discountBadge: 'SAVE ₹45,000',
    category: 'Early Bird',
    destination: 'Zermatt, St. Moritz & Lucerne',
    country: 'Switzerland',
    image: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹3,40,000',
    promoPrice: '₹2,95,000',
    savings: 'Flat ₹45,000 off per booking',
    validUntil: '15 November 2026',
    daysRemaining: 21,
    featured: true,
    inclusions: [
      'Complimentary upgrade to Glacier Express Excellence Class seating',
      'Daily heated thermal infinity bath passes with Matterhorn vista',
      'Swiss Travel Pass First Class (8 Days unlimited rail & lake steamers)',
      'Gourmet fondue & raclette tasting dinner in an alpine chalet'
    ],
    terms: [
      'Must book at least 30 days ahead of chosen departure window',
      'Passport copy with minimum 6-month validity required',
      'Non-refundable deposit of 20% secures the reservation'
    ],
    overview: 'Traverse timeless snow-crowned summits and emerald valley floors. Enjoy world-class hospitality in Zermatt and St. Moritz with guaranteed seats on the legendary Glacier Express.',
    packageSlugOrCategory: 'Adventure'
  },
  {
    id: 'promo-bali-ubud-honeymoon',
    title: 'Romantic Bali & Nusa Penida Sanctuary',
    subtitle: 'Private Jungle Pool Villa in Ubud & Cliffside Sunset Suite in Uluwatu',
    code: 'BALI30',
    discountBadge: '30% OFF',
    category: 'Honeymoon',
    destination: 'Ubud & Uluwatu',
    country: 'Indonesia',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹1,85,000',
    promoPrice: '₹1,29,500',
    savings: 'Save ₹55,500 per couple',
    validUntil: '20 October 2026',
    daysRemaining: 9,
    featured: false,
    inclusions: [
      'Private infinity pool villa surrounded by lush Ayung river rainforest',
      'Sunset candlelit 5-course cliffside dinner overlooking Jimbaran Bay',
      'Speedboat transfers and private driver for Nusa Penida island exploration',
      'Traditional Balinese herbal boreh massage for two'
    ],
    terms: [
      'Honeymoon amenity setup requires wedding certificate within 12 months',
      'Free rescheduling up to 14 days before check-in',
      'Subject to luxury villa inventory'
    ],
    overview: 'Designed exclusively for couples seeking intimate tranquility. Revel in lush tropical valleys, sacred water temples, floating flower baths, and dramatic ocean sunset vistas.',
    packageSlugOrCategory: 'Bali & Southeast Asia'
  },
  {
    id: 'promo-dubai-desert-vip',
    title: 'Dubai Glamour & Royal Desert Glamping',
    subtitle: 'Burj Khalifa Sky Lounge, Yacht Marina Cruise & Bedouin Stargazing Retreat',
    code: 'DUBAILUX',
    discountBadge: 'FREE GLAMPING',
    category: 'Luxury Beach',
    destination: 'Dubai & Al Marmoom Desert',
    country: 'UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹1,90,000',
    promoPrice: '₹1,48,000',
    savings: 'Worth ₹42,000 desert stay included',
    validUntil: '05 November 2026',
    daysRemaining: 18,
    featured: false,
    inclusions: [
      '1 Night complimentary luxury desert glamping suite under desert stars',
      'VIP At The Top Burj Khalifa Level 148 lounge access',
      'Private yacht charter cruise with sunset canapés along Dubai Marina',
      'Desert falconry, camel caravan & dune rover safari'
    ],
    terms: [
      'Valid for minimum 5 Nights / 6 Days holiday bookings',
      'Includes express Dubai Tourist Visa processing',
      'Valid for travel dates through March 2027'
    ],
    overview: 'Witness modern architectural marvels fused with timeless Arabian heritage. From skyline sky-lounges to authentic Bedouin banquets under starlit Arabian skies.',
    packageSlugOrCategory: 'Dubai & Middle East'
  },
  {
    id: 'promo-japan-sakura-earlybird',
    title: 'Japan Sakura & Cultural Heartland 2026',
    subtitle: 'Tokyo Shinkansen Bullet Train, Kyoto Ryokan & Mount Fuji Onsen Experience',
    code: 'SAKURA2026',
    discountBadge: '20% OFF',
    category: 'Cultural Heritage',
    destination: 'Tokyo, Hakone & Kyoto',
    country: 'Japan',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹3,75,000',
    promoPrice: '₹2,99,000',
    savings: 'Save ₹76,000 per traveler',
    validUntil: '31 December 2026',
    daysRemaining: 45,
    featured: true,
    inclusions: [
      'Stay in authentic Kyoto Onsen Ryokan with multi-course Kaiseki dinner',
      '7-Day Japan Rail (JR) Whole Country Pass included',
      'Private tea ceremony with a master in an ancient Kyoto temple garden',
      'Hakone ropeway cable car & Lake Ashi pirate boat cruise facing Mt. Fuji'
    ],
    terms: [
      'Early bird discount strictly limited to first 25 booked guests',
      'Japan Tourist Visa processing support and itinerary documentation included',
      'Flexible date change options available'
    ],
    overview: 'Experience the world-renowned Japanese hospitality (Omotenashi). Wander through Tokyo neon districts, soak in volcanic hot springs, and stroll beneath ancient bamboo groves.',
    packageSlugOrCategory: 'Culture'
  },
  {
    id: 'promo-south-africa-family',
    title: 'South Africa Big Five Safari & Garden Route',
    subtitle: 'Mabula Game Lodge, Sun City Resort & Cape Peninsula Coastal Drive',
    code: 'SAFARI50',
    discountBadge: 'FAMILY 50% OFF',
    category: 'Family Specials',
    destination: 'Cape Town, Mabula & Sun City',
    country: 'South Africa',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹4,90,000',
    promoPrice: '₹3,67,500',
    savings: 'Save ₹1,22,500 on family packages',
    validUntil: '12 November 2026',
    daysRemaining: 26,
    featured: false,
    inclusions: [
      'Second guest or child under 12 receives 50% discount on land package',
      'Two open-top 4x4 Big Five game drives daily with certified ranger',
      'Cape Point Seal Island boat cruise and Boulders Beach penguin visit',
      'Table Mountain revolving cable car express tickets'
    ],
    terms: [
      'Applicable on family bookings of 3 or more travelers sharing suites',
      'Includes domestic flight between Cape Town and Johannesburg',
      'Must book by promo deadline'
    ],
    overview: 'An unforgettable expedition blending premier wildlife encounters with dramatic oceanic coastlines. Discover lions, elephants, rhinos, and penguins in their pristine natural habitats.',
    packageSlugOrCategory: 'Africa & Safari'
  },
  {
    id: 'promo-schengen-europe-free-visa',
    title: 'Europe Grand Capitals & Schengen Advantage',
    subtitle: 'Paris, Switzerland, Austria & Venice with 100% Free Visa Assistance',
    code: 'SCHENGENFREE',
    discountBadge: 'FREE VISA',
    category: 'Cultural Heritage',
    destination: 'Paris, Lucerne, Innsbruck & Venice',
    country: 'Europe Multi-Country',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹2,80,000',
    promoPrice: '₹2,35,000',
    savings: 'Free Visa + ₹45,000 off per person',
    validUntil: '28 October 2026',
    daysRemaining: 12,
    featured: false,
    inclusions: [
      'Complete Schengen Visa documentation, VFS appointment & fees waived',
      'Seine River dinner cruise aboard a glass canopy vessel in Paris',
      'Mt. Titlis revolving cable car & Ice Flyer in Engelberg',
      'Gondola serenade ride along Venice Grand Canal'
    ],
    terms: [
      'Free visa fee coverage applies upon tour confirmation',
      'VFS bio-metric attendance required in person as per consular rules',
      'Applies to 9N/10D European package itineraries'
    ],
    overview: 'Tour Europe with total peace of mind. Our veteran visa concierge manages appointments and dossier verification while you prepare for legendary palaces, museums, and mountain peaks.',
    packageSlugOrCategory: 'Europe & UK'
  },
  {
    id: 'promo-ladakh-himalayan-pass',
    title: 'Ladakh High Passes & Pangong Lake Expedition',
    subtitle: 'Nubra Valley Camel Safari, Khardung La Pass & Luxury Heated Camp Stays',
    code: 'LADAKH20',
    discountBadge: '20% OFF',
    category: 'Alpine & Winter',
    destination: 'Leh, Nubra Valley & Pangong Tso',
    country: 'India',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=1200&auto=format&fit=crop',
    originalPrice: '₹75,000',
    promoPrice: '₹59,900',
    savings: 'Save ₹15,100 per person',
    validUntil: '15 October 2026',
    daysRemaining: 7,
    featured: false,
    inclusions: [
      'Boutique glamping with heated geodomes along Pangong Lake shore',
      'Private 4x4 vehicle with veteran mountain driver throughout the route',
      'Oxygen cylinder, acclimatization doctor on call & Inner Line Permits included',
      'Double-humped Bactrian camel ride across Hunder sand dunes'
    ],
    terms: [
      'Valid for travel dates from May to October',
      'Group booking discounts of 4+ passengers can combine with this code',
      'Includes all monastery entrance fees'
    ],
    overview: 'Surreal moonscapes, crystal-clear Himalayan lakes reflecting snow-capped peaks, and ancient cliffside Buddhist monasteries. A transformative mountain sojourn with royal comfort.',
    packageSlugOrCategory: 'Ladakh & Himalayas'
  }
];
