export interface GalleryItemType {
  id: number | string;
  title: string;
  location: string;
  desc: string;
  image: string;
}

export const DEFAULT_GALLERY_ITEMS: GalleryItemType[] = [
  {
    id: 1,
    title: 'Oceanfront Overwater Villa',
    location: 'Maldives',
    desc: 'Step directly from your private deck into crystal clear turquoise waters. The ultimate tropical luxury and relaxation.',
    image: 'https://images.unsplash.com/photo-1439066615861-d1af74d74000?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 2,
    title: 'Alpine Sanctuary',
    location: 'Swiss Alps, Switzerland',
    desc: 'A luxurious mountain retreat offering breathtaking views. Warm up by the stone fireplace after a day exploring the peaks.',
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?q=80&w=2071&auto=format&fit=crop',
  },
  {
    id: 3,
    title: 'Lakeside Manor',
    location: 'Lake Como, Italy',
    desc: 'Experience classic European elegance by the lake. Featuring sprawling gardens and exquisite views of the water.',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 4,
    title: 'Misty Highland Estate',
    location: 'Scottish Highlands, UK',
    desc: 'Discover the raw beauty of the highlands. A historic estate surrounded by rolling hills, deep lochs, and a dramatic, moody sky.',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 5,
    title: 'Cliffside Village',
    location: 'Cinque Terre, Italy',
    desc: 'Wander through vibrant, pastel-colored houses perched precariously on the rugged cliffs overlooking the Mediterranean Sea.',
    image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=1986&auto=format&fit=crop',
  },
  {
    id: 6,
    title: 'Urban Penthouse',
    location: 'New York, USA',
    desc: 'Experience the city from above. A modern, glass-walled penthouse offering unparalleled, panoramic views of the iconic skyline.',
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 7,
    title: 'Santorini Sunset',
    location: 'Oia, Greece',
    desc: 'Breathtaking sunsets, pristine white architecture, and the deep blue of the Aegean Sea. A timeless Mediterranean dream.',
    image: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?q=80&w=1974&auto=format&fit=crop',
  },
  {
    id: 8,
    title: 'Jungle Retreat',
    location: 'Bali, Indonesia',
    desc: 'A hidden sanctuary nestled deeply within the lush tropical rainforest. Reconnect with nature in absolute tranquility.',
    image: 'https://images.unsplash.com/photo-1507608616759-54f48f0af0ee?q=80&w=1974&auto=format&fit=crop',
  },
  {
    id: 9,
    title: 'Historic Canal House',
    location: 'Amsterdam, Netherlands',
    desc: 'Step back in time in a beautifully restored canal house. Experience the charm, history, and unique architecture of the city.',
    image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 10,
    title: 'Desert Luxury Pavilion',
    location: 'Dubai, UAE',
    desc: 'Modern marvels meeting golden desert dunes. An exclusive, luxury pavilion offering both seclusion and opulence.',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 11,
    title: 'Winter Wonderland Igloo',
    location: 'Lapland, Finland',
    desc: 'Cozy up in a glass igloo and watch the spectacular Northern Lights dance across the arctic sky from the comfort of your bed.',
    image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 12,
    title: 'Machu Picchu Ruins',
    location: 'Cusco Region, Peru',
    desc: 'Explore the ancient Incan citadel set high in the Andes Mountains. A testament to historical engineering and natural beauty.',
    image: 'https://images.unsplash.com/photo-1526392060635-9d6019884377?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 13,
    title: 'Cherry Blossom Gardens',
    location: 'Kyoto, Japan',
    desc: 'Wander through serene temples surrounded by beautiful, blooming sakura trees during the spring season.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 14,
    title: 'Bora Bora Overwater Bungalows',
    location: 'French Polynesia',
    desc: 'Wake up to the gentle sound of waves in a luxurious overwater bungalow, surrounded by vibrant coral reefs.',
    image: 'https://images.unsplash.com/photo-1502507858907-8840b17b686d?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 15,
    title: 'Serengeti Safari',
    location: 'Tanzania',
    desc: 'Experience the thrill of a lifetime observing majestic wildlife in their natural habitat across the vast African plains.',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=2068&auto=format&fit=crop',
  },
  {
    id: 16,
    title: 'Glacier National Park',
    location: 'Montana, USA',
    desc: 'Discover breathtaking alpine scenery, pristine lakes, and abundant wildlife in the heart of the Rocky Mountains.',
    image: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 17,
    title: 'Victoria Falls',
    location: 'Zambia/Zimbabwe',
    desc: 'Witness the raw power and spectacular beauty of one of the largest and most famous waterfalls in the world.',
    image: 'https://images.unsplash.com/photo-1603201236596-eb1a63eb0ede?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 18,
    title: 'Banff National Park',
    location: 'Alberta, Canada',
    desc: 'Marvel at turquoise glacial lakes, rugged mountain peaks, and dense pine forests in this picturesque national park.',
    image: 'https://images.unsplash.com/photo-1542614947-640a45e4e73b?q=80&w=2070&auto=format&fit=crop',
  }
];
