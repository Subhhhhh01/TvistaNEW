export interface DestinationItem {
  id: number | string;
  name: string;
  country: string;
  description: string;
  duration: string;
  price: string;
  image: string;
  featured?: boolean;
}

export const DEFAULT_DESTINATIONS: DestinationItem[] = [
  {
    id: 1,
    name: 'Kyoto',
    country: 'Japan',
    description: 'Ancient temples, serene gardens, and traditional geisha districts await in this cultural heart of Japan. Experience cherry blossoms and centuries-old tea houses.',
    duration: '7 Days',
    price: '₹1,98,000',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
    featured: true
  },
  {
    id: 2,
    name: 'Amalfi Coast',
    country: 'Italy',
    description: 'Dramatic cliffs, pastel-colored coastal towns, and crystal clear Mediterranean waters. A perfect blend of romance, culinary perfection, and scenic beauty.',
    duration: '5 Days',
    price: '₹1,48,000',
    image: 'https://images.unsplash.com/photo-1499678329028-101435549a4e?q=80&w=2070&auto=format&fit=crop',
    featured: true
  },
  {
    id: 3,
    name: 'Paris',
    country: 'France',
    description: 'The city of lights, love, and world-class architecture. Explore timeless museums, charming sidewalk cafes, and world-famous monuments.',
    duration: '6 Days',
    price: '₹1,75,000',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=2070&auto=format&fit=crop',
    featured: true
  },
  {
    id: 4,
    name: 'Swiss Alps',
    country: 'Switzerland',
    description: 'Snow-capped peaks, pristine alpine lakes, and world-class skiing resorts. A nature lover\'s sanctuary in both winter and summer.',
    duration: '8 Days',
    price: '₹2,65,000',
    image: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?q=80&w=2070&auto=format&fit=crop',
    featured: true
  },
  {
    id: 5,
    name: 'Santorini',
    country: 'Greece',
    description: 'Iconic white-washed buildings, azure domes, and legendary sunsets perched over the Aegean Caldera.',
    duration: '6 Days',
    price: '₹2,10,000',
    image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?q=80&w=2070&auto=format&fit=crop',
    featured: false
  },
  {
    id: 6,
    name: 'Banff National Park',
    country: 'Canada',
    description: 'Breathtaking wilderness, turquoise glacial lakes, and towering Rocky Mountain peaks.',
    duration: '9 Days',
    price: '₹2,85,000',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
    featured: false
  }
];
