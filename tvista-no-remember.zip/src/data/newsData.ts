export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: 'Visa Updates' | 'Travel Trends' | 'Destination Guides' | 'Aviation News' | 'Press & Awards';
  author: {
    name: string;
    role: string;
    avatar: string;
  };
  date: string;
  readTime: string;
  coverImage: string;
  featured?: boolean;
  tags: string[];
  keyHighlights: string[];
  relatedDestination?: string;
}

export const NEWS_CATEGORIES = [
  'All News',
  'Visa Updates',
  'Travel Trends',
  'Destination Guides',
  'Aviation News',
  'Press & Awards'
] as const;

export const NEWS_ARTICLES: NewsArticle[] = [
  {
    id: 'schengen-cascade-visa-2026',
    title: 'Schengen Visa 2026: The "Cascade Regime" & Digital Entry Rules for Travelers',
    slug: 'schengen-cascade-visa-2026',
    excerpt: 'The European Union introduces simplified multi-year visas and upcoming digital applications. Here is everything travelers need to know to secure 2-year and 5-year permits.',
    category: 'Visa Updates',
    author: {
      name: 'Aditi Sengupta',
      role: 'Head of Consular & Visa Affairs, Tvista Holidays',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop'
    },
    date: 'September 08, 2026',
    readTime: '5 min read',
    coverImage: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1200&auto=format&fit=crop',
    featured: true,
    tags: ['Schengen', 'Visa Guide', 'Europe Travel', 'EU Regulations'],
    keyHighlights: [
      'Travelers with a history of two previous Schengen visas can qualify for a 2-year multi-entry visa',
      'The 2-year visa can now be followed by a 5-year multi-entry visa, provided passport validity allows',
      'Consular biometric appointments still require booking 45 to 60 days in advance during peak seasons',
      'Tvista Holidays offers complete end-to-end dossier verification to eliminate rejections'
    ],
    content: `
### What is the Schengen "Cascade" Regime?

Under the updated Schengen Visa Code adopted by the European Commission, a standardized "cascade" regime provides frequent travelers with access to multi-year visas with long validity. 

If you have lawfully obtained and used two Schengen visas within the previous three years, you may now be granted a multi-entry visa valid for **two years**. Following the lawful completion of this two-year visa, eligible applicants can unlock a **five-year multi-entry visa**, provided their passport possesses sufficient remaining validity.

> *"The cascade system represents a breakthrough for luxury leisure travelers and business executives who frequently visit European capitals for holidays, cultural festivals, and business forums."* — Aditi Sengupta

### Transitioning to the EU Digital Visa Platform

The European Union has commenced pilot phases for the **EU VAP (Visa Application Platform)**, which will eventually transition Schengen applications online:

1. **Digital Applications:** Submission of forms, itineraries, and hotel reservations will be handled through a unified European portal.
2. **Reduced Physical Visits:** First-time applicants still provide in-person biometrics (fingerprints & digital photography), but renewal applicants will frequently bypass physical consulate appointments.
3. **Digital Barcode Visas:** Physical sticker visas in passports will gradually be replaced by cryptographically signed digital 2D barcodes stored on traveler profiles.

### How Tvista Holidays Prepares Your Application

Our specialized visa concierge team provides:
- Comprehensive dossier auditing to ensure zero discrepancies between flights, accommodation vouchers, and financial certificates.
- Automated appointment tracking across VFS Global centres in Kolkata, Delhi, Mumbai, Bengaluru, and Chennai.
- Dedicated insurance policies covering up to €50,000 in medical and emergency repatriations as mandated by European law.
    `,
    relatedDestination: 'Europe Multi-Country'
  },
  {
    id: 'scenic-luxury-rail-europe-japan',
    title: 'The Renaissance of Ultra-Luxury Rail: Glacier Express, Belmond & Shinkansen Suites',
    slug: 'scenic-luxury-rail-europe-japan',
    excerpt: 'Slow travel has reclaimed the high throne of luxury. Why discerning voyagers are choosing panoramic glass-domed trains and vintage sleeper carriages over private jets.',
    category: 'Travel Trends',
    author: {
      name: 'Vikram Roy Chowdhury',
      role: 'Senior Editorial Curator, Tvista Holidays',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop'
    },
    date: 'August 29, 2026',
    readTime: '6 min read',
    coverImage: 'https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?q=80&w=1200&auto=format&fit=crop',
    featured: true,
    tags: ['Luxury Rail', 'Glacier Express', 'Slow Travel', 'Scenic Journeys'],
    keyHighlights: [
      'Glacier Express Excellence Class offers guaranteed window seating and 5-course sommelier pairings',
      'Belmond Venice Simplon-Orient-Express debuts new grand suites connecting Paris to Portofino',
      'Japan’s Seven Stars in Kyushu continues to command a 6-month lottery waiting list for private cabins',
      'Eco-conscious luxury travelers are driving a 42% year-on-year increase in scenic rail bookings'
    ],
    content: `
### The Allure of Thoughtful Speed

In an era where travel has become increasingly commoditized by airport queues and rapid transit, ultra-luxury rail offers a timeless antidote. It invites travelers to witness geographical transformations gradually — from sun-drenched vineyards along the Rhine to jagged alpine peaks pierced by granite tunnels.

### Spotlight: Glacier Express Excellence Class

Between Zermatt and St. Moritz, the Glacier Express navigates 291 bridges and 91 tunnels over eight hours. In **Excellence Class**, every guest enjoys:
- Individual plush leather swivel seats guaranteeing unobstructed views of the Landwasser Viaduct.
- A dedicated concierge serving champagne, amuse-bouche, and regional Swiss wine pairings.
- Access to the Glacier Bar with an open brass ceiling skylight.

### Integrating Rail with Tvista Holiday Packages

We curate seamless multimodal itineraries where high-speed Shinkansen bullet trains or heritage steam locomotives connect private villas, 5-star mountain lodges, and yacht charters without cumbersome luggage transfers.
    `,
    relatedDestination: 'Swiss Alps & Dolomites'
  },
  {
    id: 'japan-autumn-foliage-forecast-2026',
    title: 'Japan Autumn Foliage & Sakura 2026: Insider Guide to Kyoto, Hakone & Kanazawa',
    slug: 'japan-autumn-foliage-forecast-2026',
    excerpt: 'The Japan Meteorological Corporation has released its preliminary Momiji and Sakura outlook. Discover the golden windows for temple illuminations and ryokan stays.',
    category: 'Destination Guides',
    author: {
      name: 'Sayani Mukherjee',
      role: 'East Asia Specialist, Tvista Holidays',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop'
    },
    date: 'August 14, 2026',
    readTime: '4 min read',
    coverImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=1200&auto=format&fit=crop',
    featured: false,
    tags: ['Japan', 'Kyoto', 'Ryokan', 'Autumn Leaves', 'Culture'],
    keyHighlights: [
      'Peak crimson maples (Momiji) projected from mid-November to early December across Kyoto temples',
      'Private night illuminations at Kodai-ji and Eikan-do booked exclusively through licensed concierges',
      'Kanazawa emerges as the premier crowd-free alternative for preserved geisha districts and samurai gardens',
      'Onsen etiquette and kaiseki dietary preferences handled seamlessly by Tvista liaisons'
    ],
    content: `
### Finding Serenity Amidst Seasonal Splendor

Few sights rival the fiery Japanese maples draped over moss-covered stones in Kyoto's northern hills. However, the surge in global tourism means planning three to six months in advance is essential to secure premier boutique ryokan with private thermal baths (*rotenburo*).

### Why Kanazawa Belongs on Your Itinerary

Just two hours by Shinkansen from Tokyo, Kanazawa offers:
- **Kenroku-en Garden:** Ranked among Japan's three great landscape gardens, famed for *yukitsuri* rope cones that protect ancient pine trees.
- **Higashi Chaya District:** Preserved wooden teahouses where the arts of traditional song and shamisen are practiced.
- **Omicho Market:** Exceptional seasonal snow crab (*Kano-gani*) and freshly sliced sashimi.
    `,
    relatedDestination: 'Japan'
  },
  {
    id: 'aviation-direct-flights-expanding',
    title: 'Aviation Watch: New Non-Stop Long-Haul Corridors Connecting India to Europe & Far East',
    slug: 'aviation-direct-flights-expanding',
    excerpt: 'Air India, Singapore Airlines, and European carriers deploy new Airbus A350 and Boeing 787 fleets, reducing layover fatigue for Indian travelers.',
    category: 'Aviation News',
    author: {
      name: 'Rajiv Kapoor',
      role: 'Aviation & Airline Partnerships Lead',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop'
    },
    date: 'July 28, 2026',
    readTime: '4 min read',
    coverImage: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=1200&auto=format&fit=crop',
    featured: false,
    tags: ['Aviation', 'Business Class', 'Direct Flights', 'A350', 'Airlines'],
    keyHighlights: [
      'New direct flights launched connecting Delhi and Mumbai directly to Zurich, Vienna, and Milan',
      'Next-generation Business Class suites with sliding privacy doors and wireless charging standard on A350-900',
      'Tvista Holidays offers privileged corporate & luxury companion fare tariffs on partner airlines',
      'Baggage allowance allowances up to 40kg for international tour package ticket bookings'
    ],
    content: `
### Reimagined Cabin Comfort

The arrival of state-of-the-art widebody aircraft with lower cabin altitude simulation and improved humidity has drastically reduced jet lag for intercontinental journeys.

### Benefits for Tvista Holiday Guests

When you book flight ticketing with Tvista Holidays:
- We reserve preferred seating, including bulkhead and bassinet rows, without standard airline surcharges.
- Coordinated flight monitoring alerts our private chauffeur teams at destination airports in real-time regarding delays.
- Immediate re-booking priority in case of seasonal weather disruptions.
    `,
    relatedDestination: 'International Flights'
  },
  {
    id: 'secret-mediterranean-islands-2026',
    title: 'Beyond Mykonos & Capri: 5 Untouched Mediterranean Hideaways for Seclusion',
    slug: 'secret-mediterranean-islands-2026',
    excerpt: 'Escape overcrowded beaches. Explore the tranquil volcanic shores of Pantelleria, the pine-clad coves of Paxos, and the wild coastline of Menorca.',
    category: 'Destination Guides',
    author: {
      name: 'Vikram Roy Chowdhury',
      role: 'Senior Editorial Curator, Tvista Holidays',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop'
    },
    date: 'July 15, 2026',
    readTime: '5 min read',
    coverImage: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=1200&auto=format&fit=crop',
    featured: false,
    tags: ['Mediterranean', 'Private Islands', 'Yacht Charter', 'Hidden Gems'],
    keyHighlights: [
      'Pantelleria (Italy): Volcanic mud baths, Arab-influenced dammusi stone villas, and Passito wine',
      'Paxos & Antipaxos (Greece): Crystalline waters accessible almost exclusively by private boat',
      'Menorca (Spain): UNESCO Biosphere reserve boasting quiet turquoise calas bordered by wild olive groves',
      'Private motor-yacht charters arranged with experienced skippers and onboard chef service'
    ],
    content: `
### Rediscovering the True Spirit of the Mediterranean

While iconic ports like Amalfi and Ibiza vibrate with high energy, an increasing number of our travelers seek peaceful sanctuaries where water clarity rivals the Caribbean and local tavernas serve fish caught hours earlier.

### Spotlight: Paxos & Antipaxos

Situated just south of Corfu in the Ionian Sea, Paxos is covered with century-old olive groves. Neighboring Antipaxos features white-sand beaches like Voutoumi, where water appears luminescent under the midday sun. Our custom itineraries pair a boutique villa stay with a dedicated tender boat moored at your private jetty.
    `,
    relatedDestination: 'Mediterranean Escapes'
  },
  {
    id: 'tvista-holidays-excellence-award-2026',
    title: 'Tvista Holidays Recognized for "Excellence in Luxury Itinerary Design 2026"',
    slug: 'tvista-holidays-excellence-award-2026',
    excerpt: 'Our commitment to bespoke luxury, meticulous visa handling, and personalized client support has earned national recognition from the Luxury Travel Guild.',
    category: 'Press & Awards',
    author: {
      name: 'Editorial Desk',
      role: 'Tvista Holidays Communications',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop'
    },
    date: 'June 30, 2026',
    readTime: '3 min read',
    coverImage: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=1200&auto=format&fit=crop',
    featured: false,
    tags: ['Tvista News', 'Awards', 'Excellence', 'Luxury Travel'],
    keyHighlights: [
      'Honored for personalized, client-centric itinerary curation and 99.4% visa approval track record',
      'Milestone of over 4,500 families and couples served across 42 global destination corridors',
      'Expansion of 24/7 dedicated travel concierge assistance on WhatsApp for traveling guests',
      'Launch of sustainable tourism partnerships in Ladakh, Bali, and African conservation reserves'
    ],
    content: `
### A Milestone in Our Journey of Crafting Memories

We are deeply honored to receive this recognition from the Luxury Travel Guild. Since our inception, Tvista Holidays has been driven by a single conviction: travel should never be an off-the-shelf commodity, but a deeply personal, flawlessly orchestrated story.

We extend our sincere gratitude to our valued travelers, our worldwide hotel and ground partners, and our passionate team of visa concierges, destination specialists, and flight managers.
    `,
    relatedDestination: 'Global'
  }
];
