export interface Package {
  id: number;
  title: string;
  location: string;
  image: string;
  duration: string;
  price: string;
  rating: number;
  reviews: number;
  tags: string[];
  description: string;
}

export const CATEGORIES = [
  'All',
  'Africa & Safari',
  'Ladakh & Himalayas',
  'India & Heritage',
  'Dubai & Middle East',
  'Egypt & Jordan',
  'Australia & NZ',
  'Europe & UK',
  'USA & Canada',
  'Bali & Southeast Asia',
  'Bhutan & Sri Lanka'
];

export const PACKAGES: Package[] = [
  {
    id: 1,
    title: 'Best of Safari with Mabula',
    location: 'South Africa, Africa',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=1200&auto=format&fit=crop',
    duration: '10N / 11D',
    price: '₹2,45,000',
    rating: 4.9,
    reviews: 142,
    tags: ['Africa & Safari', 'Safari', 'Big Five', 'Sun City'],
    description: `> **Best of Safari with Mabula**: A power packed South Africa tour package which will take you on safari, cruise, national parks, caves and much more. Experience the luxurious casinos and resorts of sun city, go on an adventurous jungle safari in Mabula game reserve and come eye to eye with the big 5: elephant, rhino, lion, buffalo and leopard.

### Day 1: Arrival in South Africa
Upon your arrival at Cape Town International Airport, please collect your bags and proceed toward the Arrival Hall. You will be met and assisted by an English-speaking Representative of Calculus Africa. Depart on a private road transfer to your hotel. Arrive and check-in at your hotel. Day free for own activities.

### Day 2: Cape Town & Table Mountain
Depart for Half Day City Tour of Cape Town with Table Mountain with your driver cum guide.
• Table Mountain (weather permitting): Take the famous cable car to the top for a panoramic view of the city and coastline.
• Must-do Helicopter Ride (10 mins) over open skies (optional).
• Half Day City Tour: Castle of Good Hope, City Hall, Adderley Street, St. George's Cathedral, Company Gardens, Malay Quarter, and Victoria & Alfred Waterfront.

### Day 3: Cape Town – Seal Island & Peninsula Tour
Proceed on your full day tour of Cape Point / Cape Peninsula.
• Breath-taking views of Clifton and Camps Bay with the 12 Apostles.
• Boat ride to Seal Island from Mariner’s Wharf.
• Scenic drive along world-famous Chapman’s Peak Drive to Cape of Good Hope Nature Reserve.
• Visit Simon’s Town and the African Penguins at Boulders Penguin Colony.
• Funicular "Flying Dutchman" up to old Cape Point lighthouse.

### Day 4: Cape Town – Knysna / George
Check out from the hotel and depart to Garden Route by private vehicle (+/- 6 Hours). Arrive at Knysna lagoon. Visit Knysna Heads cliffs and board John Benn Cruise to Featherbed Nature Reserve. Evening at leisure. Overnight in Knysna.

### Day 5: Knysna – Oudtshoorn Tour
Full day Oudtshoorn excursion. Visit Cango Caves for subterranean walks, Safari Ostrich Farm tractor tour, and Cango Wildlife Ranch with over 90 animal species. Return to hotel.

### Day 6: Knysna – Flight to Johannesburg – Sun City Resort
Transfer to George Airport for flight to Johannesburg/Lanseria. Private road transfer to Sun City Resort. Complimentary access to Valley of Waves waterpark, pools, and shuttle services. Overnight at Sun City.

### Day 7: Sun City Adventure Day
Enjoy thrill-seeking outdoor adventures: Pilanesberg Game Drives, Hot Air Ballooning, Quad Biking, Archery, Mountain Bike trails, and Chimp & Zee Rope Adventure. Overnight at hotel.

### Day 8: Sun City – Mabula Game Reserve
Transfer from Sun City to Mabula Game Reserve (+/- 2 Hours). Check-in at luxury safari lodge. Afternoon/evening game drive in open 4x4 vehicle. Dinner served at lodge.

### Day 9: Mabula Big 5 Game Drives
• 06h00 – Morning Game drive in open 4x4 vehicle spotting lions, leopards, rhinos, elephants, buffalos.
• 08h30 – Breakfast at the Lodge, followed by mid-morning leisure.
• 12h00 – Gourmet lunch at lodge.
• 16h00 – Evening sunset game drive.
• 20h00 – Bush dinner under the African stars.

### Day 10: Mabula Game Reserve – Gold Reef City – Johannesburg
Morning game drive and breakfast. Transfer to Johannesburg with en route stop at Gold Reef City theme park for thrilling rides. Check-in hotel in Johannesburg.

### Day 11: Johannesburg – Departure
Private transfer to Johannesburg OR Tambo International Airport for your departure flight.`
  },
  {
    id: 2,
    title: 'Classic South Africa',
    location: 'South Africa',
    image: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?q=80&w=1200&auto=format&fit=crop',
    duration: '10N / 11D',
    price: '₹2,35,000',
    rating: 4.8,
    reviews: 118,
    tags: ['Africa & Safari', 'Cape Town', 'Kruger', 'Wine Tasting'],
    description: `> **Classic South Africa**: Experience the crown jewels of South Africa: Cape Town, scenic Winelands, Garden Route coast, and the legendary Kruger National Park safari.

### Day 1: Arrival in Cape Town
Arrive at Cape Town International Airport, meet our local representative, transfer to hotel and relax. Overnight in Cape Town.

### Day 2: Cape Town City Tour & Table Mountain
Half-day city orientation including cable car ascent to Table Mountain (weather permitting), historic Malay Quarter, Company Gardens, and Castle of Good Hope. Overnight in Cape Town.

### Day 3: Seal Island & Cape Peninsula Tour
Full day tour of Cape Point. Boat ride to Seal Island from Mariner's Wharf, Chapman's Peak Drive, Boulders Beach penguin colony in Simon's Town, and Flying Dutchman funicular at Cape Point.

### Day 4: Cape Winelands Tasting
Explore world-class vineyards in Stellenbosch and Franschhoek. Wine tasting, artisanal cheese pairings, and picturesque valley scenery.

### Day 5: Cape Town to Knysna
Scenic drive along the Garden Route past Mossel Bay and Santos Beach. Arrive in Knysna lagoon. Overnight in Knysna.

### Day 6: Knysna & Oudtshoorn Heritage Tour
Excursion to Oudtshoorn: explore ancient limestone Cango Caves and Safari Ostrich Farm tractor tour. Overnight in Knysna.

### Day 7: Knysna – George – Flight to Johannesburg
Transfer to George Airport, flight to Johannesburg, and check-in to hotel.

### Day 8: Johannesburg to Kruger National Park
Flight to Hoedspruit / Kruger gateway. Transfer to safari lodge. Afternoon 15:00 game drive spotting the Big 5. Overnight in Kruger.

### Day 9: Full Day Kruger Game Drives
Early morning 06:00 open 4x4 game drive, lodge breakfast, and afternoon 14:00 safari drive. Bush dinner at lodge.

### Day 10: Kruger to Johannesburg
Morning safari, flight back to Johannesburg, and afternoon at leisure.

### Day 11: Johannesburg Departure
Transfer to OR Tambo International Airport for your onward flight.`
  },
  {
    id: 3,
    title: 'Kenya Earth Safari & Masai Mara',
    location: 'Kenya, Africa',
    image: 'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?q=80&w=1200&auto=format&fit=crop',
    duration: '7N / 8D',
    price: '₹1,85,000',
    rating: 4.9,
    reviews: 96,
    tags: ['Africa & Safari', 'Masai Mara', 'Wildlife', 'Samburu'],
    description: `> **Kenya Earth Safari & Masai Mara**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Kenya, Africa.

NAIROBI 1N – SAMBURU NATIONAL PARK 2N – LAKE NAKURU NATIONAL PARK 1N – MASAI MARA NATIONAL PARK 3N

### Day 1: Arrival in Nairobi
Meet and greet on arrival at Jomo Kenyatta International Airport. Transfer to hotel and overnight stay in Nairobi.

### Day 2: Nairobi to Samburu National Park
Transfer north crossing the Equator with Coriolis effect demonstration. Evening game drive in Samburu. Overnight in Samburu.

### Day 3: Full Day Samburu Wildlife Exploration
Full day viewing rare northern species (Gerenuk, Grevy's zebra, Reticulated giraffe). Optional camel ride and Samburu tribal cultural visit.

### Day 4: Samburu to Lake Nakuru National Park
Drive past Thomson's Falls nature trail to Lake Nakuru bird lover's paradise. Late afternoon safari drive around the flamingo-fringed alkaline lake.

### Day 5: Lake Nakuru to Masai Mara National Reserve
Drive into the fabled Masai Mara, home to the Great Migration and Big 5. Late afternoon game drive.

### Day 6: Full Day Masai Mara Safari
Full day game drive with picnic lunch across vast savanna plains tracking lions, cheetahs, leopards, elephants, and wildebeests.

### Day 7: Second Full Day Masai Mara
Morning and afternoon safari drives with optional hot air balloon sunrise safari over the Mara.

### Day 8: Masai Mara to Nairobi Departure
Final dawn game drive, breakfast, and transfer back to Nairobi for onward flight.`
  },
  {
    id: 4,
    title: 'Kenya Calling',
    location: 'Kenya, Africa',
    image: 'https://images.unsplash.com/photo-1534567153574-2b12153a87f0?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹1,65,000',
    rating: 4.8,
    reviews: 84,
    tags: ['Africa & Safari', 'Amboseli', 'Masai Mara', 'Kilimanjaro Views'],
    description: `> **Kenya Calling**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Kenya, Africa.

2N AMBOSELI NATIONAL PARK – 1N LAKE NAKURU NATIONAL PARK – 3N MASAI MARA NATIONAL PARK

### Day 1: Nairobi to Amboseli National Park
Meet at Jomo Kenyatta Airport and depart for Amboseli. Arrive for lunch and embark on an afternoon game drive with views of Mount Kilimanjaro.

### Day 2: Amboseli National Park
Early morning and late afternoon game drives observing huge elephant herds against the snow-capped peak of Kilimanjaro.

### Day 3: Amboseli to Lake Nakuru National Park
Drive to Lake Nakuru National Park. Immediate game viewing upon entering the park gate. Overnight in Lake Nakuru.

### Day 4: Lake Nakuru to Masai Mara
Transfer to the Mara Reserve. Afternoon game drive safari. Overnight in Masai Mara.

### Day 5: Masai Mara Morning & Evening Safaris
Morning and afternoon game drives tracking predators and plains game.

### Day 6: Full Day Masai Mara Expedition
Full day traversing the Mara plains with packed lunch.

### Day 7: Masai Mara to Nairobi Drop-off
Final morning safari drive, breakfast, and transfer to Nairobi CBD / Airport.`
  },
  {
    id: 5,
    title: 'Kenya Gateway (Tanzania, Serengeti & Zanzibar)',
    location: 'Tanzania & Zanzibar, Africa',
    image: 'https://images.unsplash.com/photo-1516426122078-c23e76319801?q=80&w=1200&auto=format&fit=crop',
    duration: '10N / 11D',
    price: '₹2,95,000',
    rating: 5.0,
    reviews: 112,
    tags: ['Africa & Safari', 'Serengeti', 'Ngorongoro', 'Zanzibar'],
    description: `> **Kenya Gateway (Tanzania, Serengeti & Zanzibar)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Tanzania & Zanzibar, Africa.

02N ARUSHA – 01N LAKE MANYARA – 02N SERENGETI – 02N NGORONGORO – 03N ZANZIBAR

### Day 1: Arrive in Arusha
Meet at airport and transfer to hotel with safari briefing. Evening at leisure.

### Day 2: Arusha to Tarangire National Park
Safari drive through Tarangire, famous for ancient baobab trees and large elephant herds.

### Day 3: Lake Manyara National Park
Drive to Lake Manyara. Afternoon game drive searching for tree-climbing lions and flamingoes.

### Day 4: Lake Manyara to Serengeti National Park
Drive into the endless plains of the Serengeti. Sunset game drive.

### Day 5: Full Day Serengeti Safari
Full day tracking the Great Migration and big cats across northern and central Serengeti. Optional sunrise hot air balloon.

### Day 6: Serengeti to Ngorongoro Conservation Area
Scenic drive to the rim of Ngorongoro Crater with afternoon game drive.

### Day 7: Ngorongoro Crater Floor Safari
Descend 600 meters into the volcanic caldera for world-class wildlife viewing including black rhinos and pride of lions.

### Day 8: Ngorongoro to Flight to Zanzibar
Drive to Arusha, lunch, transfer to Kilimanjaro Airport for flight to the tropical spice island of Zanzibar.

### Day 9: Zanzibar Beach Leisure
Relax on white powdery sand beaches or explore Stone Town UNESCO historic quarter.

### Day 10: Zanzibar Island Exploration
Full day exploring spice plantations, snorkeling at Mnemba Atoll, or sunset dhow cruise.

### Day 11: Zanzibar Departure
Transfer to Zanzibar Airport for your return flight.`
  },
  {
    id: 6,
    title: 'Kruger Calling & Garden Route',
    location: 'South Africa',
    image: 'https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?q=80&w=1200&auto=format&fit=crop',
    duration: '10N / 11D',
    price: '₹2,40,000',
    rating: 4.9,
    reviews: 130,
    tags: ['Africa & Safari', 'Kruger', 'Sun City', 'Garden Route'],
    description: `> **Kruger Calling & Garden Route**: Sun City, Kruger National Park, Johannesburg, Garden Route & Cape Town.

### Day 1: Johannesburg to Sun City Resort
Private transfer to Sun City. Complimentary access to Valley of Waves waterpark.

### Day 2: Sun City Outdoor Adventures
Pilanesberg game drives, hot air ballooning, and resort entertainment.

### Day 3: Sun City to Kruger National Park
Transfer to Kruger safari lodge (+/- 6 Hours). Afternoon game drive and bush dinner.

### Day 4: Big 5 Safari in Kruger
06h00 morning safari drive in open 4x4, mid-day lodge relaxation, and 16h00 sunset game drive.

### Day 5: Kruger to Johannesburg
Dawn game drive, breakfast, and transfer to Johannesburg.

### Day 6: Johannesburg to Garden Route (Knysna)
Flight to George Airport. Transfer to Knysna, lagoon lookout, and John Benn cruise.

### Day 7: Knysna & Oudtshoorn Tour
Cango Caves, Safari Ostrich Farm tractor tour, and Cango Wildlife Ranch.

### Day 8: Knysna to Cape Town
Scenic coastal drive to Cape Town. Evening at leisure.

### Day 9: Cape Town City & Table Mountain
Cable car up Table Mountain, Malay Quarter, and V&A Waterfront.

### Day 10: Cape Point & Boulders Penguins
Chapman's Peak Drive, Boulders Beach penguins, and Flying Dutchman funicular.

### Day 11: Cape Town Departure
Transfer to Cape Town International Airport.`
  },
  {
    id: 7,
    title: 'South Africa with Seychelles Island',
    location: 'South Africa & Seychelles',
    image: 'https://images.unsplash.com/photo-1589553416260-f586c8f1514f?q=80&w=1200&auto=format&fit=crop',
    duration: '13N / 14D',
    price: '₹3,40,000',
    rating: 5.0,
    reviews: 89,
    tags: ['Africa & Safari', 'Seychelles', 'Cape Town', 'Sun City'],
    description: `> **South Africa with Seychelles Island**: The ultimate luxury combo: 3 Nights in exotic Seychelles followed by South Africa's Sun City, Garden Route safari and Cape Town.

### Day 01 - 03: Tropical Paradise in Mahé, Seychelles
Arrive in Mahé, check-in to luxury beachfront resort. Leisure days exploring granite boulders, coral reefs, and turquoise lagoons.

### Day 4: Mahé to Johannesburg
Flight to Johannesburg, transfer to hotel.

### Day 5: Johannesburg to Sun City
Drive to Sun City entertainment resort. Valley of Waves and optional quad biking.

### Day 6: Sun City – George – Mossel Bay
Flight to George, transfer to Mossel Bay, tidal pool relaxation and Cape St. Blaize lighthouse hike.

### Day 7: Mossel Bay to Oudtshoorn
Cango Caves stalactites, Ostrich riding farm, and Cheetah Land wildlife ranch.

### Day 8: Mossel Bay Adventure
Helicopter coastal flip, 4-wheel quad bike safari, or speed boat rides.

### Day 9: Mossel Bay to Knysna & Bloukrans Bridge
Bloukrans Bungee Jump stop and Knysna Lagoon river cruise.

### Day 10: Game Lodge Safari
Open vehicle game drive spotting lions, leopards, elephants, buffalos, and rhinos.

### Day 11: Cape Town Arrival & Canal Walk
Transfer to Cape Town, shopping at Canal Walk complex.

### Day 12: Cape Point & Seal Island
Boulders Beach penguins, Cape of Good Hope, Seal Island cruise, and V&A Waterfront.

### Day 13: Table Mountain & City Orientation
Cable car to Table Mountain summit, Green Market Square, and Signal Hill.

### Day 14: Departure
Transfer to airport for return flight.`
  },
  {
    id: 8,
    title: 'Zambia, Victoria Falls & Okavango Delta',
    location: 'Zambia & Botswana, Africa',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹2,60,000',
    rating: 4.9,
    reviews: 77,
    tags: ['Africa & Safari', 'Victoria Falls', 'Okavango Delta', 'Chobe'],
    description: `> **Zambia, Victoria Falls & Okavango Delta**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Zambia & Botswana, Africa.

LIVINGSTONE 2N – CHOBE NATIONAL PARK 2N – OKAVANGO DELTA 2N

### Day 1: Livingstone & Zambezi Sunset Cruise
Arrival in Livingstone, transfer to safari lodge. Zambezi river sunset cruise with refreshments.

### Day 2: Victoria Falls Dual-Side Tour & Rhino Walk
Guided tour of Victoria Falls from both Zimbabwean and Zambian sides, followed by a guided rhino tracking walk.

### Day 3: Helicopter Flight over Falls to Chobe (Botswana)
15-minute scenic helicopter flight over the thundering Victoria Falls. Border transfer to Botswana's Chobe Safari Lodge.

### Day 4: Chobe River Cruise & Safari Drives
Famous Chobe River boat safari with massive elephant herds drinking at the water's edge and afternoon 4x4 game drive.

### Day 5: Chobe to Okavango Delta Air Transfer
Light aircraft bush flight into the pristine Okavango Delta waterways. Mokoro canoe safari and walking trail.

### Day 6: Okavango Delta Wildlife Safari
Morning and afternoon water and land safaris in the world's largest inland wetland delta.

### Day 7: Okavango Delta to Livingstone Departure
Air transfer to Kasane and road transfer to Livingstone Airport.`
  },
  {
    id: 9,
    title: 'Valley of Flowers & Hemkund Sahib Trek',
    location: 'Uttarakhand, Himalayas',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=1200&auto=format&fit=crop',
    duration: '5N / 6D',
    price: '₹28,500',
    rating: 4.9,
    reviews: 215,
    tags: ['Ladakh & Himalayas', 'Trek', 'UNESCO', 'Nature'],
    description: `> **Valley of Flowers & Hemkund Sahib Trek**: Valley of Flowers is a UNESCO World Heritage site home to 500+ rare species of alpine flora and fauna. Hemkund Sahib is a holy high-altitude lake and Gurudwara situated at 4,300 meters.

### Day 1: Arrival at Joshimath
Arrival at Joshimath, check-in to guest house, trek briefing, and overnight stay.

### Day 2: Joshimath to Govindghat to Ghangaria
Drive 20 km to Govindghat / Poolna. Trek 13 km along the roaring Pushpawati River to Ghangaria base camp.

### Day 3: Ghangaria to Valley of Flowers to Ghangaria
Trek 4 km into the UNESCO Valley of Flowers (8 km total). Witness carpets of Brahmakamal, Blue Poppies, and alpine streams.

### Day 4: Ghangaria to Hemkund Sahib to Ghangaria
Steep 6 km uphill trek (12 km total) to the sacred Hemkund Sahib glacial lake at 14,100 ft. Return to Ghangaria.

### Day 5: Ghangaria to Govindghat to Joshimath
Descend 13 km to Govindghat and drive back to Joshimath.

### Day 6: Departure from Joshimath
Check out after breakfast for onward journey.`
  },
  {
    id: 10,
    title: '7 Days Around Leh & Pangong Lake',
    location: 'Ladakh, India',
    image: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹38,500',
    rating: 4.9,
    reviews: 180,
    tags: ['Ladakh & Himalayas', 'Ladakh', 'Pangong Lake', 'Khardung La'],
    description: `> **7 Days Around Leh & Pangong Lake**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Ladakh, India.

LEH – KHARDUNG LA – NUBRA VALLEY – SIACHEN BASE CAMP – PANGONG LAKE – SHAM VALLEY

### Day 1: Arrival at Leh Airport (Acclimatization)
Arrive at Kushok Bakula Airport (3,500m). Full day mandatory rest for high-altitude acclimatization.

### Day 2: Leh to Nubra Valley via Khardung La Pass (150 km / 5 hrs)
Drive over the World's highest motorable pass (18,380 ft). Diskit Monastery and double-humped Bactrian camel safari at Hunder sand dunes.

### Day 3: Nubra to Sumoor & Siachen Base Camp Excursion
Excursion to Sumoor, Panamik natural hot springs, and Siachen Base Camp view point.

### Day 4: Sumoor to Pangong Lake via Warila / Shayok
Scenic high mountain drive to breathtaking Pangong Tso Lake (14,270 ft). Overnight in lakeside luxury camps.

### Day 5: Pangong Lake to Leh
Sunrise over turquoise Pangong Lake. Return drive via Changla Pass and Rancho's School.

### Day 6: Sham Valley Sightseeing
Hall of Fame military museum, Spituk Monastery, Sangam (Zanskar & Indus confluence), Magnetic Hill, and Gurudwara Pathar Sahib.

### Day 7: Departure from Leh
Airport drop for onward flight.`
  },
  {
    id: 11,
    title: 'Beautiful Ladakh (High Altitude Lakes & Passes)',
    location: 'Ladakh, India',
    image: 'https://images.unsplash.com/photo-1506197603052-3cc9c3a201bd?q=80&w=1200&auto=format&fit=crop',
    duration: '8N / 9D',
    price: '₹52,000',
    rating: 5.0,
    reviews: 145,
    tags: ['Ladakh & Himalayas', 'Pangong', 'Tso Moriri', 'Khardung La'],
    description: `> **Beautiful Ladakh (High Altitude Lakes & Passes)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Ladakh, India.

LEH – SHAM VALLEY – ALCHI – KHARDUNG LA – NUBRA VALLEY – PANGONG TSO – TSO MORIRI – TSO KAR

### Day 1: Arrival in Leh
Rest and acclimatization. Evening walk in historic Leh Bazaar.

### Day 2: Sham Valley & Alchi Monastery
Magnetic Hill, Gurudwara Patthar Sahib, Sangam point, Alchi Monastery (1000-year-old frescoes), and Hall of Fame.

### Day 3: Leh to Nubra Valley via Khardung La
Cross Khardung La (18,390 ft). Hunder sand dunes and double-humped camel safari.

### Day 4: Nubra Valley to Leh
Diskit Monastery Maitreya Buddha statue and scenic return to Leh.

### Day 5: Leh to Pangong Tso Lake via Chang La
Drive through Chang La Pass (17,586 ft) to the blue waters of Pangong Tso. Camp stay.

### Day 6: Pangong Tso to Leh
Thiksey Monastery and Sindhu Ghat cultural stop.

### Day 7: Leh to Tso Moriri Lake (15,000 ft)
Drive via Chumathang hot springs to the secluded, pristine alpine sanctuary of Tso Moriri Lake.

### Day 8: Tso Moriri to Tso Kar Lake to Leh
Cross Polokongka Pass, visit the white salt lake Tso Kar, and cross Taglang La Pass (17,585 ft) to Leh.

### Day 9: Departure from Leh
Transfer to Leh Airport.`
  },
  {
    id: 12,
    title: 'A Romantic Sri Lanka Honeymoon',
    location: 'Sri Lanka',
    image: 'https://images.unsplash.com/photo-1546708973-b339540b5162?q=80&w=1200&auto=format&fit=crop',
    duration: '4N / 5D',
    price: '₹62,000',
    rating: 4.8,
    reviews: 135,
    tags: ['Bhutan & Sri Lanka', 'Honeymoon', 'Kandy', 'Bentota Beach'],
    description: `> **A Romantic Sri Lanka Honeymoon**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Sri Lanka.

KANDY – NUWARA ELIYA – BENTOTA – COLOMBO

### Day 1: Colombo to Kandy
Meet at airport, visit Pinnawala Elephant Orphanage, Royal Botanical Gardens, and Temple of the Tooth Relic.

### Day 2: Kandy to Nuwara Eliya (Little England)
Ramboda Waterfalls, tea plantation & factory tour, Gregory Lake, and Seetha Amman Temple.

### Day 3: Nuwara Eliya to Bentota Golden Beaches
Drive to coastal Bentota. Madu River mangrove boat safari and Kosgoda Turtle Hatchery.

### Day 4: Bentota to Colombo City Tour
National Museum, Old Parliament, Independence Square, and souvenir shopping.

### Day 5: Colombo Departure
Breakfast and transfer to Bandaranaike International Airport.`
  },
  {
    id: 13,
    title: 'Adventurous Sri Lanka & Yala Safari',
    location: 'Sri Lanka',
    image: 'https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹74,000',
    rating: 4.9,
    reviews: 110,
    tags: ['Bhutan & Sri Lanka', 'Sigiriya', 'Yala Safari', 'Leopards'],
    description: `> **Adventurous Sri Lanka & Yala Safari**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Sri Lanka.

SIGIRIYA – KANDY – NUWARA ELIYA – YALA NATIONAL PARK – BENTOTA – COLOMBO

### Day 1: Colombo to Sigiriya
Pinnawala Elephant Orphanage stop, arrival in Sigiriya.

### Day 2: Sigiriya Rock Fortress to Kandy
Climb the 5th-century UNESCO Sigiriya Rock Fortress, Dambulla Cave Temples, and Temple of Tooth in Kandy.

### Day 3: Kandy to Nuwara Eliya
Scenic tea hill country, Ramboda Falls, and colonial Nuwara Eliya.

### Day 4: Nuwara Eliya to Yala National Park
4x4 Jeep Safari in Yala National Park, tracking leopards, elephants, and sloth bears.

### Day 5: Yala to Bentota Beach
Galle Dutch Fort UNESCO walk, Turtle Hatchery, and golden sand beaches.

### Day 6: Bentota to Colombo
Colombo city tour and shopping at Odel and Laksala.

### Day 7: Colombo Departure
Transfer to airport.`
  },
  {
    id: 14,
    title: 'Amazing Bhutan & Tiger\'s Nest',
    location: 'Bhutan',
    image: 'https://images.unsplash.com/photo-1578637387939-43c525550085?q=80&w=1200&auto=format&fit=crop',
    duration: '5N / 6D',
    price: '₹78,000',
    rating: 5.0,
    reviews: 95,
    tags: ['Bhutan & Sri Lanka', 'Tiger\'s Nest', 'Thimphu', 'Punakha Dzong'],
    description: `> **Amazing Bhutan & Tiger\'s Nest**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Bhutan.

PARO – THIMPHU – DOCHULA PASS – PUNAKHA – TAKTSANG TIGER'S NEST

### Day 1: Arrive Paro – Transfer to Thimphu
Scenic flight past Himalayan peaks. Drive to Thimphu, visit Trashi Chhoe Dzong and National Library.

### Day 2: Thimphu Capital Sightseeing
Buddha Dordenma (Giant Golden Buddha), National Memorial Chorten, and Takin Zoo.

### Day 3: Thimphu to Punakha via Dochula Pass
Stop at 3,100m Dochula Pass with 108 stupas and Himalayan panoramas. Visit Punakha Dzong at the confluence of Pho Chhu and Mo Chhu rivers, and the long suspension bridge.

### Day 4: Punakha to Paro
National Museum of Bhutan (Ta Dzong), Rinpung Dzong, and Nya Mey Zam bridge.

### Day 5: Hike to Taktsang Monastery (Tiger's Nest)
Hike to the legendary Tiger's Nest Monastery perched on a sheer 900m granite cliff. Visit Kyichu Lhakhang.

### Day 6: Depart Paro Airport
Transfer to airport for return flight.`
  },
  {
    id: 15,
    title: 'Amazing Bali & Nusa Lembongan',
    location: 'Bali, Indonesia',
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹68,000',
    rating: 4.9,
    reviews: 165,
    tags: ['Bali & Southeast Asia', 'Ubud', 'Uluwatu', 'Waterfalls'],
    description: `> **Amazing Bali & Nusa Lembongan**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Bali, Indonesia.

UBUD – TEGENUNGAN – TANJUNG BENOA – ULUWATU – KINTAMANI VOLCANO – LOVINA DOLPHINS – SPA

### Day 1: Airport Pickup & Leisure
Arrive at Ngurah Rai Airport, transfer to resort.

### Day 2: Ubud Culture & Tegenungan Waterfall
Barong dance, Celuk silversmiths, Batuan paintings, Tegenungan Waterfall, Tegalalang Rice Terraces, and Ubud Royal Palace.

### Day 3: Tanjung Benoa Watersports & Uluwatu Sunset
Banana boat, flying fish, turtle island, GWK cultural park, Uluwatu cliff temple, and Kecak Fire Dance with Jimbaran seafood dinner.

### Day 4: Kintamani Volcano & Tanah Lot Sunset
Tirta Empul holy springs, Mount Batur volcano view with buffet lunch, Taman Ayun temple, and Tanah Lot sea temple sunset.

### Day 5: Lovina Dolphin Boat Tour & North Bali
Early morning boat to spot wild dolphins, Banjar hot springs, Gitgit waterfall, and Ulun Danu Beratan temple on the lake.

### Day 6: Denpasar City Tour & 2-Hour Balinese Spa
Badung traditional market, Bali Museum, Bajra Sandhi monument, and 2-hour luxury massage treatment.

### Day 7: Departure Transfer
Transfer to airport.`
  },
  {
    id: 16,
    title: 'Alluring Siem Reap & Phnom Penh',
    location: 'Cambodia',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=1200&auto=format&fit=crop',
    duration: '4N / 5D',
    price: '₹58,000',
    rating: 4.8,
    reviews: 82,
    tags: ['Bali & Southeast Asia', 'Angkor Wat', 'Siem Reap', 'Mekong Cruise'],
    description: `> **Alluring Siem Reap & Phnom Penh**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Cambodia.

SIEM REAP – TONLE SAP – ANGKOR WAT – PHNOM PENH – ROYAL PALACE – MEKONG CRUISE

### Day 1: Siem Reap Arrival & Floating Village
Boat ride on Tonle Sap Lake exploring floating villages and stilted houses. Apsara Dinner Show.

### Day 2: Angkor Wat & Angkor Thom Complex
South Gate of Angkor Thom, Bayon temple with 200 smiling stone faces, Ta Prohm (Tomb Raider temple), and the grand Angkor Wat temple complex.

### Day 3: Siem Reap to Phnom Penh
Scenic transfer past Spider Market. Visit Royal Palace, Silver Pagoda (90kg gold Buddha), and Wat Phnom.

### Day 4: Phnom Penh History & Sunset Cruise
Tuol Sleng Genocide Museum, Russian Market, and sunset cruise on Mekong and Tonle Sap rivers.

### Day 5: Phnom Penh Departure
Shopping and transfer to airport.`
  },
  {
    id: 17,
    title: 'Blissful Vietnam & Cambodia',
    location: 'Vietnam & Cambodia',
    image: 'https://images.unsplash.com/photo-1528127269322-539801943592?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹89,000',
    rating: 4.9,
    reviews: 104,
    tags: ['Bali & Southeast Asia', 'Halong Bay', 'Angkor Wat', 'Hanoi'],
    description: `> **Blissful Vietnam & Cambodia**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Vietnam & Cambodia.

HANOI – HALONG BAY OVERNIGHT CRUISE – SIEM REAP – ANGKOR WAT – TONLE SAP

### Day 1: Hanoi Arrival
Arrival, transfer to hotel, evening walk around Hoan Kiem Lake.

### Day 2: Halong Bay Luxury Cruise
Board cruise in Halong Bay. Kayaking through emerald waters, exploring Sung Sot (Surprise) Cave, sunset party on deck, and squid fishing.

### Day 3: Pearl Farm & Return to Hanoi
Morning Tai Chi, pearl farm tour, cooking class, and return to Hanoi.

### Day 4: Hanoi City Tour to Siem Reap
Temple of Literature and Museum of Ethnology. Flight to Siem Reap.

### Day 5: Angkor Wat & Bayon Temples
Angkor Thom, Bayon stone faces, Ta Prohm, and sunset over Angkor Wat.

### Day 6: Tonle Sap Floating Village
Boat cruise on Tonle Sap lake visiting floating schools and villages.

### Day 7: Siem Reap Departure
Airport transfer for return flight.`
  },
  {
    id: 18,
    title: 'Bangkok & Pattaya Family Tour',
    location: 'Thailand',
    image: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?q=80&w=1200&auto=format&fit=crop',
    duration: '5N / 6D',
    price: '₹44,000',
    rating: 4.7,
    reviews: 190,
    tags: ['Bali & Southeast Asia', 'Bangkok', 'Pattaya', 'Coral Island', 'Family'],
    description: `> **Bangkok & Pattaya Family Tour**: BANGKOK & PATTAYA

### Day 1: Bangkok to Pattaya
Meet at Suvarnabhumi Airport, coastal drive to Pattaya, and evening at leisure.

### Day 2: Koh Larn Coral Island by Speedboat
Speedboat to Coral Island. Water activities, parasailing, snorkeling, and seafood lunch.

### Day 3: Nong Nooch Botanical Gardens
500-acre tropical gardens, orchid nursery, elephant shows, and Thai cultural performances.

### Day 4: Pattaya to Bangkok Temple Tour
Wat Traimit (Golden Buddha) and Wat Pho (Reclining Buddha). Evening shopping.

### Day 5: Safari World & Marine Park
Open safari drive with wild animals and Marine Park dolphin & sea lion shows.

### Day 6: Bangkok Departure
Transfer to airport.`
  },
  {
    id: 19,
    title: 'Best of South Korea (Jeju, Nami, DMZ & Seoul)',
    location: 'South Korea',
    image: 'https://images.unsplash.com/photo-1538485399081-7191377e8241?q=80&w=1200&auto=format&fit=crop',
    duration: '7N / 8D',
    price: '₹1,65,000',
    rating: 4.9,
    reviews: 98,
    tags: ['Bali & Southeast Asia', 'Seoul', 'Jeju Island', 'Nami Island', 'DMZ'],
    description: `> **Best of South Korea (Jeju, Nami, DMZ & Seoul)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across South Korea.

SEOUL – JEJU ISLAND – NAMI ISLAND – DMZ – GANGNAM

### Day 1: Arrive Seoul & Flight to Jeju Island
Arrival at Incheon, transfer to Gimpo, flight to UNESCO Jeju Island.

### Day 2: Full Day Jeju West Coast Tour
Hyupjae Beach, Hallim Park caves, Suweolbong trek, O’Sulloc Green Tea Garden, and Mt. Sanbang.

### Day 3: Jeju East Coast Tour & Flight to Seoul
Horseback riding, Seongeup Folk Village, Seongsan Ilchulbong Sunrise Peak, and Manjanggul lava cave. Flight to Seoul.

### Day 4: Nami Island & Petite France
Ferry to romantic Nami Island (Winter Sonata film site) and French cultural village Petite France.

### Day 5: Korean DMZ Border Tour
Imjingak Pavilion, 3rd Infiltration Tunnel, Dora Observatory looking into North Korea, and Dorasan Station.

### Day 6: Historic & Modern Seoul
Gyeongbokgung Palace, National Folk Museum, N Seoul Tower on Namsan mountain, and Namsan Hanok Village.

### Day 7: Dongdaemun Design Plaza & Gangnam
DDP architecture, Gwangjang Market, and luxury shopping in Garosu-gil Gangnam.

### Day 8: Seoul Departure
Transfer to Incheon Airport.`
  },
  {
    id: 20,
    title: 'Dazzling Dubai & Abu Dhabi',
    location: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=1200&auto=format&fit=crop',
    duration: '4N / 5D',
    price: '₹58,000',
    rating: 4.8,
    reviews: 240,
    tags: ['Dubai & Middle East', 'Burj Khalifa', 'Desert Safari', 'Abu Dhabi'],
    description: `> **Dazzling Dubai & Abu Dhabi**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Dubai, UAE.

DUBAI CITY – BURJ KHALIFA – DESERT SAFARI – ABU DHABI GRAND MOSQUE

### Day 1: Dubai Arrival & Dhow Creek Cruise
Arrival, check-in, and evening traditional Dhow Cruise with dinner along Dubai Creek.

### Day 2: Dubai City Tour, Burj Khalifa & Aquarium
Jumeirah Mosque, Burj Al Arab photo stop, Dubai Palm Island, Burj Khalifa 124th Floor observation deck, and Dubai Aquarium.

### Day 3: 4x4 Desert Safari & BBQ Dinner
Thrilling red dune bashing in 4x4 vehicles, sandboarding, camel rides, tanoura dance, belly dancing, and BBQ buffet under desert stars.

### Day 4: Full Day Abu Dhabi & Sheikh Zayed Grand Mosque
Day tour to Abu Dhabi visiting the magnificent Sheikh Zayed Grand Mosque and Ferrari World.

### Day 5: Departure
Shopping at Gold Souk and transfer to DXB Airport.`
  },
  {
    id: 21,
    title: 'Marvellous Dubai & Theme Parks',
    location: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=1200&auto=format&fit=crop',
    duration: '8N / 9D',
    price: '₹98,000',
    rating: 4.9,
    reviews: 175,
    tags: ['Dubai & Middle East', 'Atlantis Aquaventure', 'Museum of Future', 'Ferrari World'],
    description: `> **Marvellous Dubai & Theme Parks**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Dubai, UAE.

BURJ KHALIFA – ATLANTIS AQUAVENTURE – DUBAI PARKS – GREEN PLANET – MUSEUM OF THE FUTURE

### Day 1: Arrival in Dubai
Check-in and evening at leisure.

### Day 2: Dubai City Tour & Burj Khalifa
Historic Bastakiya district, Abra water taxi, Gold Souk, Burj Khalifa, and Dubai Mall Fountains.

### Day 3: Desert Safari with BBQ Dinner
Dune bashing, camel farm visit, quad biking (optional), and live Arabic shows with buffet.

### Day 4: Atlantis Aquaventure & Lost Chambers
Full day access to Aquaventure Waterpark and underwater Lost Chambers Aquarium on Palm Jumeirah.

### Day 5: Abu Dhabi City Tour & Ferrari World
Sheikh Zayed Grand Mosque and high-speed rides at Ferrari World Abu Dhabi.

### Day 6: Dubai Parks & Resorts (Motiongate + Bollywood)
Full day thrills across two international theme parks.

### Day 7: Green Planet Rainforest & Marina Dinner Cruise
Indoor tropical rainforest biodome with 3,000 plants & animals, and Dubai Marina luxury yacht cruise.

### Day 8: Museum of the Future
Visit the architectural marvel Museum of the Future.

### Day 9: Departure
Transfer to Dubai Airport.`
  },
  {
    id: 22,
    title: 'Beautiful Egypt, Cairo & Nile Cruise',
    location: 'Egypt',
    image: 'https://images.unsplash.com/photo-1539768942893-daf53e448371?q=80&w=1200&auto=format&fit=crop',
    duration: '7N / 8D',
    price: '₹1,35,000',
    rating: 4.9,
    reviews: 130,
    tags: ['Egypt & Jordan', 'Pyramids of Giza', 'Nile Cruise', 'Luxor'],
    description: `> **Beautiful Egypt, Cairo & Nile Cruise**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Egypt.

CAIRO – GIZA PYRAMIDS – ASWAN – PHILAE TEMPLE – NILE CRUISE – KOM OMBO – EDFU – LUXOR VALLEY OF KINGS

### Day 1: Arrival in Cairo
Meet and assist at Cairo International Airport. Transfer to hotel.

### Day 2: Pyramids of Giza, Sphinx & Sleeper Train
Great Pyramids of Cheops, Chephren, and Mykerinus, the Great Sphinx, Papyrus Institute, and Egyptian Museum. Board sleeper train to Aswan.

### Day 3: Aswan & Nile Cruise Check-in
Arrive in Aswan, board 5-star Nile Cruise. Visit Philae Temple on Agilkia Island and the High Dam.

### Day 4: Sailing the Nile to Kom Ombo & Edfu
Sail to Kom Ombo Crocodile Temple, then navigate to the Temple of Horus in Edfu.

### Day 5: Luxor West Bank & Valley of the Kings
Sail to Luxor. Visit Valley of the Kings, Temple of Queen Hatshepsut, and Colossi of Memnon.

### Day 6: Luxor East Bank & Sleeper Train to Cairo
Explore Karnak Temple complex and Luxor Temple. Board sleeper train back to Cairo.

### Day 7: Cairo Khan El Khalili Bazaar
Arrive in Cairo, explore historic Khan El Khalili bazaar.

### Day 8: Cairo Departure
Transfer to Cairo Airport for flight back home.`
  },
  {
    id: 23,
    title: 'Israel, Jordan & Cairo Grand Expedition',
    location: 'Israel, Jordan & Egypt',
    image: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?q=80&w=1200&auto=format&fit=crop',
    duration: '14N / 15D',
    price: '₹3,10,000',
    rating: 5.0,
    reviews: 88,
    tags: ['Egypt & Jordan', 'Petra', 'Jerusalem', 'Pyramids', 'Dead Sea'],
    description: `> **Israel, Jordan & Cairo Grand Expedition**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Israel, Jordan & Egypt.

TEL AVIV – JERUSALEM – DEAD SEA – PETRA – WADI RUM – CAIRO

### DAY 01 - 03: Tel Aviv, Galilee & Nazareth
Caesarea Roman aqueduct, Haifa Bahai gardens, Nazareth Church of Annunciation, Sea of Galilee boat ride, and Mount of Beatitudes.

### DAY 04 - 06: Jerusalem & Bethlehem
Old City of Jerusalem, Western (Wailing) Wall, Via Dolorosa, Church of Holy Sepulchre, Mount of Olives, and Bethlehem Church of Nativity.

### DAY 07 - 08: Jordan Border, Jerash & Amman
Cross Sheik Hussein Bridge, explore Jerash Roman ruins, Desert Castles, Madaba mosaic map, and Mount Nebo.

### DAY 09 - 10: Dead Sea & Dana Biosphere
Float in the mineral-rich Dead Sea, Lot's Cave, and Dana mountain village.

### DAY 11 - 12: Petra Wonder of the World & Wadi Rum Desert
Walk through the Siq to Petra Treasury and carved tombs. 4x4 Jeep safari and camel trek through Wadi Rum desert.

### DAY 13 - 15: Flight to Cairo & Pyramids of Giza
Flight to Cairo. Full day exploring Giza Pyramids, Sphinx, Egyptian Museum, and Saladin Citadel.`
  },
  {
    id: 24,
    title: 'Wonderful Turkey & Cappadocia Balloon',
    location: 'Turkey',
    image: 'https://images.unsplash.com/photo-1527838832700-5059252407fa?q=80&w=1200&auto=format&fit=crop',
    duration: '10N / 11D',
    price: '₹1,92,000',
    rating: 4.9,
    reviews: 140,
    tags: ['Dubai & Middle East', 'Cappadocia', 'Hot Air Balloon', 'Ephesus', 'Istanbul'],
    description: `> **Wonderful Turkey & Cappadocia Balloon**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Turkey.

ISTANBUL – CAPPADOCIA – PAMUKKALE – EPHESUS – ANTALYA

### DAY 01 - 03: Istanbul to Cappadocia & Hot Air Balloon
Flight to Cappadocia. Sunrise Hot Air Balloon flight over fairy chimneys, Goreme Open Air Museum, Devrent Valley, and Kaymakli Underground City.

### DAY 04 - 05: Kusadasi & Pamukkale Travertines
Flight to Kusadasi. Walk on the white calcium terraces of Pamukkale and explore Hierapolis Roman spa city.

### Day 6: Ephesus Ancient City & Virgin Mary\'s House
Explore Ephesus Celsus Library, Great Theatre, Temple of Hadrian, and House of Virgin Mary.

### DAY 07 - 08: Istanbul Bosphorus Cruise & Old City Highlights
Flight to Istanbul. Bosphorus Dinner Cruise, Blue Mosque, Hagia Sophia, Topkapi Palace, and Grand Bazaar.

### DAY 09 - 11: Antalya Turquoise Coast & Departure
Duden Waterfalls, Kaleici historic town walking tour, Tunektepe cable car, and departure transfer.`
  },
  {
    id: 25,
    title: 'Best of Australia Coast to Coast',
    location: 'Australia',
    image: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?q=80&w=1200&auto=format&fit=crop',
    duration: '8N / 9D',
    price: '₹2,85,000',
    rating: 4.9,
    reviews: 160,
    tags: ['Australia & NZ', 'Sydney Opera House', 'Great Barrier Reef', 'Melbourne'],
    description: `> **Best of Australia Coast to Coast**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Australia.

SYDNEY – GOLD COAST – CAIRNS GREAT BARRIER REEF – MELBOURNE GREAT OCEAN ROAD

### DAY 1 - 2: Sydney Opera House & Sea Life
Sydney Tower Observatory deck, guided tour inside Sydney Opera House, Darling Harbour, Bondi Beach, and Sydney Showboat Dinner Cruise.

### DAY 3 - 4: Brisbane & Gold Coast Movie World
Currumbin Wildlife Sanctuary (kangaroos & koalas) and Warner Bros. Movie World thrill rides.

### DAY 5 - 6: Cairns & The Great Barrier Reef
Kuranda Skyrail Rainforest cableway, aboriginal cultural show, and full-day catamaran cruise to Great Barrier Reef with glass-bottom boat & semi-submersible.

### DAY 7 - 8: Melbourne, Phillip Island & Great Ocean Road
Melbourne city tram, Phillip Island Penguin Parade, and scenic Great Ocean Road tour viewing the 12 Apostles with optional helicopter ride.

### Day 9: Melbourne Departure
City orientation tour and transfer to airport.`
  },
  {
    id: 26,
    title: 'Ghan Expedition, Darwin & Sydney',
    location: 'Australia',
    image: 'https://images.unsplash.com/photo-1529108190281-9a4f620bc2d8?q=80&w=1200&auto=format&fit=crop',
    duration: '11N / 12D',
    price: '₹4,20,000',
    rating: 5.0,
    reviews: 65,
    tags: ['Australia & NZ', 'The Ghan Train', 'Kakadu', 'Sydney'],
    description: `> **Ghan Expedition, Darwin & Sydney**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Australia.

ADELAIDE – KANGAROO ISLAND – THE GHAN OUTBACK TRAIN – ALICE SPRINGS – KAKADU – DARWIN – SYDNEY

### DAY 01 - 03: Adelaide, Kangaroo Island & Barossa Valley
Seal Bay sea lions, Remarkable Rocks, Barossa Valley premier wine and chocolate tastings, and German settlement of Hahndorf.

### DAY 04 - 05: The Ghan Luxury Train Across the Outback
Board the legendary Ghan train in private sleeper cabins crossing the Red Centre from Adelaide to Alice Springs and Katherine Gorge.

### DAY 06 - 08: Darwin, Kakadu & Yellow Water Cruise
Nitmiluk Katherine Gorge, Kakadu National Park rock art at Nourlangie, Yellow Water billabong crocodile cruise, and Darwin Harbour sunset cruise.

### DAY 09 - 11: Flight to Sydney & Blue Mountains
Sydney Opera House, Sydney Tower Eye, Captain Cook Harbour Dinner Cruise, and Blue Mountains Scenic World railway & cableway.

### Day 12: Departure
Transfer to Sydney Airport.`
  },
  {
    id: 27,
    title: 'New Zealand Self Drive Epic 20 Days',
    location: 'New Zealand',
    image: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=1200&auto=format&fit=crop',
    duration: '19N / 20D',
    price: '₹5,40,000',
    rating: 5.0,
    reviews: 92,
    tags: ['Australia & NZ', 'Milford Sound', 'Franz Josef Glacier', 'Waitomo', 'Self Drive'],
    description: `> **New Zealand Self Drive Epic 20 Days**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across New Zealand.

CHRISTCHURCH – MT COOK – QUEENSTOWN – MILFORD SOUND – FRANZ JOSEF – WELLINGTON – TAUPO – ROTORUA – COROMANDEL – AUCKLAND

### DAY 1 - 3: Christchurch to Mount Cook
Pick up rental car. Drive across Canterbury Plains to Lake Tekapo Church of Good Shepherd and Mount Cook Big Sky Stargazing.

### DAY 4 - 6: Queenstown & Milford Sound Fjord Cruise
Skyline Gondola & Luge ride. Full day coach & cruise through Homer Tunnel to spectacular Milford Sound waterfalls.

### DAY 7 - 9: Wanaka & Franz Josef Glacier Helicopter Snow Landing
Lake Wanaka, Haast Pass alpine rainforest, and helicopter snow landing on Franz Josef Glacier.

### DAY 10 - 11: West Coast to Wellington Ferry
Punakaiki Pancake Rocks. Board Interislander ferry across Cook Strait to capital Wellington.

### DAY 12 - 14: Lake Taupo, Huka Falls & Waitomo Caves
Huka Falls Jetboat, Taupo skydive, and world-famous Waitomo Glowworm Caves boat tour. Polynesian Spa in Rotorua.

### DAY 15 - 17: Rotorua Geothermal & Coromandel Peninsula
Te Puia geysers, Maori cultural village, Cathedral Cove, and Hot Water Beach.

### DAY 18 - 20: Auckland Sky Tower & Waiheke Island Wine Tour
Waiheke Island vineyard ferry tour, Sky Tower 360° views, and departure from Auckland Airport.`
  },
  {
    id: 28,
    title: 'Switzerland, France & Paris Disneyland',
    location: 'Switzerland & France',
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=1200&auto=format&fit=crop',
    duration: '12N / 13D',
    price: '₹3,60,000',
    rating: 4.9,
    reviews: 185,
    tags: ['Europe & UK', 'Jungfraujoch', 'Mt. Titlis', 'Paris Disneyland', 'Eiffel Tower'],
    description: `> **Switzerland, France & Paris Disneyland**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Switzerland & France.

LUCERNE – MT TITLIS – INTERLAKEN – JUNGFRAUJOCH – MONTREUX GLACIER 3000 – PARIS EIFFEL & DISNEYLAND

### DAY 01 - 03: Zurich to Lucerne & Mt. Titlis Rotair
Lake Lucerne cruise, Lion Monument, and revolving cable car up Mt. Titlis with Ice Flyer and glacier suspension bridge.

### DAY 04 - 05: Interlaken & Jungfraujoch Top of Europe
Scenic train to Jungfraujoch (3,454m), Europe's highest railway station, Ice Palace, and Sphinx observation terrace.

### DAY 06 - 08: Montreux & Glacier 3000
Swiss Riviera, Chillon Castle, Chaplin's World in Vevey, and Glacier 3000 Peak Walk suspension bridge.

### DAY 09 - 10: High-Speed TGV to Paris & Eiffel Tower
TGV train to Paris. Seine River cruise and Eiffel Tower summit/2nd level views.

### Day 11: Disneyland Paris 1 Day / 2 Parks
Full day unlimited access to Disneyland Park and Walt Disney Studios Park.

### DAY 12 - 13: Louvre Museum & Paris Departure
Free leisure for shopping on Champs-Élysées and transfer to Charles de Gaulle Airport.`
  },
  {
    id: 29,
    title: 'Way to London & Harry Potter Studio',
    location: 'United Kingdom',
    image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹1,85,000',
    rating: 4.9,
    reviews: 145,
    tags: ['Europe & UK', 'London', 'Harry Potter Studio', 'Stonehenge', 'Windsor Castle'],
    description: `> **Way to London & Harry Potter Studio**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across United Kingdom.

LONDON EYE – MADAME TUSSAUDS – STONEHENGE – WINDSOR CASTLE – HARRY POTTER STUDIO – OXFORD & CAMBRIDGE

### Day 1: Welcome to London
Arrival, transfer to hotel, evening stroll along the River Thames.

### Day 2: London Hop-On Hop-Off City Tour
Trafalgar Square, St. Paul's Cathedral, Tower of London (Crown Jewels), Westminster Abbey, Tower Bridge, and Buckingham Palace Changing of the Guard.

### Day 3: Madame Tussauds & London Eye
Wax figures at Madame Tussauds and flight on the London Eye giant observation wheel.

### Day 4: Stonehenge, Windsor Castle & Roman Baths
State Apartments at Windsor Castle, 5,000-year-old mysterious Stonehenge circle, and historic Roman Baths in Bath.

### Day 5: Warner Bros. Studio Tour – The Making of Harry Potter
Walk down Diagon Alley, step inside Great Hall, board the Hogwarts Express at Platform 9¾, and discover movie props & costumes.

### Day 6: Oxford & Cambridge University Towns
Guided walking tour of Bodleian Library and Christ Church College in Oxford, followed by King\'s College Chapel and Mathematical Bridge in Cambridge.

### Day 7: London Departure
Transfer to Heathrow Airport.`
  },
  {
    id: 30,
    title: 'American Grandeur (New York, Niagara, Vegas & LA)',
    location: 'USA',
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=1200&auto=format&fit=crop',
    duration: '11N / 12D',
    price: '₹4,20,000',
    rating: 4.9,
    reviews: 210,
    tags: ['USA & Canada', 'Statue of Liberty', 'Niagara Falls', 'Las Vegas', 'Universal Studios'],
    description: `> **American Grandeur (New York, Niagara, Vegas & LA)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across USA.

NEW YORK – PHILADELPHIA – WASHINGTON DC – HERSHEY – NIAGARA FALLS – LAS VEGAS – LOS ANGELES – SAN FRANCISCO

### Day 01 - 02: New York City & Statue of Liberty
Ferry to Statue of Liberty on Liberty Island, Empire State Building 86th floor observatory, Times Square night tour, Wall Street, and Central Park.

### Day 3: Philadelphia Independence Hall
Liberty Bell, Independence Hall, and tax-free shopping at Philadelphia Premium Outlets.

### Day 4: Washington DC Capital Monuments
White House, Capitol Hill, Lincoln Memorial, Washington Monument, and Smithsonian Air & Space Museum.

### Day 05 - 06: Hershey Chocolate & Niagara Falls Maid of the Mist
Hershey's Chocolate World ride, Niagara Falls night illumination, and Maid of the Mist boat ride right into Horseshoe Falls spray.

### Day 7: Flight to Las Vegas City of Lights
Vegas Strip panoramic night tour, Bellagio fountains, Fremont Street light show, and optional Grand Canyon excursion.

### Day 08 - 09: Los Angeles & Universal Studios Hollywood
Hollywood Walk of Fame, Dolby Theatre, Beverly Hills, and full day at Universal Studios Hollywood theme park.

### Day 10 - 12: San Francisco Golden Gate & Bay Cruise
Drive to San Francisco. Golden Gate Bay cruise, Fisherman\'s Wharf Pier 39, Lombard Street, Twin Peaks, and departure transfer.`
  },
  {
    id: 31,
    title: 'Canadian Rockies (Banff, Jasper & Vancouver)',
    location: 'Canada, North America',
    image: 'https://images.unsplash.com/photo-1503614472-8c93d56e92ce?q=80&w=1200&auto=format&fit=crop',
    duration: '8N / 9D',
    price: '₹3,45,000',
    rating: 5.0,
    reviews: 95,
    tags: ['USA & Canada', 'Banff', 'Lake Louise', 'Glacier Skywalk', 'Vancouver'],
    description: `> **Canadian Rockies (Banff, Jasper & Vancouver)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Canada, North America.

CALGARY – BANFF – LAKE LOUISE – COLUMBIA ICEFIELDS – JASPER – VICTORIA – VANCOUVER – WHISTLER

### Day 1 - 2: Calgary to Banff National Park
Scenic drive into the Canadian Rockies. Banff townsite, Sulphur Mountain Gondola 360° ride, and Bow Valley Parkway.

### Day 3: Lake Louise & Moraine Lake
Emerald waters of Lake Louise, Victoria Glacier, Moraine Lake and the Valley of the Ten Peaks in Yoho National Park.

### Day 4: Icefields Parkway to Jasper
Drive Icefields Parkway. Ride the all-terrain Ice Explorer onto Athabasca Glacier and walk on the glass-floored Glacier Skywalk.

### Day 5: Maligne Canyon & Maligne Lake Cruise
Maligne Canyon limestone gorge walk and cruise on Lake Maligne to iconic Spirit Island.

### Day 6: Flight to Victoria & Butchart Gardens
Flight to Vancouver Island. Explore the world-famous 55-acre Butchart Gardens and Victoria's Inner Harbour.

### Day 7: Vancouver City Tour & FlyOver Canada
Historic Gastown steam clock, Stanley Park totem poles, Capilano Suspension Bridge, and FlyOver Canada 4D flight simulation.

### Day 8: Whistler & Peak 2 Peak Gondola
Sea-to-Sky highway drive past Shannon Falls. Ride the world-record Peak 2 Peak Gondola between Whistler and Blackcomb mountains.

### Day 9: Vancouver Departure
Transfer to Vancouver International Airport.`
  },
  {
    id: 32,
    title: 'Andaman Adventure Explorer (Diving & Sea Walk)',
    location: 'Andaman Islands, India',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop',
    duration: '6N / 7D',
    price: '₹46,000',
    rating: 4.9,
    reviews: 175,
    tags: ['India & Heritage', 'Andaman', 'Scuba Diving', 'Radhanagar Beach'],
    description: `> **Andaman Adventure Explorer (Diving & Sea Walk)**: Experience an exquisitely crafted travel itinerary featuring handpicked accommodations, private transfers, and premier guided excursions across Andaman Islands, India.

PORT BLAIR – CELLULAR JAIL – HAVELOCK ISLAND – SCUBA DIVING – SEA WALK AT ELEPHANT BEACH – NEIL ISLAND

### Day 1: Port Blair, Corbyn\'s Cove & Cellular Jail
Airport pickup, scenic coastal drive to Corbyn's Cove, and historic Cellular Jail Light & Sound Show.

### Day 2: Port Blair to Havelock & Radhanagar Beach Sunset
High-speed ferry cruise to Havelock Island. Relax on Asia's top-rated Radhanagar Beach until sunset.

### Day 3: Certified Scuba Diving at Havelock Reef
Underwater scuba diving with Divemaster including complimentary underwater photos and video footage.

### Day 4: Underwater Sea Walk at Elephant Beach
Speedboat to Elephant Beach. Experience underwater helmet Sea Walking along coral reefs and complimentary snorkeling.

### Day 5: Havelock to Neil Island & Laxmanpur Beach
Cruise to peaceful Neil Island. Sunset at pristine Laxmanpur Beach.

### Day 6: Bharatpur Beach Jet Ski, Natural Rock Bridge & Port Blair
Complimentary Jet Ski session at Bharatpur beach, visit natural coral bridge rock formation, and cruise back to Port Blair for local shopping.

### Day 7: Port Blair Airport Drop
Transfer to airport for return flight.`
  }
];
