export interface HomeHeroSlide {
  id: number | string;
  title: string;
  location: string;
  image: string;
}

export interface HomeFeaturedEscape {
  id: string;
  title: string;
  description: string;
  image: string;
  bgImage: string;
  season: string;
  duration: string;
  price: string;
  rating: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  location: string;
  quote: string;
  avatar: string;
  rating: string;
}

export interface HomeSettings {
  badgeText: string;
  mainHeadline: string;
  mainSubheadline: string;
  searchPlaceholder: string;
  featuredHeading: string;
  featuredSubtitle: string;
}

export const DEFAULT_HERO_SLIDES: HomeHeroSlide[] = [
  {
    id: 1,
    title: 'Tropical Beaches',
    location: 'Maldives',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=2065&auto=format&fit=crop',
  },
  {
    id: 2,
    title: 'Historic Cities',
    location: 'Prague',
    image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 3,
    title: 'Breathtaking Nature',
    location: 'Switzerland',
    image: 'https://images.unsplash.com/photo-1527668752968-14dc70a27c95?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 4,
    title: 'Cultural Escapes',
    location: 'Kyoto, Japan',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 5,
    title: 'Desert Wonders',
    location: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 6,
    title: 'Alpine Lakes',
    location: 'Banff, Canada',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
  }
];

export const DEFAULT_FEATURED_ESCAPES: HomeFeaturedEscape[] = [
  {
    id: 'bali',
    title: 'Ubud, Bali',
    description: 'Immerse yourself in the spiritual heart of Bali. From ancient emerald rice terraces to secluded jungle retreats, experience a transformative journey where luxury meets untouched nature.',
    image: 'https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop',
    season: 'May - September',
    duration: '10 - 14 Days',
    price: '₹1,95,000',
    rating: '4.9/5 (120+ Reviews)'
  },
  {
    id: 'santorini',
    title: 'Santorini, Greece',
    description: 'Witness the world\'s most breathtaking sunsets. Wander through iconic white-washed villages perched on volcanic cliffs overlooking the endless azure Aegean Sea.',
    image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=2021&auto=format&fit=crop',
    season: 'June - October',
    duration: '7 - 10 Days',
    price: '₹2,65,000',
    rating: '4.8/5 (200+ Reviews)'
  },
  {
    id: 'kyoto',
    title: 'Kyoto, Japan',
    description: 'Step back in time in Japan\'s cultural capital. Explore serene Zen gardens, magnificent temples, and traditional geisha districts wrapped in quiet elegance.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?q=80&w=2071&auto=format&fit=crop',
    season: 'March - May',
    duration: '14 - 21 Days',
    price: '₹3,40,000',
    rating: '4.9/5 (85+ Reviews)'
  }
];

export const DEFAULT_TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'rohan-priya',
    name: 'Rohan & Priya Sharma',
    role: 'Honeymooners',
    location: 'Delhi, India',
    quote: 'Tvista Holidays curated a dream honeymoon for us in the Maldives. The overwater villa, private sandbank dinner under the stars, and seamless flight transfers made it magical!',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  },
  {
    id: 'ananya-iyer',
    name: 'Ananya Iyer',
    role: 'Family Voyager',
    location: 'Bengaluru, India',
    quote: 'Our family trip to Switzerland was flawlessly organized. From glacier express train passes to alpine resort stays, Tvista took care of every tiny detail with utmost care.',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  },
  {
    id: 'vikramaditya',
    name: 'Vikramaditya Singhania',
    role: 'Luxury Connoisseur',
    location: 'Mumbai, India',
    quote: 'Bespoke luxury at its finest! Our private yacht charter along the Amalfi Coast and 24/7 concierge assistance made our vacation completely effortless and prestigious.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  },
  {
    id: 'josephine-vance',
    name: 'Josephine Vance',
    role: 'Cultural Collector',
    location: 'London, UK',
    quote: 'An extraordinary private expedition through Kyoto during cherry blossom season. Private tea ceremonies, ryokan hot springs, and sublime local guidance throughout.',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  },
  {
    id: 'albert-chirls',
    name: 'Albert Chirls',
    role: 'Global Explorer',
    location: 'New York, USA',
    quote: 'Seamless flight bookings, luxury private villas, and instant support whenever needed. Tvista Holidays is our go-to partner for international vacations.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  },
  {
    id: 'anas-iqbual',
    name: 'Anas Iqbual',
    role: 'Frequent Jetsetter',
    location: 'Dubai, UAE',
    quote: 'The helicopter tour over Capri and private safari lodge experience in Kenya exceeded all our expectations. Exceptional attention to luxury standards!',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=400&auto=format&fit=crop',
    rating: '5.0'
  }
];

export const DEFAULT_HOME_SETTINGS: HomeSettings = {
  badgeText: 'Curated Luxury Holidays',
  mainHeadline: 'Unforgettable Journeys Across The Globe',
  mainSubheadline: 'Handcrafted itineraries, private tours, 5-star stays, and bespoke concierge care.',
  searchPlaceholder: 'Search destinations, packages, or experiences...',
  featuredHeading: 'Featured Escapes',
  featuredSubtitle: 'Handpicked seasonal journeys designed for extraordinary moments'
};
