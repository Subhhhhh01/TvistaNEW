import React, { useRef, useState } from 'react';
import { motion, MotionValue, useMotionValueEvent, useMotionValue } from 'motion/react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { useData } from '../context/DataContext';
import { DEFAULT_TESTIMONIALS } from '../data/homeData';

interface TestimonialsProps {
  progress?: MotionValue<number>;
}

export default function Testimonials({ progress }: TestimonialsProps) {
  const { testimonials } = useData();
  const list = testimonials && testimonials.length > 0 ? testimonials : DEFAULT_TESTIMONIALS;

  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  const fallbackProg = useMotionValue(0);
  const activeProg = progress || fallbackProg;

  // Sync with scroll progress if passed from parent Home.tsx
  useMotionValueEvent(activeProg, 'change', (latest) => {
    if (progress && list.length > 0) {
      const idx = Math.min(
        list.length - 1,
        Math.floor(latest * list.length)
      );
      if (idx !== activeIndex) {
        setActiveIndex(idx);
        scrollToCard(idx);
      }
    }
  });

  const scrollToCard = (index: number) => {
    if (scrollRef.current) {
      const cardWidth = 320; // card width + gap approx
      scrollRef.current.scrollTo({
        left: index * cardWidth,
        behavior: 'smooth'
      });
    }
  };

  const handlePrev = () => {
    const next = activeIndex > 0 ? activeIndex - 1 : list.length - 1;
    setActiveIndex(next);
    scrollToCard(next);
  };

  const handleNext = () => {
    const next = activeIndex < list.length - 1 ? activeIndex + 1 : 0;
    setActiveIndex(next);
    scrollToCard(next);
  };

  return (
    <section className="relative py-16 sm:py-24 px-4 sm:px-8 lg:px-16 min-h-screen flex flex-col justify-center items-center overflow-hidden">
      {/* Background Image & Scenery Overlay matching the website theme */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.img 
          initial={{ scale: 1.08 }}
          whileInView={{ scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop"
          alt="Coastal Scenery Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[4px] transition-colors duration-500"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-neutral-950/80 via-transparent to-neutral-950"></div>
      </div>

      <div className="max-w-7xl w-full mx-auto flex flex-col items-center relative z-10">
        {/* Cyan Title matching website font-display */}
        <div className="text-center mb-16 sm:mb-20">
          <h2 className="text-3xl sm:text-5xl font-display font-bold text-cyan-400 tracking-wide drop-shadow-md">
            Testimonials
          </h2>
          <p className="text-white/70 text-xs sm:text-sm mt-2 font-medium drop-shadow">
            Stories & experiences from our valued guests around the globe
          </p>
        </div>

        {/* Side Scrolling Container with Navigation Controls */}
        <div className="relative w-full max-w-5xl">
          {/* Navigation Buttons */}
          <button
            onClick={handlePrev}
            aria-label="Previous Testimonials"
            className="absolute -left-3 sm:-left-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-cyan-500/20 backdrop-blur-md border border-cyan-400/40 text-cyan-300 flex items-center justify-center hover:bg-cyan-500 hover:text-white transition-all shadow-lg"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          <button
            onClick={handleNext}
            aria-label="Next Testimonials"
            className="absolute -right-3 sm:-right-6 top-1/2 -translate-y-1/2 z-20 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-cyan-500/20 backdrop-blur-md border border-cyan-400/40 text-cyan-300 flex items-center justify-center hover:bg-cyan-500 hover:text-white transition-all shadow-lg"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          {/* Side Scrolling Track */}
          <div
            ref={scrollRef}
            className="flex gap-6 sm:gap-8 overflow-x-auto snap-x snap-mandatory pt-14 pb-8 px-4 sm:px-8 scrollbar-none scroll-smooth"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {list.map((item, index) => {
              const isActive = index === activeIndex;

              return (
                <motion.div
                  key={item.id}
                  onClick={() => {
                    setActiveIndex(index);
                    scrollToCard(index);
                  }}
                  whileHover={{ y: -6 }}
                  className={`relative shrink-0 w-[260px] sm:w-[290px] bg-white/95 backdrop-blur-md rounded-2xl p-6 sm:p-7 shadow-2xl flex flex-col justify-between snap-center transition-all duration-300 cursor-pointer border border-white/30 ${
                    isActive ? 'ring-4 ring-cyan-400/80 scale-105 z-10 shadow-[0_10px_30px_rgba(34,211,238,0.25)]' : 'opacity-90 hover:opacity-100'
                  }`}
                >
                  {/* Circular Avatar overlapping top center */}
                  <div className="absolute -top-12 left-1/2 -translate-x-1/2">
                    <img
                      src={item.avatar}
                      alt={item.name}
                      className="w-20 h-20 sm:w-22 sm:h-22 rounded-full object-cover border-4 border-white shadow-xl"
                    />
                  </div>

                  {/* Top Left Quote Icon */}
                  <div className="flex justify-start pt-6 mb-2">
                    <span className="text-cyan-400 text-3xl sm:text-4xl font-serif font-bold leading-none select-none">
                      “
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="flex flex-col items-center text-center flex-1 my-2">
                    <h3 className="text-stone-900 font-bold text-base sm:text-lg mb-1">
                      {item.name}
                    </h3>
                    <p className="text-cyan-600 text-[11px] font-semibold tracking-wider uppercase mb-2">
                      {item.location}
                    </p>
                    <p className="text-stone-600 text-xs leading-relaxed font-normal px-1">
                      {item.quote}
                    </p>
                  </div>

                  {/* Bottom Right Quote Icon & Rating */}
                  <div className="flex items-center justify-between pt-4 border-t border-stone-200/80 mt-3">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                      <span className="text-stone-500 font-mono text-xs font-semibold ml-1">
                        {item.rating}
                      </span>
                    </div>

                    <span className="text-cyan-400 text-3xl sm:text-4xl font-serif font-bold leading-none select-none">
                      ”
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Dots Indicator for Side Scrolling */}
        <div className="flex items-center gap-2 mt-8">
          {list.map((_, i) => (
            <button
              key={i}
              onClick={() => {
                setActiveIndex(i);
                scrollToCard(i);
              }}
              aria-label={`Go to testimonial ${i + 1}`}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                i === activeIndex ? 'w-8 bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]' : 'w-2.5 bg-white/30 hover:bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
