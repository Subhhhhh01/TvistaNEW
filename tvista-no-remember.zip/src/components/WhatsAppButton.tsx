import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Plane, MapPin, Globe2, Sparkles } from 'lucide-react';
import { openWhatsAppChat, TVISTA_WHATSAPP_NUMBER, TVISTA_WHATSAPP_DISPLAY } from '../utils/whatsapp';

export default function WhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  const handleQuickChat = (topic: string) => {
    let msg = `Hello Tvista Holidays! I am inquiring about ${topic}. Please connect me with a travel concierge.`;
    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, msg);
    setIsOpen(false);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMsg.trim()) return;
    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, customMsg);
    setCustomMsg('');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      {/* Popover Card */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 15 }}
            className="mb-4 w-80 sm:w-88 bg-white/95 backdrop-blur-2xl border border-stone-200 rounded-3xl shadow-2xl overflow-hidden text-stone-900 font-sans"
          >
            {/* Card Header */}
            <div className="bg-gradient-to-r from-emerald-600 via-emerald-700 to-teal-800 p-4 text-white relative">
              <button
                onClick={() => setIsOpen(false)}
                className="absolute top-3.5 right-3.5 w-7 h-7 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
                aria-label="Close chat popup"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white p-2 shadow-inner flex items-center justify-center shrink-0">
                  <MessageCircle className="w-6 h-6 text-emerald-600 fill-emerald-600" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-base leading-tight">Chat with Tvista Holidays</h4>
                  <p className="text-[11px] text-emerald-100 flex items-center gap-1.5 mt-0.5 font-medium">
                    <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                    <span>Travel Concierge Online ({TVISTA_WHATSAPP_DISPLAY})</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Suggestions & Input */}
            <div className="p-4 space-y-3">
              <p className="text-xs text-stone-600 leading-relaxed font-medium">
                Select an inquiry topic or type your message below for instant WhatsApp assistance:
              </p>

              <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                <button
                  onClick={() => handleQuickChat('Flight Deals & Fare Quotes')}
                  className="p-2.5 rounded-xl bg-stone-50 hover:bg-emerald-50 text-stone-800 hover:text-emerald-900 border border-stone-200 hover:border-emerald-300 transition-all text-left flex items-center gap-2 group"
                >
                  <Plane className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate">Flight Deals</span>
                </button>

                <button
                  onClick={() => handleQuickChat('Holiday Packages & Custom Itineraries')}
                  className="p-2.5 rounded-xl bg-stone-50 hover:bg-emerald-50 text-stone-800 hover:text-emerald-900 border border-stone-200 hover:border-emerald-300 transition-all text-left flex items-center gap-2 group"
                >
                  <MapPin className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate">Packages</span>
                </button>

                <button
                  onClick={() => handleQuickChat('Visa Assistance & Appointments')}
                  className="p-2.5 rounded-xl bg-stone-50 hover:bg-emerald-50 text-stone-800 hover:text-emerald-900 border border-stone-200 hover:border-emerald-300 transition-all text-left flex items-center gap-2 group"
                >
                  <Globe2 className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate">Visa Help</span>
                </button>

                <button
                  onClick={() => handleQuickChat('Group Travel & Custom Luxury Journeys')}
                  className="p-2.5 rounded-xl bg-stone-50 hover:bg-emerald-50 text-stone-800 hover:text-emerald-900 border border-stone-200 hover:border-emerald-300 transition-all text-left flex items-center gap-2 group"
                >
                  <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 group-hover:scale-110 transition-transform" />
                  <span className="truncate">Group Booking</span>
                </button>
              </div>

              {/* Direct Input Form */}
              <form onSubmit={handleCustomSubmit} className="pt-2 border-t border-stone-100 flex gap-2">
                <input
                  type="text"
                  placeholder="Ask a question..."
                  value={customMsg}
                  onChange={(e) => setCustomMsg(e.target.value)}
                  className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all"
                />
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white p-2 rounded-xl transition-all shadow-md shrink-0 flex items-center justify-center"
                  title="Send via WhatsApp"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Trigger Floating Action Button */}
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="relative group bg-emerald-500 hover:bg-emerald-600 text-white p-4 rounded-full shadow-2xl flex items-center justify-center border-2 border-white/80 backdrop-blur-md transition-all duration-300"
        aria-label="Open WhatsApp Chat"
      >
        {/* Glowing pulse ring */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-40 group-hover:opacity-75 blur animate-pulse" />
        <MessageCircle className="w-7 h-7 relative z-10 fill-white text-emerald-500" />

        {/* Unread badge or tooltip */}
        <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm z-20">
          1
        </span>
      </motion.button>
    </div>
  );
}
