import React, { useState, useRef } from 'react';
import { 
  Bold, Italic, Heading1, Heading2, Heading3, List, ListOrdered, 
  Quote, Highlighter, Strikethrough, Minus, Sparkles, Calendar, 
  Eye, Edit3, HelpCircle, Check
} from 'lucide-react';
import RichDescription from './RichDescription';

interface DescriptionEditorProps {
  value: string;
  onChange: (value: string) => void;
  rows?: number;
  placeholder?: string;
}

export default function DescriptionEditor({
  value,
  onChange,
  rows = 8,
  placeholder = "Enter package description, day-by-day itinerary, and highlights..."
}: DescriptionEditorProps) {
  const [activeTab, setActiveTab] = useState<'write' | 'preview'>('write');
  const [showCheatSheet, setShowCheatSheet] = useState(false);
  const [copiedTemplate, setCopiedTemplate] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  /**
   * Helper to wrap or insert text around current selection in the textarea
   */
  const insertFormatting = (
    prefix: string, 
    suffix: string = '', 
    defaultText: string = 'text',
    lineLevel: boolean = false
  ) => {
    const textarea = textareaRef.current;
    if (!textarea) {
      onChange(value ? `${value}\n${prefix}${defaultText}${suffix}` : `${prefix}${defaultText}${suffix}`);
      return;
    }

    textarea.focus();
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);

    if (lineLevel) {
      // Find start and end of the lines
      const lineStart = value.lastIndexOf('\n', start - 1) + 1;
      const lineEnd = value.indexOf('\n', end);
      const actualLineEnd = lineEnd === -1 ? value.length : lineEnd;
      const currentLines = value.substring(lineStart, actualLineEnd);
      
      const newLines = currentLines
        .split('\n')
        .map(l => `${prefix}${l || defaultText}`)
        .join('\n');

      const newValue = value.substring(0, lineStart) + newLines + value.substring(actualLineEnd);
      onChange(newValue);

      setTimeout(() => {
        textarea.setSelectionRange(lineStart, lineStart + newLines.length);
      }, 10);
      return;
    }

    let textToInsert = '';
    let selectStart = 0;
    let selectEnd = 0;

    if (selectedText) {
      textToInsert = `${prefix}${selectedText}${suffix}`;
      selectStart = start + prefix.length;
      selectEnd = selectStart + selectedText.length;
    } else {
      textToInsert = `${prefix}${defaultText}${suffix}`;
      selectStart = start + prefix.length;
      selectEnd = selectStart + defaultText.length;
    }

    const newValue = value.substring(0, start) + textToInsert + value.substring(end);
    onChange(newValue);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(selectStart, selectEnd);
    }, 10);
  };

  const insertTemplate = (template: string, name: string) => {
    const textarea = textareaRef.current;
    const prefix = value && !value.endsWith('\n\n') ? (value.endsWith('\n') ? '\n' : '\n\n') : '';
    const updated = value + prefix + template;
    onChange(updated);
    setCopiedTemplate(name);
    setTimeout(() => setCopiedTemplate(null), 2500);

    if (textarea) {
      setTimeout(() => {
        textarea.focus();
        textarea.scrollTop = textarea.scrollHeight;
      }, 20);
    }
  };

  const wordCount = value.trim() ? value.trim().split(/\s+/).length : 0;
  const charCount = value.length;

  return (
    <div className="bg-stone-50/90 border border-stone-300 rounded-2xl overflow-hidden shadow-2xs">
      {/* Top Header: View Switcher & Title */}
      <div className="px-4 py-2.5 bg-stone-100/90 border-b border-stone-200 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-bold text-stone-800 flex items-center gap-1.5">
            <Edit3 className="w-3.5 h-3.5 text-amber-600" />
            <span>Rich Description & Formatting</span>
          </span>
          <span className="text-[10px] text-stone-500 font-medium hidden sm:inline">
            (Supports Headings, Bold, Italic, Highlights & Itineraries)
          </span>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-stone-200 shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('write')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold text-xs transition-all ${
              activeTab === 'write'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Write & Format</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold text-xs transition-all ${
              activeTab === 'preview'
                ? 'bg-amber-500 text-stone-950 shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Live Customer Preview</span>
          </button>
        </div>
      </div>

      {/* Formatting Toolbar (Only in write mode) */}
      {activeTab === 'write' && (
        <div className="p-2 bg-stone-50 border-b border-stone-200 flex flex-wrap items-center gap-1.5">
          {/* Headings Group */}
          <div className="flex items-center bg-white border border-stone-200 rounded-lg p-0.5 shadow-2xs">
            <button
              type="button"
              onClick={() => insertFormatting('# ', '', 'Major Heading', true)}
              title="Heading 1 (# Heading)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-700 hover:text-stone-950 transition-colors flex items-center gap-1 text-[11px] font-bold px-2"
            >
              <Heading1 className="w-3.5 h-3.5 text-amber-700" />
              <span>H1</span>
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('## ', '', 'Section Title', true)}
              title="Heading 2 (## Heading)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-700 hover:text-stone-950 transition-colors flex items-center gap-1 text-[11px] font-bold px-2"
            >
              <Heading2 className="w-3.5 h-3.5 text-amber-700" />
              <span>H2</span>
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('### ', '', 'Subsection', true)}
              title="Heading 3 (### Heading)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-700 hover:text-stone-950 transition-colors flex items-center gap-1 text-[11px] font-bold px-2"
            >
              <Heading3 className="w-3.5 h-3.5 text-amber-700" />
              <span>H3</span>
            </button>
          </div>

          <div className="h-4 w-px bg-stone-200 mx-0.5" />

          {/* Text Style Group */}
          <div className="flex items-center bg-white border border-stone-200 rounded-lg p-0.5 shadow-2xs">
            <button
              type="button"
              onClick={() => insertFormatting('**', '**', 'bold text')}
              title="Bold text (**text**)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <Bold className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('*', '*', 'italic text')}
              title="Italic text (*text*)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <Italic className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('==', '==', 'highlighted text')}
              title="Highlight text (==text==)"
              className="p-1.5 rounded-md hover:bg-amber-50 text-amber-800 hover:text-amber-950 transition-colors"
            >
              <Highlighter className="w-3.5 h-3.5 text-amber-600" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('~~', '~~', 'strikethrough')}
              title="Strikethrough (~~text~~)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-600 hover:text-stone-950 transition-colors"
            >
              <Strikethrough className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('[badge: ', ']', 'Featured')}
              title="Badge Pill ([badge: Text])"
              className="p-1.5 rounded-md hover:bg-amber-50 text-amber-800 transition-colors text-[11px] font-bold px-2 flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-amber-600" />
              <span>Badge</span>
            </button>
          </div>

          <div className="h-4 w-px bg-stone-200 mx-0.5" />

          {/* Lists & Blocks */}
          <div className="flex items-center bg-white border border-stone-200 rounded-lg p-0.5 shadow-2xs">
            <button
              type="button"
              onClick={() => insertFormatting('• ', '', 'List item', true)}
              title="Bullet point (• item)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <List className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('1. ', '', 'Numbered step', true)}
              title="Numbered list (1. item)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <ListOrdered className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('> ', '', 'Important travel advice or note...', true)}
              title="Callout / Quote block (> note)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <Quote className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => insertFormatting('\n---\n', '', '', false)}
              title="Horizontal divider (---)"
              className="p-1.5 rounded-md hover:bg-stone-100 text-stone-800 hover:text-stone-950 transition-colors"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick Insert Templates */}
          <div className="flex items-center gap-1 ml-auto">
            <button
              type="button"
              onClick={() => insertTemplate(
                `### Day 1: Arrival & Welcome Reception\n• Meet and assist at the airport by private English-speaking chauffeur\n• Luxury private transfer to the 5-star oceanfront resort\n• Evening sunset cocktails and curated welcome dinner with live music`,
                'Day Itinerary'
              )}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-100/80 hover:bg-amber-200/90 text-amber-900 border border-amber-300/80 text-[11px] font-bold transition-all shadow-2xs"
              title="Insert a formatted Day Itinerary template"
            >
              <Calendar className="w-3.5 h-3.5 text-amber-700" />
              <span>+ Add Day</span>
            </button>

            <button
              type="button"
              onClick={() => setShowCheatSheet(!showCheatSheet)}
              className={`p-1.5 rounded-lg border transition-colors ${
                showCheatSheet 
                  ? 'bg-stone-800 text-white border-stone-800' 
                  : 'bg-white text-stone-600 border-stone-200 hover:bg-stone-100'
              }`}
              title="Toggle Markdown Formatting Syntax Tips"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Syntax Cheat Sheet Banner */}
      {showCheatSheet && activeTab === 'write' && (
        <div className="bg-amber-50/90 border-b border-amber-200/80 p-3 text-[11px] text-stone-700 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div>
            <span className="font-bold text-amber-900 block mb-0.5">Headings:</span>
            <code className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-amber-200 font-mono block">
              # Heading 1<br />
              ## Heading 2<br />
              ### Day 1: Title
            </code>
          </div>
          <div>
            <span className="font-bold text-amber-900 block mb-0.5">Text Styling:</span>
            <code className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-amber-200 font-mono block">
              **bold text**<br />
              *italic text*<br />
              ==highlighted==
            </code>
          </div>
          <div>
            <span className="font-bold text-amber-900 block mb-0.5">Lists & Quotes:</span>
            <code className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-amber-200 font-mono block">
              • Bullet point<br />
              1. Numbered item<br />
              &gt; Important Note
            </code>
          </div>
          <div>
            <span className="font-bold text-amber-900 block mb-0.5">Tags & Dividers:</span>
            <code className="text-[10px] bg-white px-1.5 py-0.5 rounded border border-amber-200 font-mono block">
              [badge: Luxury]<br />
              --- (Divider)
            </code>
          </div>
        </div>
      )}

      {/* Template Success Notification */}
      {copiedTemplate && (
        <div className="px-4 py-1.5 bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-[11px] font-semibold flex items-center gap-1.5 animate-fadeIn">
          <Check className="w-3.5 h-3.5 text-emerald-600" />
          <span>Inserted {copiedTemplate} template snippet into the description.</span>
        </div>
      )}

      {/* Main Content Area: Write vs Preview */}
      <div className="p-3 bg-white min-h-[180px]">
        {activeTab === 'write' ? (
          <textarea
            ref={textareaRef}
            rows={rows}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full text-xs sm:text-sm font-sans text-stone-900 leading-relaxed placeholder:text-stone-400 focus:outline-none resize-y min-h-[160px]"
          />
        ) : (
          <div className="p-3 sm:p-4 bg-stone-50/70 border border-stone-200/80 rounded-xl min-h-[160px] max-h-[340px] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-stone-200 text-[11px] text-stone-500 font-medium">
              <span>Customer View (Live Styled Simulation)</span>
              <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
                Active Render
              </span>
            </div>
            <RichDescription content={value} theme="light" />
          </div>
        )}
      </div>

      {/* Footer Metrics */}
      <div className="px-4 py-2 bg-stone-100/90 border-t border-stone-200 flex items-center justify-between text-[11px] text-stone-500">
        <div className="flex items-center gap-3">
          <span>{wordCount} {wordCount === 1 ? 'word' : 'words'}</span>
          <span>•</span>
          <span>{charCount} characters</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-stone-400">
            Tip: Highlight text and click any toolbar icon to format instantly
          </span>
        </div>
      </div>
    </div>
  );
}
