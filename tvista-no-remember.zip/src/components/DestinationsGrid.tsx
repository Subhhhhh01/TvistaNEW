import React, { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring, MotionValue } from 'motion/react';
import { ArrowUpRight, Clock, IndianRupee, Sparkles } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useData } from '../context/DataContext';

const DESTINATIONS = [
  {
    id: 1,
    name: 'Kyoto',
    country: 'Japan',
    description: 'Ancient temples, serene gardens, and traditional geisha districts await in this cultural heart of Japan. Experience the beauty of cherry blossoms and centuries-old tea houses.',
    duration: '7 Days',
    price: '₹1,98,000',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 2,
    name: 'Amalfi Coast',
    country: 'Italy',
    description: 'Dramatic cliffs, pastel-colored coastal towns, and crystal clear Mediterranean waters. A perfect blend of romance and scenic beauty.',
    duration: '5 Days',
    price: '₹1,48,000',
    image: 'https://images.unsplash.com/photo-1499678329028-101435549a4e?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 3,
    name: 'Paris',
    country: 'France',
    description: 'The city of lights, love, and architecture. Explore world-class museums, charming cafes, and iconic landmarks.',
    duration: '6 Days',
    price: '₹1,75,000',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 4,
    name: 'Swiss Alps',
    country: 'Switzerland',
    description: 'Snow-capped peaks, pristine alpine lakes, and world-class skiing resorts. A nature lover\'s paradise in both winter and summer.',
    duration: '8 Days',
    price: '₹2,65,000',
    image: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?q=80&w=2070&auto=format&fit=crop'
  }
];

interface DestinationsGridProps {
  theme?: 'dark' | 'light';
}

function DestinationCard({ 
  dest, 
  isLight, 
  index, 
  total, 
  progress 
}: { 
  dest: typeof DESTINATIONS[0]; 
  isLight: boolean; 
  index: number; 
  total: number; 
  progress: MotionValue<number>; 
  key?: React.Key;
}) {
  const navigate = useNavigate();
  const step = 1 / (total - 1);
  const center = index * step;

  let domain: number[];
  let scaleVals: number[];
  let opacityVals: number[];
  let borderVals: number[];

  if (index === 0) {
    domain = [0, step * 0.5, step];
    scaleVals = [1, 0.95, 0.92];
    opacityVals = [1, 0.75, 0.5];
    borderVals = [1, 0.4, 0];
  } else if (index === total - 1) {
    domain = [1 - step, 1 - step * 0.5, 1];
    scaleVals = [0.92, 0.95, 1];
    opacityVals = [0.5, 0.75, 1];
    borderVals = [0, 0.4, 1];
  } else {
    domain = [
      Math.max(0, center - step * 0.7),
      center,
      Math.min(1, center + step * 0.7)
    ];
    scaleVals = [0.92, 1, 0.92];
    opacityVals = [0.5, 1, 0.5];
    borderVals = [0, 1, 0];
  }

  const cardScale = useTransform(progress, domain, scaleVals);
  const cardOpacity = useTransform(progress, domain, opacityVals);
  const borderOpacity = useTransform(progress, domain, borderVals);

  return (
    <div className="w-screen px-6 sm:px-12 lg:px-20 flex-shrink-0 h-full flex items-center justify-center">
      <motion.div
        style={{ scale: cardScale, opacity: cardOpacity }}
        onClick={() => navigate('/packages')}
        className={`group relative rounded-[2rem] overflow-hidden cursor-pointer border w-full max-w-5xl h-full shadow-2xl will-change-[transform,opacity] transition-colors duration-300 ${
          isLight ? 'border-stone-200/50 shadow-stone-200/50' : 'border-white/20'
        }`}
      >
        <img 
          src={dest.image} 
          alt={dest.name} 
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/30 to-transparent opacity-85 group-hover:opacity-70 transition-opacity duration-500" />
        
        {/* Active Highlight Border */}
        <motion.div
          style={{ opacity: borderOpacity }}
          className="absolute inset-0 border-2 border-white/60 rounded-[2rem] pointer-events-none shadow-[0_0_25px_rgba(255,255,255,0.2)]"
        />

        {/* Number Badge */}
        <div className="absolute top-6 left-6 z-10 flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-white/20 text-white text-xs font-bold tracking-widest">
          <Sparkles className="w-3.5 h-3.5 text-white" />
          0{index + 1} / 0{total}
        </div>

        <div className="absolute inset-0 p-8 md:p-12 flex flex-col justify-end z-10">
          <div className="transform transition-transform duration-500">
            <p className="text-white/80 text-sm font-bold uppercase tracking-widest mb-2 drop-shadow-md">{dest.country}</p>
            <h3 className="text-white font-serif text-4xl md:text-6xl mb-4 drop-shadow-md">{dest.name}</h3>
            
            <div className="transition-all duration-500">
              <p className="text-white/80 text-base md:text-lg max-w-2xl pt-4 border-t border-white/20 leading-relaxed">
                {dest.description}
              </p>
              <div className="flex items-center gap-6 mt-6 pt-6 border-t border-white/10">
                <div className="flex items-center gap-2 text-white/90">
                  <Clock className="w-5 h-5 text-white/70" />
                  <span className="text-sm font-semibold">{dest.duration}</span>
                </div>
                <div className="flex items-center gap-2 text-white/90">
                  <IndianRupee className="w-5 h-5 text-white/70" />
                  <span className="text-sm font-semibold">From {dest.price}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="absolute top-8 right-8 w-12 h-12 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center opacity-0 transform translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
            <ArrowUpRight className="w-6 h-6 text-white" />
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function Destinations({ theme = 'dark' }: DestinationsGridProps = {}) {
  const isLight = theme === 'light';
  const { destinations: dynamicDestinations } = useData();
  const list = dynamicDestinations && dynamicDestinations.length > 0 ? dynamicDestinations : DESTINATIONS;
  const totalCount = Math.max(list.length, 1);

  const targetRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end end"]
  });

  const smoothProgress = useSpring(scrollYProgress, {
    damping: 28,
    stiffness: 90,
    mass: 0.25,
    restDelta: 0.0001
  });

  // Shift track horizontally by (N - 1) * 100vw
  const x = useTransform(smoothProgress, [0, 1], ["0vw", `-${(totalCount - 1) * 100}vw`]);

  return (
    <section ref={targetRef} className="relative h-[400vh] bg-transparent">
      <div className="sticky top-0 h-screen flex flex-col justify-center overflow-hidden pt-20 pb-12">
        <div className="max-w-7xl mx-auto w-full px-6 sm:px-12 lg:px-20 mb-8 md:mb-12 flex-shrink-0">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <p className={`text-sm font-semibold tracking-[0.2em] uppercase mb-3 inline-block px-4 py-1.5 rounded-full border backdrop-blur-md ${isLight ? 'text-stone-500 bg-stone-200/50 border-stone-300/50' : 'text-white/60 bg-white/5 border-white/10'}`}>
                Handpicked
              </p>
              <h2 className={`font-serif text-4xl md:text-5xl ${isLight ? 'text-stone-900' : 'text-white'}`}>
                Trending Destinations
              </h2>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Link 
                to="/packages"
                className={`group inline-flex items-center gap-3 transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/80 hover:text-white'}`}
              >
                <span className="font-medium tracking-wide uppercase text-sm">View All Packages</span>
                <div className={`w-10 h-10 rounded-full border flex items-center justify-center transition-all ${isLight ? 'border-stone-300 group-hover:bg-stone-900 group-hover:text-white' : 'border-white/20 group-hover:bg-white group-hover:text-neutral-950'}`}>
                  <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </Link>
            </motion.div>
          </div>
        </div>

        <motion.div style={{ x, width: `${totalCount * 100}vw` }} className="flex h-[60vh] md:h-[65vh] will-change-transform">
          {list.map((dest, i) => (
            <DestinationCard 
              key={dest.id} 
              dest={dest as any} 
              isLight={isLight} 
              index={i} 
              total={totalCount}
              progress={smoothProgress}
            />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
