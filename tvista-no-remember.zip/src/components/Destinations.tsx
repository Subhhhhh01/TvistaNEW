import React from 'react';
import { motion, useTransform, MotionValue, useMotionValue } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const DESTINATIONS = [
  {
    id: 1,
    name: 'Kyoto',
    country: 'Japan',
    description: 'Ancient temples and serene gardens.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 2,
    name: 'Amalfi',
    country: 'Italy',
    description: 'Dramatic cliffs and pastel coastal towns.',
    image: 'https://images.unsplash.com/photo-1499678329028-101435549a4e?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 3,
    name: 'Paris',
    country: 'France',
    description: 'The city of lights, love, and architecture.',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 4,
    name: 'Swiss Alps',
    country: 'Switzerland',
    description: 'Snow-capped peaks and pristine alpine lakes.',
    image: 'https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 5,
    name: 'Santorini',
    country: 'Greece',
    description: 'Iconic white-washed buildings over the Aegean.',
    image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?q=80&w=2070&auto=format&fit=crop'
  },
  {
    id: 6,
    name: 'Banff',
    country: 'Canada',
    description: 'Breathtaking wilderness and glacial lakes.',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop'
  }
];

interface DestinationsProps {
  progress?: MotionValue<number>;
}

function DestinationCard({
  dest,
  index,
  total,
  progress,
  onClick
}: {
  dest: typeof DESTINATIONS[0];
  index: number;
  total: number;
  progress: MotionValue<number>;
  onClick: () => void;
  key?: React.Key;
}) {
  const step = 1 / (total - 1);
  const center = index * step;

  // Domain points representing before-active, active, and after-active states
  const domainPoints = [
    center - step,
    center,
    center + step
  ];

  // Active card takes almost all horizontal flex space (16x), inactive is a thin strip (0.12x)
  const flexGrowValues = [0.12, 16, 0.12];
  
  // Height transitions: active has more height on mobile, inactive collapses nicely
  const minHeightValues = ['60px', '220px', '60px'];

  // Opacity: active is fully vibrant, inactive is dimmed (0.35)
  const opacityValues = [0.35, 1, 0.35];

  // Scale: active is standard size, inactive is slightly scaled down
  const scaleValues = [0.96, 1, 0.96];

  // Active border highlighting
  const activeBorderValues = [0, 1, 0];

  const flexGrow = useTransform(progress, domainPoints, flexGrowValues);
  const opacity = useTransform(progress, domainPoints, opacityValues);
  const scale = useTransform(progress, domainPoints, scaleValues);
  const minHeight = useTransform(progress, domainPoints, minHeightValues);
  const activeBorderOpacity = useTransform(progress, domainPoints, activeBorderValues);

  return (
    <motion.div
      style={{
        opacity,
        scale,
        flexGrow,
        minHeight
      }}
      onClick={onClick}
      className="group relative flex-1 rounded-2xl sm:rounded-3xl overflow-hidden cursor-pointer border border-white/20 hover:border-white/50 shadow-2xl min-h-[55px] sm:min-h-[100px] will-change-[flex-grow,transform]"
    >
      <img
        src={dest.image}
        alt={dest.name}
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-85 group-hover:opacity-75 transition-opacity duration-300"></div>

      {/* Active White Subtle Highlight Border */}
      <motion.div
        style={{ opacity: activeBorderOpacity }}
        className="absolute inset-0 border-2 border-white/60 rounded-2xl sm:rounded-3xl pointer-events-none shadow-[0_0_20px_rgba(255,255,255,0.25)]"
      />

      {/* Slide Content (only visible when active) */}
      <motion.div 
        style={{ opacity: activeBorderOpacity }}
        className="absolute inset-x-0 bottom-0 p-3 sm:p-4 md:p-6 flex flex-col justify-end h-full z-10"
      >
        <div className="flex flex-row items-end justify-between gap-2 sm:gap-4">
          <div className="max-w-full">
            <p className="text-white/70 text-[9px] sm:text-xs font-bold uppercase tracking-widest drop-shadow-md mb-0.5 sm:mb-1">
              {dest.country}
            </p>
            <h3 className="text-white font-display text-lg sm:text-2xl md:text-3xl xl:text-4xl whitespace-nowrap lg:truncate drop-shadow-lg leading-tight">
              {dest.name}
            </h3>
            
            <p className="text-white/80 text-xs sm:text-sm hidden lg:block max-w-[260px] mt-2 line-clamp-2 leading-relaxed">
              {dest.description}
            </p>
          </div>

          <motion.div
            whileHover={{ scale: 1.1, rotate: -45 }}
            whileTap={{ scale: 0.9 }}
            className="w-7 h-7 sm:w-10 sm:h-10 lg:w-12 lg:h-12 flex-shrink-0 rounded-full bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center self-end shadow-lg"
          >
            <ArrowRight className="w-3.5 h-3.5 sm:w-5 sm:h-5 text-white" />
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function Destinations({ progress }: DestinationsProps) {
  const navigate = useNavigate();
  const defaultProgress = useMotionValue(1);
  const activeProgress = progress || defaultProgress;

  return (
    <section className="relative py-16 md:py-20 px-6 sm:px-12 lg:px-20 min-h-screen lg:h-screen flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <motion.img 
          initial={{ scale: 1.1 }}
          whileInView={{ scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          src="https://images.unsplash.com/photo-1506929562872-bb421503ef21?q=80&w=2068&auto=format&fit=crop" 
          alt="Ocean Background" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]"></div>
      </div>

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-6 md:mb-8 gap-6">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="font-display text-3xl md:text-4xl sm:text-5xl text-white drop-shadow-lg"
            >
              Where do you want to go?
            </motion.h2>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3, type: "spring", stiffness: 200, damping: 20 }}
          >
            <Link 
              to="/destinations" 
              className="group inline-flex items-center gap-2 text-white font-medium hover:text-white/80 transition-colors pb-2 drop-shadow-md"
            >
              View All Destinations
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>

        {/* Places opening one by one in a scroll-driven flex container */}
        <div className="flex flex-col lg:flex-row gap-4 md:gap-5 min-h-[580px] lg:h-[480px]">
          {DESTINATIONS.map((dest, i) => (
            <DestinationCard
              key={dest.id}
              dest={dest}
              index={i}
              total={DESTINATIONS.length}
              progress={activeProgress}
              onClick={() => navigate('/destinations')}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
