import React from 'react';
import { Filter, Search } from 'lucide-react';

interface PackageFilterProps {
  categories: string[];
  activeCategory: string;
  onSelectCategory: (category: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  theme?: 'light' | 'dark';
}

export default function PackageFilter({ 
  categories, 
  activeCategory, 
  onSelectCategory,
  searchQuery,
  onSearchChange,
  theme = 'light'
}: PackageFilterProps) {
  const isLight = theme === 'light';

  return (
    <div className={`flex flex-col lg:flex-row justify-between items-stretch lg:items-center gap-6 mb-12 backdrop-blur-xl p-4 sm:p-6 rounded-[2rem] shadow-lg transition-all ${
      isLight 
        ? 'bg-white/85 border border-stone-200/90 shadow-stone-900/5' 
        : 'bg-white/5 border border-white/10 shadow-2xl'
    }`}>
      {/* Search Input Box */}
      <div className="relative w-full lg:w-80 xl:w-96 focus-within:w-full lg:focus-within:max-w-2xl xl:focus-within:max-w-3xl 2xl:focus-within:max-w-4xl transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]">
        <Search className={`w-4 h-4 sm:w-5 sm:h-5 absolute left-4.5 top-1/2 -translate-y-1/2 transition-colors duration-200 ${
          isLight ? 'text-stone-400 group-focus-within:text-amber-600' : 'text-white/50'
        }`} />
        <input 
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search package, tag, or destination..."
          className={`w-full rounded-full pl-12 pr-16 py-3.5 focus:py-4 sm:focus:py-4.5 text-sm sm:focus:text-base transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] focus:outline-none focus:ring-4 ${
            isLight
              ? 'bg-white/90 border border-stone-300 text-stone-900 placeholder:text-stone-400 focus:border-amber-500 focus:ring-amber-500/20 focus:bg-white shadow-xs focus:shadow-xl focus:shadow-amber-500/10'
              : 'bg-white/5 border border-white/15 text-white placeholder:text-white/40 focus:border-amber-400 focus:ring-amber-400/20 focus:bg-neutral-900/95 shadow-inner focus:shadow-2xl'
          }`}
        />
        {searchQuery && (
          <button 
            onClick={() => onSearchChange('')}
            className={`absolute right-4 top-1/2 -translate-y-1/2 text-xs font-semibold px-2.5 py-1 rounded-full transition-colors ${
              isLight ? 'text-stone-500 hover:text-stone-900 bg-stone-100 hover:bg-stone-200' : 'text-white/60 hover:text-white bg-white/10 hover:bg-white/20'
            }`}
          >
            Clear
          </button>
        )}
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 scrollbar-none flex-shrink min-w-0 transition-all duration-500">
        <div className={`flex items-center gap-2 text-xs font-bold uppercase tracking-wider pr-2 flex-shrink-0 ${
          isLight ? 'text-stone-600' : 'text-white/50'
        }`}>
          <Filter className="w-3.5 h-3.5" />
          <span>Style:</span>
        </div>
        
        {categories.map(category => {
          const isSelected = activeCategory === category;
          return (
            <button
              key={category}
              onClick={() => onSelectCategory(category)}
              className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all duration-300 flex-shrink-0 border ${
                isSelected 
                  ? (isLight 
                      ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-md shadow-amber-500/20 scale-105' 
                      : 'bg-white text-neutral-950 border-white shadow-[0_0_20px_rgba(255,255,255,0.3)] scale-105')
                  : (isLight 
                      ? 'bg-white/80 text-stone-700 border-stone-200 hover:bg-white hover:text-stone-950 shadow-2xs' 
                      : 'bg-white/5 text-white/70 border-white/10 hover:bg-white/10 hover:text-white')
              }`}
            >
              {category}
            </button>
          );
        })}
      </div>
    </div>
  );
}

