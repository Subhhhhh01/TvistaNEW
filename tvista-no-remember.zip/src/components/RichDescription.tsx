import React from 'react';
import { Calendar, Info, Sparkles, MapPin, Clock } from 'lucide-react';

/**
 * Strips markdown and special formatting tags from text for plain previews
 */
export function stripMarkdown(text: string): string {
  if (!text) return '';
  return text
    .replace(/#{1,6}\s+/g, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/_([^_]+)_/g, '$1')
    .replace(/==([^=]+)==/g, '$1')
    .replace(/~~([^~]+)~~/g, '$1')
    .replace(/\[badge:\s*([^\]]+)\]/gi, '$1')
    .replace(/^[•\-*]\s+/gm, '')
    .replace(/^\d+\.\s+/gm, '')
    .replace(/^>\s+/gm, '')
    .replace(/---+/g, '')
    .replace(/\n+/g, ' ')
    .trim();
}

/**
 * Parses inline formatting: **bold**, *italic*, ==highlight==, ~~strike~~, [badge: text]
 */
function renderInlineText(text: string, isLightOnDark = false): React.ReactNode[] {
  // Regex to capture bold (**text**), italic (*text* or _text_), highlight (==text==), strike (~~text~~), badge ([badge: text])
  const tokenRegex = /(\*\*[^*]+\*\*|\*[^*]+\*|_[^_]+_|==[^=]+==|~~[^~]+~~|\[badge:[^\]]+\])/g;
  const parts = text.split(tokenRegex);

  return parts.map((part, index) => {
    if (!part) return null;

    // Bold: **text**
    if (part.startsWith('**') && part.endsWith('**') && part.length >= 4) {
      const inner = part.slice(2, -2);
      return (
        <strong 
          key={index} 
          className={`font-bold ${isLightOnDark ? 'text-amber-200' : 'text-stone-950'}`}
        >
          {inner}
        </strong>
      );
    }

    // Italic: *text* or _text_
    if ((part.startsWith('*') && part.endsWith('*') && part.length >= 2) || 
        (part.startsWith('_') && part.endsWith('_') && part.length >= 2)) {
      const inner = part.slice(1, -1);
      return (
        <em key={index} className="italic opacity-90">
          {inner}
        </em>
      );
    }

    // Highlight: ==text==
    if (part.startsWith('==') && part.endsWith('==') && part.length >= 4) {
      const inner = part.slice(2, -2);
      return (
        <mark 
          key={index} 
          className="px-1.5 py-0.5 rounded-md font-medium text-xs sm:text-sm bg-amber-200/90 text-stone-900 mx-0.5 shadow-2xs inline-block"
        >
          {inner}
        </mark>
      );
    }

    // Strikethrough: ~~text~~
    if (part.startsWith('~~') && part.endsWith('~~') && part.length >= 4) {
      const inner = part.slice(2, -2);
      return (
        <del key={index} className="line-through opacity-60">
          {inner}
        </del>
      );
    }

    // Badge: [badge: text]
    if (part.toLowerCase().startsWith('[badge:') && part.endsWith(']')) {
      const inner = part.slice(7, -1).trim();
      return (
        <span 
          key={index} 
          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-amber-400/20 border border-amber-500/30 text-amber-800 mx-1 align-middle"
        >
          <Sparkles className="w-3 h-3 text-amber-600" />
          {inner}
        </span>
      );
    }

    return part;
  });
}

interface RichDescriptionProps {
  content: string;
  theme?: 'light' | 'dark';
  className?: string;
}

export default function RichDescription({ content, theme = 'light', className = '' }: RichDescriptionProps) {
  if (!content || !content.trim()) {
    return (
      <p className={`italic ${theme === 'dark' ? 'text-white/60' : 'text-stone-500'} text-sm`}>
        No description provided.
      </p>
    );
  }

  const isDark = theme === 'dark';
  const lines = content.split('\n');

  const renderedBlocks: React.ReactNode[] = [];
  let currentList: { type: 'bullet' | 'number'; items: string[] } | null = null;

  const flushList = (keyPrefix: number) => {
    if (!currentList) return;
    const { type, items } = currentList;
    if (type === 'bullet') {
      renderedBlocks.push(
        <ul key={`list-${keyPrefix}`} className="space-y-1.5 my-2.5 pl-1">
          {items.map((item, itemIdx) => (
            <li key={itemIdx} className="flex items-start gap-2.5 text-sm sm:text-base leading-relaxed">
              <span className="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0 shadow-2xs" />
              <span className={isDark ? 'text-stone-200' : 'text-stone-800'}>
                {renderInlineText(item, isDark)}
              </span>
            </li>
          ))}
        </ul>
      );
    } else {
      renderedBlocks.push(
        <ol key={`list-${keyPrefix}`} className="space-y-1.5 my-2.5 pl-1">
          {items.map((item, itemIdx) => (
            <li key={itemIdx} className="flex items-start gap-2.5 text-sm sm:text-base leading-relaxed">
              <span className={`px-1.5 py-0.5 rounded text-[11px] font-bold shrink-0 mt-0.5 ${
                isDark ? 'bg-amber-400/20 text-amber-300' : 'bg-stone-200 text-stone-800'
              }`}>
                {itemIdx + 1}
              </span>
              <span className={isDark ? 'text-stone-200' : 'text-stone-800'}>
                {renderInlineText(item, isDark)}
              </span>
            </li>
          ))}
        </ol>
      );
    }
    currentList = null;
  };

  lines.forEach((line, idx) => {
    const trimmed = line.trim();

    // Empty line
    if (!trimmed) {
      flushList(idx);
      renderedBlocks.push(<div key={`spacer-${idx}`} className="h-2" />);
      return;
    }

    // Horizontal Rule: --- or ***
    if (/^(---|---|\*\*\*)$/.test(trimmed)) {
      flushList(idx);
      renderedBlocks.push(
        <hr 
          key={`hr-${idx}`} 
          className={`my-4 border-t ${isDark ? 'border-white/15' : 'border-stone-200'}`} 
        />
      );
      return;
    }

    // Bullet List: • or - or * (when followed by space)
    if (/^[•\-*]\s+/.test(trimmed)) {
      const itemText = trimmed.replace(/^[•\-*]\s+/, '');
      if (!currentList || currentList.type !== 'bullet') {
        flushList(idx);
        currentList = { type: 'bullet', items: [itemText] };
      } else {
        currentList.items.push(itemText);
      }
      return;
    }

    // Numbered List: 1. or 2.
    if (/^\d+\.\s+/.test(trimmed)) {
      const itemText = trimmed.replace(/^\d+\.\s+/, '');
      if (!currentList || currentList.type !== 'number') {
        flushList(idx);
        currentList = { type: 'number', items: [itemText] };
      } else {
        currentList.items.push(itemText);
      }
      return;
    }

    // Any non-list line flushes list accumulator
    flushList(idx);

    // Tour Route Detection: e.g. "CITY 1 – CITY 2 – CITY 3"
    const hasRouteSeparators = trimmed.includes(' – ') || trimmed.includes(' — ') || (trimmed.includes(' - ') && !trimmed.startsWith('-'));
    const isNotMarkdownHeading = !trimmed.startsWith('#') && !trimmed.startsWith('>') && !trimmed.startsWith('•');
    const isRouteLine = isNotMarkdownHeading && hasRouteSeparators && trimmed.split(/[–—]|\s+-\s+/).length >= 2 && !trimmed.endsWith('.');

    if (isRouteLine) {
      const stops = trimmed.split(/[–—]|\s+-\s+/).map(s => s.trim()).filter(Boolean);
      renderedBlocks.push(
        <div 
          key={`route-${idx}`} 
          className={`my-3 p-3 sm:p-4 rounded-xl border ${
            isDark 
              ? 'bg-amber-400/10 border-amber-400/20' 
              : 'bg-amber-50/80 border-amber-200/80'
          }`}
        >
          <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-900 mb-2">
            <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
            <span className={isDark ? 'text-amber-300' : 'text-amber-900'}>Curated Journey Route</span>
          </div>
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {stops.map((stop, sIdx) => (
              <React.Fragment key={sIdx}>
                <span className={`px-2.5 py-1 rounded-lg text-xs font-bold shadow-2xs border ${
                  isDark 
                    ? 'bg-stone-900 border-white/10 text-stone-200' 
                    : 'bg-white border-stone-200 text-stone-900'
                }`}>
                  {stop}
                </span>
                {sIdx < stops.length - 1 && (
                  <span className="text-amber-500 font-bold text-xs select-none">→</span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      );
      return;
    }

    // Heading 1: # Heading
    if (trimmed.startsWith('# ')) {
      const text = trimmed.slice(2);
      renderedBlocks.push(
        <div key={`h1-${idx}`} className="pt-4 pb-1">
          <h2 className={`text-xl sm:text-2xl font-serif font-bold tracking-tight ${
            isDark ? 'text-white' : 'text-stone-900'
          }`}>
            {renderInlineText(text, isDark)}
          </h2>
          <div className="w-12 h-0.5 bg-amber-500 rounded-full mt-1.5" />
        </div>
      );
      return;
    }

    // Heading 2: ## Heading
    if (trimmed.startsWith('## ')) {
      const text = trimmed.slice(3);
      renderedBlocks.push(
        <div key={`h2-${idx}`} className="pt-3 pb-1">
          <h3 className={`text-lg sm:text-xl font-serif font-bold ${
            isDark ? 'text-amber-200' : 'text-stone-900'
          }`}>
            {renderInlineText(text, isDark)}
          </h3>
        </div>
      );
      return;
    }

    // Check if line is a Day Itinerary heading (with or without '###')
    // Examples: "### Day 1: Arrival", "### DAY 01: Welcome", "Day 1: Arrival", "Day 01 - 03: Resort"
    const dayRegex = /^(?:###\s*)?(Day\s+\d+|Day\s+[0-9]+(\s*-\s*[0-9]+)?|DAY\s+\d+|DAY\s+[0-9]+(\s*-\s*[0-9]+)?)(?:[:\s–-]+(.*))?$/i;
    const dayMatch = trimmed.match(dayRegex);

    if (dayMatch) {
      const dayLabel = dayMatch[1].trim();
      const dayTitle = dayMatch[4] ? dayMatch[4].trim() : '';

      renderedBlocks.push(
        <div key={`day-${idx}`} className="pt-4 pb-1">
          <div className={`inline-flex flex-wrap items-center gap-2 px-3.5 py-1.5 rounded-xl border font-bold text-xs sm:text-sm shadow-2xs ${
            isDark 
              ? 'bg-amber-400/15 border-amber-400/30 text-amber-300' 
              : 'bg-amber-100/90 border-amber-300 text-amber-950'
          }`}>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{dayLabel}</span>
            </div>
            {dayTitle && (
              <>
                <span className="text-amber-400 font-normal select-none">•</span>
                <span className="font-semibold">{renderInlineText(dayTitle, isDark)}</span>
              </>
            )}
          </div>
        </div>
      );
      return;
    }

    // Other Heading 3: ### Heading
    if (trimmed.startsWith('### ')) {
      const text = trimmed.slice(4);
      
      // Special section header under ### (e.g. Highlights, Tour Highlights, Important Notes)
      const isSpecialH3 = /^(Highlights|Tour Highlights|Important Notes|Package Overview):?/i.test(text);
      if (isSpecialH3) {
        renderedBlocks.push(
          <div key={`special-h3-${idx}`} className="pt-4 pb-1">
            <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border shadow-2xs ${
              isDark ? 'bg-amber-950/40 border-amber-800 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}>
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              {text}
            </span>
          </div>
        );
        return;
      }

      renderedBlocks.push(
        <h4 key={`h3-${idx}`} className={`text-base sm:text-lg font-bold pt-2.5 pb-0.5 ${
          isDark ? 'text-amber-100' : 'text-stone-900'
        }`}>
          {renderInlineText(text, isDark)}
        </h4>
      );
      return;
    }

    // Heading 4: #### Heading
    if (trimmed.startsWith('#### ')) {
      const text = trimmed.slice(5);
      renderedBlocks.push(
        <h5 key={`h4-${idx}`} className={`text-sm sm:text-base font-semibold uppercase tracking-wider pt-2 ${
          isDark ? 'text-amber-300' : 'text-amber-800'
        }`}>
          {renderInlineText(text, isDark)}
        </h5>
      );
      return;
    }

    // Blockquote: > Quote
    if (trimmed.startsWith('>')) {
      const quoteText = trimmed.replace(/^>\s*/, '');
      renderedBlocks.push(
        <div 
          key={`quote-${idx}`} 
          className={`pl-4 py-3 my-3 border-l-4 rounded-r-xl ${
            isDark 
              ? 'border-amber-400 bg-white/5 text-stone-200' 
              : 'border-amber-500 bg-amber-50/70 text-stone-800'
          }`}
        >
          <p className="text-xs sm:text-sm italic leading-relaxed">
            {renderInlineText(quoteText, isDark)}
          </p>
        </div>
      );
      return;
    }

    // Highlights / Overview Standalone Headers: e.g. "Highlights:"
    const isSpecialHeader = /^(Highlights|Tour Highlights|Important Notes|Package Overview):/i.test(trimmed);
    if (isSpecialHeader) {
      renderedBlocks.push(
        <div key={`special-${idx}`} className="pt-4 pb-1">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-wider border shadow-2xs ${
            isDark ? 'bg-amber-950/40 border-amber-800 text-amber-300' : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            {trimmed}
          </span>
        </div>
      );
      return;
    }

    // Standard Paragraph with inline formatting
    renderedBlocks.push(
      <p 
        key={`p-${idx}`} 
        className={`leading-relaxed text-sm sm:text-base ${
          isDark ? 'text-stone-200' : 'text-stone-800'
        }`}
      >
        {renderInlineText(line, isDark)}
      </p>
    );
  });

  // Flush any trailing list
  flushList(lines.length);

  return (
    <div className={`space-y-1.5 ${className}`}>
      {renderedBlocks}
    </div>
  );
}
