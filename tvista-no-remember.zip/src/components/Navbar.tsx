import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Phone, Mail, LogIn, UserPlus } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import TvistaLogo from './TvistaLogo';
import SignUpModal from './SignUpModal';

interface NavbarProps {
  theme?: 'dark' | 'light';
}

export default function Navbar({ theme = 'light' }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('signup') === 'true';
    }
    return false;
  });
  const location = useLocation();
  const isLight = theme === 'light';

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('signup') === 'true') {
      setIsSignUpOpen(true);
    }
  }, [location.search]);

  useEffect(() => {
    const handleOpenSignup = () => setIsSignUpOpen(true);
    window.addEventListener('open-signup', handleOpenSignup);
    return () => window.removeEventListener('open-signup', handleOpenSignup);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Flights', path: '/flights' },
    { name: 'Destinations', path: '/destinations' },
    { name: 'Packages', path: '/packages' },
    { name: 'Visa Info', path: '/visa' },
    { name: 'Promos', path: '/promos', isSpecial: true },
    { name: 'News', path: '/news' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Contact Us', path: '/contact' }
  ];

  return (
    <>
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-4 sm:px-8 lg:px-12 xl:px-16 flex items-center justify-between ${
          isMobileMenuOpen
            ? (isLight 
                ? 'bg-white/65 border-b border-white/60 py-3 shadow-md text-stone-900' 
                : 'bg-black/40 border-b border-white/10 py-3 shadow-xs')
            : isScrolled 
              ? (isLight 
                  ? 'bg-white/70 border-b border-stone-200/80 shadow-[0_8px_32px_0_rgba(0,0,0,0.08)] py-2.5 text-stone-900' 
                  : 'bg-neutral-950/75 border-b border-white/10 shadow-2xl py-2.5') 
              : (isLight 
                  ? 'bg-white/45 border-b border-white/50 shadow-[0_4px_24px_0_rgba(0,0,0,0.06)] py-3.5 text-stone-900' 
                  : 'bg-black/25 border-b border-white/10 py-3.5')
        }`}
        style={{
          WebkitBackdropFilter: isMobileMenuOpen 
            ? 'blur(48px) saturate(200%) brightness(105%)' 
            : isScrolled 
              ? 'blur(40px) saturate(200%) brightness(103%)' 
              : 'blur(36px) saturate(190%) brightness(105%)',
          backdropFilter: isMobileMenuOpen 
            ? 'blur(48px) saturate(200%) brightness(105%)' 
            : isScrolled 
              ? 'blur(40px) saturate(200%) brightness(103%)' 
              : 'blur(36px) saturate(190%) brightness(105%)'
        }}
      >
        <Link 
          to="/" 
          className="flex items-center cursor-pointer group transition-transform active:scale-95 py-1 shrink-0"
          aria-label="Tvista Holidays Home"
        >
          {/* Seamless Transparent Logo */}
          <div className="flex items-center transition-all duration-300">
            <TvistaLogo 
              className="h-8 sm:h-9 md:h-10 w-auto object-contain transition-all duration-300" 
              variant={isLight ? 'color' : 'on-dark'}
            />
          </div>
        </Link>
        
        <ul className="hidden lg:flex items-center gap-4 xl:gap-6 2xl:gap-8">
          {navLinks.map((item) => (
            <li key={item.name}>
              <Link
                to={item.path}
                className={`text-[11.5px] xl:text-[12.5px] 2xl:text-[13px] font-semibold uppercase tracking-wider transition-colors relative group flex items-center gap-1 ${
                  isLight 
                    ? 'text-stone-700 hover:text-stone-950' 
                    : 'text-white/85 hover:text-white'
                } ${item.isSpecial ? (isLight ? 'text-amber-700 hover:text-amber-800 font-bold' : 'text-amber-400 hover:text-amber-300') : ''}`}
              >
                <span>{item.name}</span>
                {item.isSpecial && (
                  <span className={`w-1.5 h-1.5 rounded-full ${isLight ? 'bg-amber-600' : 'bg-amber-400'} animate-pulse`} />
                )}
                {location.pathname === item.path && (
                  <span className={`absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-[2px] rounded-full ${
                    isLight ? 'bg-stone-900' : (item.isSpecial ? 'bg-amber-400' : 'bg-white')
                  }`}></span>
                )}
              </Link>
            </li>
          ))}
        </ul>
        
        <div className="flex items-center gap-2 sm:gap-2.5 md:gap-3">
          <a
            href="https://travel.tvistaholidays.com/login"
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center gap-1.5 px-3 sm:px-3.5 h-9 rounded-full text-xs font-semibold uppercase tracking-wider transition-all border ${
              isLight
                ? 'border-stone-300/80 bg-white/70 text-stone-800 hover:bg-white hover:text-stone-950 hover:border-stone-400 shadow-xs'
                : 'border-white/20 bg-white/10 text-white hover:bg-white/20 hover:border-white/35 backdrop-blur-md'
            }`}
          >
            <LogIn className="w-3.5 h-3.5 opacity-80" />
            <span>Sign In</span>
          </a>

          <button
            type="button"
            onClick={() => setIsSignUpOpen(true)}
            className={`flex items-center gap-1.5 px-3 sm:px-3.5 h-9 rounded-full text-xs font-semibold uppercase tracking-wider transition-all border ${
              isLight
                ? 'border-amber-400 bg-amber-50 text-amber-900 hover:bg-amber-100 hover:border-amber-500 shadow-xs'
                : 'border-amber-400/40 bg-amber-400/15 text-amber-300 hover:bg-amber-400/25 hover:border-amber-400 backdrop-blur-md'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Sign Up</span>
          </button>

          <Link
            to="/contact"
            className={`hidden xl:flex items-center justify-center px-4.5 h-9 rounded-full text-xs font-semibold uppercase tracking-widest transition-all ${
              isLight 
                ? 'bg-amber-500 text-stone-950 hover:bg-amber-400 font-bold shadow-sm shadow-amber-500/20' 
                : 'bg-white text-neutral-950 hover:bg-amber-200 shadow-[0_0_15px_rgba(255,255,255,0.2)]'
            }`}
          >
            Enquire Now
          </Link>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle Navigation Menu"
            className={`lg:hidden w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
              isMobileMenuOpen
                ? (isLight 
                    ? 'bg-stone-200 text-stone-900 hover:bg-stone-300 backdrop-blur-md' 
                    : 'bg-white/15 text-white hover:bg-white/25 backdrop-blur-md border border-white/15')
                : (isLight 
                    ? 'bg-stone-100 text-stone-800 hover:bg-stone-200 border border-stone-200/90 backdrop-blur-md' 
                    : 'bg-white/10 text-white hover:bg-white/20 backdrop-blur-md border border-white/10')
            }`}
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu Drawer - Transparent Blurry Theme */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className={`fixed inset-0 z-40 pt-28 px-8 pb-10 flex flex-col justify-between overflow-y-auto ${
              isLight
                ? 'bg-white/80 text-stone-900'
                : 'bg-black/35 text-white'
            }`}
            style={{
              WebkitBackdropFilter: 'blur(48px) saturate(190%)',
              backdropFilter: 'blur(48px) saturate(190%)'
            }}
          >
            <ul className="flex flex-col gap-3.5 sm:gap-4 pt-2">
              {navLinks.map((item) => {
                const isActive = location.pathname === item.path;
                return (
                  <li key={item.name}>
                    <Link
                      to={item.path}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`text-xl sm:text-2xl font-serif tracking-wide transition-all flex items-center justify-between py-1 ${
                        isLight
                          ? (isActive ? 'text-neutral-950 font-bold' : 'text-stone-700 hover:text-neutral-950')
                          : (isActive ? 'text-white font-bold drop-shadow-[0_1px_6px_rgba(0,0,0,0.6)]' : 'text-white/75 hover:text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.7)]')
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {item.name}
                      </span>
                      {isActive && (
                        <span className={`w-2.5 h-2.5 rounded-full ${
                          isLight 
                            ? 'bg-neutral-950' 
                            : 'bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]'
                        }`} />
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>

            <div className={`border-t pt-6 flex flex-col gap-3 ${
              isLight ? 'border-stone-300/60' : 'border-white/15'
            }`}>
              <a
                href="https://travel.tvistaholidays.com/login"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`w-full py-3 font-semibold rounded-full text-center text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border ${
                  isLight
                    ? 'border-stone-300 bg-stone-100 text-stone-900 hover:bg-stone-200'
                    : 'border-white/20 bg-white/10 text-white hover:bg-white/20'
                }`}
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In to Portal</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsSignUpOpen(true);
                }}
                className={`w-full py-3 font-semibold rounded-full text-center text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 border ${
                  isLight
                    ? 'border-amber-400 bg-amber-50 text-amber-900 hover:bg-amber-100'
                    : 'border-amber-400/40 bg-amber-400/15 text-amber-300 hover:bg-amber-400/25'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>Sign Up (Partner Registration)</span>
              </button>

              <Link
                to="/contact"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`w-full py-3.5 font-bold rounded-full text-center text-xs uppercase tracking-widest shadow-md transition-all active:scale-[0.99] ${
                  isLight
                    ? 'bg-neutral-950 text-white hover:bg-neutral-800'
                    : 'bg-white text-neutral-950 hover:bg-neutral-100 shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                }`}
              >
                Plan Your Journey
              </Link>
              
              <div className={`flex items-center justify-between pt-1 px-1 text-xs ${
                isLight ? 'text-stone-600' : 'text-white/80'
              }`}>
                <a 
                  href="tel:+919830712357" 
                  className={`flex items-center gap-1.5 font-medium transition-colors ${
                    isLight ? 'hover:text-neutral-950' : 'hover:text-white'
                  }`}
                >
                  <Phone className="w-3.5 h-3.5 opacity-80" />
                  <span>+91 98307 12357</span>
                </a>
                <a 
                  href="mailto:support@tvistaholidays.com" 
                  className={`flex items-center gap-1.5 font-medium transition-colors ${
                    isLight ? 'hover:text-neutral-950' : 'hover:text-white'
                  }`}
                >
                  <Mail className="w-3.5 h-3.5 opacity-80" />
                  <span>Email Us</span>
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Partner Registration / Sign Up Modal */}
      <SignUpModal
        isOpen={isSignUpOpen}
        onClose={() => setIsSignUpOpen(false)}
      />
    </>
  );
}
