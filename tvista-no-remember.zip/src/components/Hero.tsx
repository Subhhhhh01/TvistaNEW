import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plane, ArrowLeft, ArrowRight, MapPin, Users, Search } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useData } from '../context/DataContext';

const DESTINATIONS = [
  {
    id: 1,
    title: 'Tropical Beaches',
    location: 'Maldives',
    image: 'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?q=80&w=2065&auto=format&fit=crop',
  },
  {
    id: 2,
    title: 'Historic Cities',
    location: 'Prague',
    image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?q=80&w=2000&auto=format&fit=crop',
  },
  {
    id: 3,
    title: 'Breathtaking Nature',
    location: 'Switzerland',
    image: 'https://images.unsplash.com/photo-1527668752968-14dc70a27c95?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 4,
    title: 'Cultural Escapes',
    location: 'Kyoto, Japan',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 5,
    title: 'Desert Wonders',
    location: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=2070&auto=format&fit=crop',
  },
  {
    id: 6,
    title: 'Alpine Lakes',
    location: 'Banff, Canada',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
  }
];

export default function Hero() {
  const { homeContent } = useData();
  const heroSettings = homeContent?.settings;
  const heroCardsData = homeContent?.heroCards && homeContent.heroCards.length > 0 ? homeContent.heroCards : DESTINATIONS;

  const iterationRef = useRef(1);
  const [cards, setCards] = useState(() => heroCardsData.map(d => ({ ...d, uniqueKey: `dest-${d.id}-0` })));
  const [isPaused, setIsPaused] = useState(false);
  const isDraggingRef = useRef(false);

  // Sync cards when admin updates hero cards
  useEffect(() => {
    if (heroCardsData && heroCardsData.length > 0) {
      setCards(heroCardsData.map(d => ({ ...d, uniqueKey: `dest-${d.id}-0` })));
    }
  }, [heroCardsData]);

  // Swipe detection for mobile container
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  const nextCard = useCallback((steps = 1) => {
    setCards(prev => {
      const newCards = [...prev];
      for (let i = 0; i < steps; i++) {
        const removed = newCards.shift();
        if (removed) {
          newCards.push({ ...removed, uniqueKey: `dest-${removed.id}-${iterationRef.current + i}` });
        }
      }
      iterationRef.current += steps;
      return newCards;
    });
  }, []);

  const prevCard = useCallback(() => {
    setCards(prev => {
      const newCards = [...prev];
      const last = newCards.pop();
      if (last) {
        iterationRef.current += 1;
        newCards.unshift({ ...last, uniqueKey: `dest-${last.id}-${iterationRef.current}` });
      }
      return newCards;
    });
  }, []);

  // Auto-play timer with pause on hover/interaction
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => nextCard(1), 4500);
    return () => clearInterval(timer);
  }, [nextCard, isPaused]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
    setIsPaused(true);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    setIsPaused(false);
    if (touchStartX.current === null || touchStartY.current === null) return;
    const deltaX = e.changedTouches[0].clientX - touchStartX.current;
    const deltaY = e.changedTouches[0].clientY - touchStartY.current;

    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 35) {
      if (deltaX < 0) {
        nextCard(1);
      } else {
        prevCard();
      }
    }
    touchStartX.current = null;
    touchStartY.current = null;
  };

  return (
    <section className="relative w-full min-h-screen bg-neutral-50 overflow-hidden font-sans pt-28 pb-20 lg:pb-48 flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0 bg-neutral-950">
        <img 
          src={heroSettings?.bgImage || "https://images.unsplash.com/photo-1510414842594-a61c69b5ae57?q=80&w=2070&auto=format&fit=crop"} 
          alt="Aesthetic Beautiful Sea View Background" 
          className="w-full h-full object-cover object-center opacity-80"
        />
        <div className="absolute inset-0 bg-black/20"></div>
      </div>

      {/* Decorative Wave at the bottom */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden leading-none z-0">
        <svg className="relative block w-full h-[100px] md:h-[150px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
          <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V0C73.41,18.9,146.9,45.42,221.7,53.27,255.4,56.88,289.17,59.22,321.39,56.44Z" className="fill-neutral-50"></path>
        </svg>
      </div>

      <div className="container mx-auto px-4 sm:px-8 lg:px-20 relative z-10 w-full py-4 sm:py-0">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-8">
          
          {/* Left Content */}
          <div className="w-full lg:w-1/2 max-w-2xl mt-4 sm:mt-8 lg:mt-0 lg:-ml-8 xl:-ml-12 text-center lg:text-left flex flex-col items-center lg:items-start">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 px-3.5 py-1.5 sm:px-5 sm:py-2.5 rounded-full mb-3 sm:mb-6 shadow-sm"
            >
              <Plane className="w-3.5 h-3.5 text-white" />
              <span className="text-white text-[11px] sm:text-[13px] font-bold tracking-widest uppercase">
                {heroSettings?.badgeText || 'Your Journey Starts Here'}
              </span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-3xl sm:text-5xl lg:text-7xl font-serif font-bold text-white leading-[1.1] mb-3 sm:mb-6 tracking-tight drop-shadow-md"
            >
              {heroSettings?.title ? heroSettings.title : (
                <>
                  See The World<br />In A <span className="text-white relative inline-block">
                    New Way
                    <svg className="absolute w-full h-3 -bottom-1 left-0 text-white/50" viewBox="0 0 100 10" preserveAspectRatio="none">
                      <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="3" fill="transparent"/>
                    </svg>
                  </span>
                </>
              )}
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-white/90 text-sm sm:text-lg lg:text-xl mb-4 sm:mb-8 lg:mb-10 max-w-md leading-relaxed font-medium drop-shadow-sm"
            >
              {heroSettings?.subtitle || 'Unique destinations, local experiences and memories to last a lifetime.'}
            </motion.p>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="flex flex-wrap items-center justify-center lg:justify-start gap-4 sm:gap-6"
            >
              <Link to="/destinations" className="bg-white hover:bg-neutral-100 text-neutral-950 px-6 py-3 sm:px-8 sm:py-4 rounded-full text-xs sm:text-[13px] uppercase tracking-wider font-bold flex items-center gap-2.5 sm:gap-3 transition-colors shadow-lg group">
                Explore Now
                <div className="bg-neutral-950 rounded-full p-1 group-hover:translate-x-1 transition-transform">
                  <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                </div>
              </Link>
            </motion.div>

            {/* Stats Row */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-5 sm:mt-10 lg:mt-16 flex flex-wrap items-center justify-center lg:justify-start gap-5 sm:gap-8 lg:gap-12 text-sm"
            >
              <div className="flex items-center gap-2.5 sm:gap-4">
                <div className="w-9 h-9 sm:w-12 sm:h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white shadow-sm border border-white/20">
                  <MapPin className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-base sm:text-xl text-white">100+</p>
                  <p className="text-white/70 text-[9px] sm:text-[11px] font-bold uppercase tracking-widest mt-0.5 drop-shadow-sm">Destinations</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2.5 sm:gap-4">
                <div className="w-9 h-9 sm:w-12 sm:h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white shadow-sm border border-white/20">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-base sm:text-xl text-white">5k+</p>
                  <p className="text-white/70 text-[9px] sm:text-[11px] font-bold uppercase tracking-widest mt-0.5 drop-shadow-sm">Travellers</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2.5 sm:gap-4">
                <div className="w-9 h-9 sm:w-12 sm:h-12 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white shadow-sm border border-white/20">
                  <Search className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-base sm:text-xl text-white">24/7</p>
                  <p className="text-white/70 text-[9px] sm:text-[11px] font-bold uppercase tracking-widest mt-0.5 drop-shadow-sm">Support</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Content - Cards Carousel with Mouse & Touch Sliding */}
          <div 
            className="w-full lg:w-[50%] relative h-[270px] sm:h-[410px] lg:h-[650px] flex flex-col justify-center lg:justify-end items-center mt-2 lg:mt-0 select-none touch-pan-y"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
          >
            {/* Slide Pagination & Drag Hint */}
            <div className="w-[220px] sm:w-[320px] lg:w-[400px] lg:mr-16 flex items-center justify-between mb-2 sm:mb-3 px-1">
              <div className="flex items-center gap-1.5">
                {DESTINATIONS.map((d, i) => {
                  const isCurrent = cards[0]?.id === d.id;
                  return (
                    <button
                      key={d.id}
                      onClick={() => {
                        const targetIdx = cards.findIndex(c => c.id === d.id);
                        if (targetIdx > 0) nextCard(targetIdx);
                      }}
                      aria-label={`Go to slide ${i + 1}`}
                      className={`h-1.5 rounded-full transition-all duration-300 ${
                        isCurrent 
                          ? 'w-6 bg-white shadow-sm' 
                          : 'w-1.5 bg-white/35 hover:bg-white/60'
                      }`}
                    />
                  );
                })}
              </div>
              <div className="inline-flex items-center gap-1 text-[10px] sm:text-[11px] font-medium tracking-wide text-white/80 bg-white/10 backdrop-blur-md px-2.5 py-0.5 rounded-full border border-white/20 select-none">
                <span>Slide with mouse or touch</span>
              </div>
            </div>

            <div className="relative w-[220px] sm:w-[320px] lg:w-[400px] h-[220px] sm:h-[340px] lg:h-[600px] lg:mr-16">
              <AnimatePresence mode="popLayout">
                {cards.map((dest, idx) => {
                  const isActive = idx === 0;
                  const offset = idx;

                  return (
                    <motion.div
                      key={dest.uniqueKey}
                      drag={isActive ? "x" : false}
                      dragDirectionLock
                      dragConstraints={{ left: 0, right: 0 }}
                      dragElastic={0.4}
                      onDragStart={() => {
                        isDraggingRef.current = true;
                        setIsPaused(true);
                      }}
                      onDragEnd={(e, info) => {
                        setTimeout(() => {
                          isDraggingRef.current = false;
                          setIsPaused(false);
                        }, 120);
                        const threshold = 35;
                        const velocityThreshold = 200;
                        if (info.offset.x < -threshold || info.velocity.x < -velocityThreshold) {
                          nextCard(1);
                        } else if (info.offset.x > threshold || info.velocity.x > velocityThreshold) {
                          prevCard();
                        }
                      }}
                      whileDrag={{ scale: 1.02, cursor: 'grabbing' }}
                      className={`absolute top-0 left-0 w-full h-full rounded-2xl sm:rounded-[2.2rem] overflow-hidden select-none touch-pan-y ${
                        isActive 
                          ? 'cursor-grab active:cursor-grabbing shadow-2xl shadow-gray-900/40' 
                          : 'cursor-pointer shadow-xl shadow-black/5'
                      }`}
                      initial={{ opacity: 0, x: 100 }}
                      animate={{
                        x: offset * 32,
                        y: 0,
                        scale: 1 - (offset * 0.05),
                        opacity: 1,
                        zIndex: 40 - offset,
                      }}
                      exit={{ opacity: 0, x: -70, y: -10, scale: 0.9 }}
                      transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
                      style={{
                        transformOrigin: 'bottom left',
                        border: isActive ? '4px solid white' : '1px solid rgba(255, 255, 255, 0.5)',
                      }}
                      onClick={() => {
                        if (isDraggingRef.current) return;
                        if (offset > 0) nextCard(offset);
                      }}
                    >
                      <img 
                        src={dest.image} 
                        alt={dest.title} 
                        draggable={false}
                        className="w-full h-full object-cover pointer-events-none select-none" 
                      />
                      
                      {isActive ? (
                        <>
                          <div className="absolute inset-0 bg-black/10 pointer-events-none"></div>
                          <div className="absolute bottom-2 sm:bottom-4 left-2 sm:left-4 right-2 sm:right-4">
                            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-2.5 sm:p-5 rounded-2xl sm:rounded-3xl flex items-center justify-between shadow-lg">
                              <div>
                                <h3 className="text-base sm:text-2xl font-bold leading-tight mb-0.5 text-white drop-shadow-sm">{dest.title}</h3>
                                <div className="flex items-center gap-1 text-white/90 text-xs sm:text-sm font-medium drop-shadow-sm">
                                  <MapPin className="w-3 h-3 sm:w-4 sm:h-4" />
                                  {dest.location}
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 sm:gap-2">
                                <button 
                                  aria-label="Previous destination"
                                  className="w-7 h-7 sm:w-10 sm:h-10 bg-white/90 hover:bg-white text-neutral-900 rounded-full flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-transform shrink-0"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    prevCard();
                                  }}
                                >
                                  <ArrowLeft className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                                </button>
                                <button 
                                  aria-label="Next destination"
                                  className="w-8 h-8 sm:w-11 sm:h-11 bg-white text-neutral-900 rounded-full flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-transform shrink-0"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    nextCard(1);
                                  }}
                                >
                                  <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="absolute inset-0 bg-white/20 backdrop-blur-[2px] pointer-events-none"></div>
                          <div className="absolute bottom-2 sm:bottom-4 left-2 sm:left-4 right-2 sm:right-4 pointer-events-none">
                            <div className="bg-white/10 backdrop-blur-md border border-white/20 p-2 sm:p-4 rounded-2xl sm:rounded-3xl shadow-sm">
                              <h3 className="text-xs sm:text-lg font-bold leading-tight mb-0.5 text-white drop-shadow-sm">{dest.title}</h3>
                              <div className="flex items-center gap-1 text-white/90 text-[10px] sm:text-xs font-medium drop-shadow-sm">
                                <MapPin className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5" />
                                {dest.location}
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
          
        </div>
      </div>

      {/* Floating Search Bar Removed */}
    </section>
  );
}
