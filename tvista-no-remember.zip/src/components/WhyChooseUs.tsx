import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Star } from 'lucide-react';

const ACCOMMODATIONS = [
  {
    id: 1,
    title: 'Oceanfront Villa',
    location: 'Maldives',
    desc: 'Experience the ultimate luxury in our overwater bungalows. Wake up to crystal clear waters and endless ocean views.',
    image: 'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?q=80&w=2070&auto=format&fit=crop',
    price: '₹98,000/night',
    rating: '4.9',
    amenities: ['Ocean View', 'Private Pool', 'Spa']
  },
  {
    id: 2,
    title: 'Alpine Sanctuary',
    location: 'Swiss Alps',
    desc: 'A luxurious mountain retreat offering breathtaking views. Warm up by the stone fireplace after a day exploring the peaks.',
    image: 'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?q=80&w=2071&auto=format&fit=crop',
    price: '₹68,000/night',
    rating: '4.8',
    amenities: ['Fireplace', 'Mountain View', 'Hot Tub']
  },
  {
    id: 3,
    title: 'Lakeside Manor',
    location: 'Lake Como, Italy',
    desc: 'Experience classic European elegance by the lake. Featuring sprawling gardens and exquisite views of the water.',
    image: 'https://images.unsplash.com/photo-1534430480872-3498386e7856?q=80&w=2070&auto=format&fit=crop',
    price: '₹1,25,000/night',
    rating: '5.0',
    amenities: ['Private Boat', 'Garden', 'Chef']
  },
  {
    id: 4,
    title: 'Desert Oasis',
    location: 'Dubai, UAE',
    desc: 'A magnificent private estate surrounded by golden dunes. Enjoy ultimate seclusion under the starlit desert sky.',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?q=80&w=2070&auto=format&fit=crop',
    price: '₹1,75,000/night',
    rating: '4.9',
    amenities: ['Dune Views', 'Infinity Pool', 'Butler']
  },
  {
    id: 5,
    title: 'Urban Penthouse',
    location: 'New York, USA',
    desc: 'Soar above the city in this modern, glass-walled penthouse offering panoramic skyline views and sleek, contemporary design.',
    image: 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?q=80&w=2070&auto=format&fit=crop',
    price: '₹2,85,000/night',
    rating: '4.9',
    amenities: ['City Views', 'Rooftop Terrace', 'Gym']
  },
  {
    id: 6,
    title: 'Scenic Retreat',
    location: 'Fjords, Norway',
    desc: 'A serene cabin nestled deeply within majestic nature. Reconnect with the natural world in breathtaking tranquility.',
    image: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?q=80&w=2070&auto=format&fit=crop',
    price: '₹78,000/night',
    rating: '4.8',
    amenities: ['Nature Trails', 'Sauna', 'Eco-friendly']
  }
];

export default function WhyChooseUs() {
  const [activeItem, setActiveItem] = useState(0);

  return (
    <section className="relative h-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-12 overflow-hidden bg-stone-900">
      {/* Blurred background image layer */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.img 
          animate={{ scale: [1.05, 1.15, 1.05] }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?q=80&w=2075&auto=format&fit=crop"
          alt="Lavish aesthetic villa background"
          className="absolute inset-0 w-full h-full object-cover opacity-60"
        />
        <div className="absolute inset-0 bg-stone-900/30 backdrop-blur-sm"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-900/40 to-stone-950/60"></div>
      </div>

      <div className="relative z-10 w-full max-w-[1400px] mx-auto flex flex-col h-full">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 flex flex-col lg:flex-row lg:items-end justify-between gap-8"
        >
          <div className="max-w-2xl">
            <p className="text-sm font-bold tracking-[0.2em] uppercase text-white/50 mb-4 flex items-center gap-4">
              <span className="w-12 h-[1px] bg-white/30"></span>
              Curated Selection
            </p>
            <h2 className="text-5xl md:text-7xl font-serif text-white leading-tight mb-6">
              Signature <span className="italic text-white/70">Residences</span>
            </h2>
            <p className="text-white/80 text-lg leading-relaxed max-w-xl">
              Experience the pinnacle of luxury with our handpicked collection of exquisite properties across the globe. Each residence is chosen for its unparalleled beauty, exceptional amenities, and unique architectural character.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-8 md:gap-12 pb-2">
            <div>
              <p className="text-4xl md:text-5xl font-serif text-white mb-2">150+</p>
              <p className="text-xs font-bold tracking-[0.2em] uppercase text-white/50">Exclusive Villas</p>
            </div>
            <div className="w-[1px] h-12 bg-white/20 hidden md:block"></div>
            <div>
              <p className="text-4xl md:text-5xl font-serif text-white mb-2">4.9</p>
              <p className="text-xs font-bold tracking-[0.2em] uppercase text-white/50">Average Rating</p>
            </div>
            <div className="w-[1px] h-12 bg-white/20 hidden md:block"></div>
            <div>
              <p className="text-4xl md:text-5xl font-serif text-white mb-2">24/7</p>
              <p className="text-xs font-bold tracking-[0.2em] uppercase text-white/50">Concierge</p>
            </div>
          </div>
        </motion.div>

        {/* Expanding Cards */}
        <div className="flex-1 flex flex-col lg:flex-row gap-4 h-full min-h-[350px] lg:min-h-[400px]">
          {ACCOMMODATIONS.map((item, index) => {
            const isActive = activeItem === index;

            return (
              <div
                key={item.id}
                onClick={() => setActiveItem(index)}
                className={`group relative overflow-hidden cursor-pointer rounded-3xl transition-[flex,width,height] duration-700 ease-[cubic-bezier(0.25,1,0.5,1)] border ${
                  isActive 
                    ? 'lg:flex-[6] lg:h-full h-[350px] border-white/30 shadow-2xl shadow-black/50' 
                    : 'lg:flex-[1] lg:h-full h-[70px] border-white/10 hover:border-white/20'
                }`}
              >
                {/* Background Image */}
                <img
                  src={item.image}
                  alt={item.title}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                />
                
                {/* Overlays */}
                <div 
                  className={`absolute inset-0 transition-all duration-700 ${
                    isActive 
                      ? 'bg-gradient-to-t from-black/90 via-black/40 to-black/10' 
                      : 'bg-black/60 group-hover:bg-black/40'
                  }`}
                />

                {/* Content Container */}
                <div className="absolute inset-0 flex flex-col justify-end">
                  {/* Number Badge */}
                  <div className={`absolute top-6 left-6 w-10 h-10 rounded-full flex items-center justify-center bg-black/40 backdrop-blur-md text-white font-serif border border-white/20 transition-opacity duration-500 ${!isActive && 'opacity-0 lg:opacity-100'}`}>
                    0{index + 1}
                  </div>

                  {/* Vertical text for non-active states on Desktop */}
                  <div className={`absolute bottom-10 left-6 origin-bottom-left -rotate-90 text-2xl font-serif text-white tracking-wider whitespace-nowrap transition-all duration-500 hidden lg:block ${
                    isActive ? 'opacity-0 translate-y-10' : 'opacity-100 translate-y-0'
                  }`}>
                    {item.title}
                  </div>

                  {/* Horizontal text for non-active states on Mobile */}
                  <div className={`absolute inset-y-0 left-6 flex items-center lg:hidden transition-all duration-500 ${
                    isActive ? 'opacity-0 -translate-x-10 pointer-events-none' : 'opacity-100 translate-x-0'
                  }`}>
                    <h3 className="text-xl font-serif text-white">{item.title}</h3>
                  </div>

                  {/* Active Content */}
                  <div className={`p-6 md:p-8 transition-all duration-700 ease-out transform ${
                    isActive ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none absolute bottom-0'
                  }`}>
                    <div className="flex flex-col gap-3 max-w-2xl">
                      <div>
                        <h3 className="text-3xl md:text-4xl lg:text-5xl font-serif text-white mb-2 leading-tight">
                          {item.title}
                        </h3>
                        <p className="text-white/70 flex items-center gap-2 text-sm uppercase tracking-wider font-medium">
                          <MapPin className="w-4 h-4" /> {item.location}
                        </p>
                      </div>
                      
                      <p className="text-white/80 text-base md:text-lg leading-relaxed">
                        {item.desc}
                      </p>

                      <div className="flex flex-wrap items-center gap-3 mt-4">
                        <div className="px-4 py-2 bg-white text-black rounded-full font-semibold text-sm">
                          {item.price}
                        </div>
                        <div className="px-4 py-2 bg-black/50 backdrop-blur-md rounded-full border border-white/20 text-white font-medium flex items-center gap-2 text-sm">
                          <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" /> {item.rating}
                        </div>
                        {item.amenities.map(amenity => (
                          <div key={amenity} className="hidden sm:block px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-white/10 text-white/90 text-sm">
                            {amenity}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
