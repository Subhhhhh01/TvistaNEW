import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Clock, Star, ArrowRight, Sparkles } from 'lucide-react';
import { Package } from '../data/packagesData';
import { stripMarkdown } from './RichDescription';

interface PackageCardProps {
  key?: React.Key;
  pkg: Package;
  index: number;
  onSelect: (pkg: Package) => void;
  theme?: 'light' | 'dark';
}

export default function PackageCard({ pkg, index, onSelect, theme = 'light' }: PackageCardProps) {
  const isLight = theme === 'light';
  const durationText = pkg.duration ? (pkg.duration.includes('/') ? pkg.duration.split('/')[0].trim() : pkg.duration) : 'Flexible';
  const tags = Array.isArray(pkg.tags) && pkg.tags.length > 0 ? pkg.tags : ['Featured'];
  const rating = pkg.rating || 4.8;
  const reviews = pkg.reviews ?? 0;
  const location = pkg.location || 'Worldwide';
  const title = pkg.title || 'Tour Package';
  const price = pkg.price || 'Price on Request';
  const description = stripMarkdown(pkg.description) || 'Exclusive luxury travel experience crafted by Tvista Holidays.';
  const image = pkg.image || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      onClick={() => onSelect(pkg)}
      className={`rounded-[2.2rem] p-3.5 shadow-md hover:shadow-2xl transition-all duration-500 group flex flex-col cursor-pointer ${
        isLight
          ? 'bg-white/85 backdrop-blur-xl border border-stone-200/90 hover:border-amber-400/80 hover:bg-white/95 text-stone-900 shadow-stone-900/5'
          : 'bg-white/10 backdrop-blur-xl border border-white/15 hover:border-white/40 hover:bg-white/15 text-white shadow-2xl'
      }`}
    >
      {/* Image Container */}
      <div className="relative h-64 sm:h-72 rounded-[1.8rem] overflow-hidden bg-neutral-900">
        <img 
          src={image} 
          alt={title} 
          loading="lazy"
          onError={(e) => {
            const target = e.currentTarget;
            if (!target.dataset.fallback) {
              target.dataset.fallback = 'true';
              target.src = 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop';
            }
          }}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-950/20 to-transparent" />
        
        {/* Top Floating Badges */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none">
          <div className="px-3.5 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg">
            <Clock className="w-3.5 h-3.5 text-white/80" />
            <span>{durationText}</span>
          </div>

          <div className="px-3.5 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="text-white">{rating}</span>
            <span className="text-white/60 font-normal">({reviews})</span>
          </div>
        </div>

        {/* Location Overlay on Bottom of Image */}
        <div className="absolute bottom-4 left-4 right-4 z-10">
          <div className="flex items-center gap-1.5 text-white text-xs font-semibold uppercase tracking-wider drop-shadow-md">
            <MapPin className="w-3.5 h-3.5 text-amber-300" />
            <span>{location}</span>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-3">
            {tags.map(tag => (
              <span 
                key={tag} 
                className={`px-3 py-1 text-[10px] font-bold uppercase tracking-widest rounded-full backdrop-blur-md ${
                  isLight
                    ? 'bg-amber-50 border border-amber-200/80 text-amber-900'
                    : 'bg-white/10 border border-white/15 text-white/90'
                }`}
              >
                {tag}
              </span>
            ))}
          </div>
          
          <h3 className={`text-2xl font-serif mb-2.5 line-clamp-1 transition-colors ${
            isLight
              ? 'text-stone-900 group-hover:text-amber-800'
              : 'text-white group-hover:text-amber-200'
          }`}>
            {title}
          </h3>
          
          <p className={`text-xs sm:text-sm leading-relaxed mb-6 line-clamp-2 ${
            isLight ? 'text-stone-600' : 'text-white/70'
          }`}>
            {description}
          </p>
        </div>

        {/* Bottom Price & CTA Row */}
        <div className={`flex items-center justify-between pt-4 mt-auto border-t ${
          isLight ? 'border-stone-200/80' : 'border-white/10'
        }`}>
          <div>
            <span className={`text-[10px] font-bold uppercase tracking-widest block mb-0.5 ${
              isLight ? 'text-stone-500' : 'text-white/50'
            }`}>
              Starting Rate
            </span>
            <div className={`text-2xl font-serif font-bold ${
              isLight ? 'text-stone-950' : 'text-white'
            }`}>
              {price} <span className={`text-xs font-sans font-normal ${
                isLight ? 'text-stone-500' : 'text-white/60'
              }`}>/ guest</span>
            </div>
          </div>
          
          <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-300 shadow-md group-hover:scale-105 ${
            isLight
              ? 'bg-amber-500 text-stone-950 hover:bg-amber-400 shadow-amber-500/20'
              : 'bg-white text-neutral-950 hover:bg-amber-200 shadow-[0_0_20px_rgba(255,255,255,0.3)]'
          }`}>
            <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-0.5" />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

