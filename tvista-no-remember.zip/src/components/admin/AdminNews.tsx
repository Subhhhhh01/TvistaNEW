import React, { useState } from 'react';
import { 
  Newspaper, Plus, Edit2, Trash2, Search, Calendar, User, 
  Clock, Tag, Sparkles, X, Image as ImageIcon, Check 
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { NewsArticle, NEWS_CATEGORIES } from '../../data/newsData';
import ImageUploadField from './ImageUploadField';

export default function AdminNews() {
  const { newsArticles, addNewsArticle, updateNewsArticle, deleteNewsArticle } = useData();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All News');

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<NewsArticle | null>(null);

  // Form
  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NewsArticle['category']>('Travel Trends');
  const [authorName, setAuthorName] = useState('Tvista Editorial');
  const [authorRole, setAuthorRole] = useState('Senior Travel Editor');
  const [authorAvatar, setAuthorAvatar] = useState('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop');
  const [date, setDate] = useState('');
  const [readTime, setReadTime] = useState('4 min read');
  const [coverImage, setCoverImage] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [highlightsInput, setHighlightsInput] = useState('');
  const [relatedDestination, setRelatedDestination] = useState('');
  const [featured, setFeatured] = useState(false);

  // Delete
  const [deleteTarget, setDeleteTarget] = useState<NewsArticle | null>(null);

  const filtered = newsArticles.filter(a => {
    const matchesSearch = 
      a.title.toLowerCase().includes(search.toLowerCase()) ||
      a.excerpt.toLowerCase().includes(search.toLowerCase()) ||
      a.author.name.toLowerCase().includes(search.toLowerCase());
    const matchesCat = selectedCategory === 'All News' || a.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const openAdd = () => {
    setEditingItem(null);
    setTitle('');
    setSlug('');
    setExcerpt('');
    setContent('');
    setCategory('Travel Trends');
    setAuthorName('Tvista Editorial');
    setAuthorRole('Senior Travel Editor');
    setAuthorAvatar('https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop');
    setDate(new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }));
    setReadTime('4 min read');
    setCoverImage('https://images.unsplash.com/photo-1499856871958-5b9627545d1a?q=80&w=1200&auto=format&fit=crop');
    setTagsInput('Luxury, Travel, Europe');
    setHighlightsInput('New premium travel routes\nCurated luxury properties\nExclusive perks for members');
    setRelatedDestination('Paris, France');
    setFeatured(false);
    setModalOpen(true);
  };

  const openEdit = (a: NewsArticle) => {
    setEditingItem(a);
    setTitle(a.title);
    setSlug(a.slug);
    setExcerpt(a.excerpt);
    setContent(a.content);
    setCategory(a.category);
    setAuthorName(a.author.name);
    setAuthorRole(a.author.role);
    setAuthorAvatar(a.author.avatar);
    setDate(a.date);
    setReadTime(a.readTime);
    setCoverImage(a.coverImage);
    setTagsInput(a.tags.join(', '));
    setHighlightsInput(a.keyHighlights?.join('\n') || '');
    setRelatedDestination(a.relatedDestination || '');
    setFeatured(!!a.featured);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !excerpt || !coverImage) return;

    const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
    const keyHighlights = highlightsInput.split('\n').map(t => t.trim()).filter(Boolean);
    const generatedSlug = slug.trim() || title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    const payload: NewsArticle = {
      id: editingItem ? editingItem.id : `news_${Date.now()}`,
      title,
      slug: generatedSlug,
      excerpt,
      content: content || excerpt,
      category,
      author: {
        name: authorName,
        role: authorRole,
        avatar: authorAvatar
      },
      date,
      readTime,
      coverImage,
      tags,
      keyHighlights,
      relatedDestination: relatedDestination || undefined,
      featured
    };

    if (editingItem) {
      updateNewsArticle(editingItem.id, payload);
    } else {
      addNewsArticle(payload);
    }
    setModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteTarget) {
      deleteNewsArticle(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-64">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search news & stories..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder:text-white/40 focus:outline-hidden focus:border-amber-400/50"
            />
          </div>

          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs overflow-x-auto max-w-full">
            {NEWS_CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg transition-all whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Publish Article</span>
        </button>
      </div>

      {/* News Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(article => (
          <div
            key={article.id}
            className="bg-neutral-900/70 border border-white/10 hover:border-white/20 rounded-2xl overflow-hidden shadow-lg flex flex-col justify-between group transition-all"
          >
            <div>
              {/* Cover Image */}
              <div className="relative h-44 w-full overflow-hidden bg-black/40">
                <img
                  src={article.coverImage}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-bold shadow-md">
                    {article.category}
                  </span>
                </div>

                {article.featured && (
                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/70 border border-amber-400/40 text-amber-300 text-[10px] font-bold">
                    <Sparkles className="w-3 h-3" />
                    <span>Featured</span>
                  </div>
                )}

                <div className="absolute bottom-2.5 left-3 flex items-center gap-2 text-[11px] text-white/80">
                  <Clock className="w-3 h-3 text-amber-400" />
                  <span>{article.readTime}</span>
                  <span>•</span>
                  <span>{article.date}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-4 space-y-2.5">
                <h4 className="text-sm font-serif font-bold text-white leading-snug line-clamp-2">
                  {article.title}
                </h4>
                <p className="text-[11px] text-white/60 line-clamp-3 leading-relaxed">
                  {article.excerpt}
                </p>

                {/* Author Info */}
                <div className="pt-2 flex items-center gap-2">
                  <img
                    src={article.author.avatar}
                    alt={article.author.name}
                    className="w-5 h-5 rounded-full object-cover border border-white/20"
                  />
                  <div className="text-[11px] text-white/70 truncate">
                    <span className="font-semibold">{article.author.name}</span>
                    <span className="text-white/40 ml-1">({article.author.role})</span>
                  </div>
                </div>

                {/* Tags */}
                {article.tags && article.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {article.tags.slice(0, 3).map((tag, idx) => (
                      <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-white/50 border border-white/5">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="p-3 border-t border-white/5 flex items-center justify-end gap-2 bg-black/20 text-xs">
              <button
                onClick={() => openEdit(article)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium"
              >
                <Edit2 className="w-3 h-3" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget(article)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 font-medium"
              >
                <Trash2 className="w-3 h-3" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="col-span-full py-16 text-center text-white/40 bg-neutral-900/40 rounded-2xl border border-white/5">
            <Newspaper className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No articles found.</p>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-2xl w-full p-6 space-y-4 my-8 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-serif font-bold text-white">
                {editingItem ? 'Edit Article' : 'Publish New Article'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-white/60 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 font-medium mb-1">Article Headline *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Schengen Visa 2026: The New Cascade Regime"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Slug / URL Key</label>
                  <input
                    type="text"
                    value={slug}
                    onChange={e => setSlug(e.target.value)}
                    placeholder="schengen-visa-2026"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white font-mono focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  >
                    <option value="Visa Updates">Visa Updates</option>
                    <option value="Travel Trends">Travel Trends</option>
                    <option value="Destination Guides">Destination Guides</option>
                    <option value="Aviation News">Aviation News</option>
                    <option value="Press & Awards">Press & Awards</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Short Excerpt *</label>
                <textarea
                  rows={2}
                  required
                  value={excerpt}
                  onChange={e => setExcerpt(e.target.value)}
                  placeholder="Brief summary for listings..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Full Article Content</label>
                <textarea
                  rows={4}
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder="Full article paragraphs..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Author Name</label>
                  <input
                    type="text"
                    value={authorName}
                    onChange={e => setAuthorName(e.target.value)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Author Role</label>
                  <input
                    type="text"
                    value={authorRole}
                    onChange={e => setAuthorRole(e.target.value)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Read Time</label>
                  <input
                    type="text"
                    value={readTime}
                    onChange={e => setReadTime(e.target.value)}
                    placeholder="4 min read"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <ImageUploadField
                  label="News Cover Image"
                  required
                  value={coverImage}
                  onChange={setCoverImage}
                  placeholder="https://images.unsplash.com/..."
                  helperText="Header banner photo displayed for this news article."
                />

                <ImageUploadField
                  label="Author Avatar Portrait"
                  value={authorAvatar}
                  onChange={setAuthorAvatar}
                  placeholder="https://images.unsplash.com/..."
                  helperText="Square profile picture of the author."
                  compact
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Publication Date</label>
                  <input
                    type="text"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    placeholder="e.g. September 08, 2026"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Reading Time Estimate</label>
                  <input
                    type="text"
                    value={readTime}
                    onChange={e => setReadTime(e.target.value)}
                    placeholder="e.g. 5 min read"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={tagsInput}
                    onChange={e => setTagsInput(e.target.value)}
                    placeholder="Visa, Europe, Passport"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Related Destination</label>
                  <input
                    type="text"
                    value={relatedDestination}
                    onChange={e => setRelatedDestination(e.target.value)}
                    placeholder="e.g. Paris, France"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Key Highlights (One per line)</label>
                <textarea
                  rows={2}
                  value={highlightsInput}
                  onChange={e => setHighlightsInput(e.target.value)}
                  placeholder="Key highlight 1&#10;Key highlight 2"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white font-mono text-[11px] focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="news-featured"
                  checked={featured}
                  onChange={e => setFeatured(e.target.checked)}
                  className="w-4 h-4 rounded-sm border-white/20 text-amber-500"
                />
                <label htmlFor="news-featured" className="text-white/80 cursor-pointer">
                  Feature this article as the hero story on the News page
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  Save Article
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-sm w-full p-6 space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-serif font-bold text-white">Delete Article?</h3>
            <p className="text-xs text-white/70">
              Are you sure you want to delete <span className="font-bold text-amber-400">"{deleteTarget.title}"</span>?
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-xs font-bold text-white"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
