import React, { useState } from 'react';
import { 
  Plus, Edit2, Trash2, Search, MapPin, Clock, IndianRupee, 
  Image as ImageIcon, Check, X, Star, Sparkles, ExternalLink 
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { DestinationItem } from '../../data/destinationsData';
import ImageUploadField from './ImageUploadField';

export default function AdminDestinations() {
  const { destinations, addDestination, updateDestination, deleteDestination } = useData();
  const [search, setSearch] = useState('');
  
  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<DestinationItem | null>(null);
  
  // Form fields
  const [name, setName] = useState('');
  const [country, setCountry] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState('');
  const [featured, setFeatured] = useState(false);

  // Delete confirm
  const [deleteTarget, setDeleteTarget] = useState<DestinationItem | null>(null);

  const filtered = destinations.filter(d => 
    d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.country.toLowerCase().includes(search.toLowerCase()) ||
    d.description.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => {
    setEditingItem(null);
    setName('');
    setCountry('');
    setDescription('');
    setDuration('7 Days');
    setPrice('₹1,50,000');
    setImage('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop');
    setFeatured(false);
    setModalOpen(true);
  };

  const openEdit = (item: DestinationItem) => {
    setEditingItem(item);
    setName(item.name);
    setCountry(item.country);
    setDescription(item.description);
    setDuration(item.duration);
    setPrice(item.price);
    setImage(item.image);
    setFeatured(!!item.featured);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !country || !image) return;

    if (editingItem) {
      updateDestination(editingItem.id, {
        name,
        country,
        description,
        duration,
        price,
        image,
        featured
      });
    } else {
      addDestination({
        name,
        country,
        description,
        duration,
        price,
        image,
        featured
      });
    }
    setModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteTarget) {
      deleteDestination(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top action bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search destinations or countries..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder:text-white/40 focus:outline-hidden focus:border-amber-400/50"
            />
          </div>
          <span className="text-xs text-white/50 whitespace-nowrap">
            {filtered.length} of {destinations.length} destinations
          </span>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md shadow-amber-500/20 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Add Destination</span>
        </button>
      </div>

      {/* Grid of destinations */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(dest => (
          <div 
            key={dest.id}
            className="group bg-neutral-900/70 border border-white/10 hover:border-white/20 rounded-2xl overflow-hidden transition-all flex flex-col justify-between shadow-lg"
          >
            <div>
              {/* Image with badges */}
              <div className="relative h-48 w-full overflow-hidden bg-black/50">
                <img 
                  src={dest.image} 
                  alt={dest.name} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/15 text-[11px] text-white font-medium">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{dest.country}</span>
                </div>

                {dest.featured && (
                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/90 text-neutral-950 font-bold text-[10px] tracking-wider uppercase shadow-md">
                    <Sparkles className="w-3 h-3" />
                    <span>Featured</span>
                  </div>
                )}

                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/90">
                  <span className="font-serif text-lg text-white font-bold drop-shadow-md">
                    {dest.name}
                  </span>
                  <div className="flex items-center gap-1 text-amber-300 font-semibold bg-black/50 px-2 py-0.5 rounded-md backdrop-blur-xs">
                    <Clock className="w-3 h-3" />
                    <span>{dest.duration}</span>
                  </div>
                </div>
              </div>

              {/* Description & Price */}
              <div className="p-4 space-y-3">
                <p className="text-xs text-white/70 line-clamp-3 leading-relaxed">
                  {dest.description}
                </p>

                <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                  <span className="text-white/50">Starting from</span>
                  <span className="text-sm font-bold text-amber-400 flex items-center gap-0.5">
                    {dest.price}
                  </span>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="px-4 pb-4 pt-1 flex items-center justify-end gap-2 border-t border-white/5">
              <button
                onClick={() => openEdit(dest)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => setDeleteTarget(dest)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-xs font-medium text-red-300 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="col-span-full py-16 text-center text-white/40 bg-neutral-900/40 rounded-2xl border border-white/5">
            <MapPin className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No destinations found matching "{search}".</p>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-xl w-full p-6 space-y-5 my-8 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="text-lg font-serif font-bold text-white">
                {editingItem ? 'Edit Destination' : 'Add New Destination'}
              </h3>
              <button 
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white/60 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white/70 font-medium mb-1.5">Destination Name *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={e => setName(e.target.value)}
                    placeholder="e.g. Kyoto"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1.5">Country *</label>
                  <input
                    type="text"
                    required
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    placeholder="e.g. Japan"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-white/70 font-medium mb-1.5">Trip Duration</label>
                  <input
                    type="text"
                    value={duration}
                    onChange={e => setDuration(e.target.value)}
                    placeholder="e.g. 7 Days"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1.5">Starting Price</label>
                  <input
                    type="text"
                    value={price}
                    onChange={e => setPrice(e.target.value)}
                    placeholder="e.g. ₹1,98,000"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <ImageUploadField
                label="Destination Cover Image"
                required
                value={image}
                onChange={setImage}
                placeholder="https://images.unsplash.com/..."
                helperText="Upload a high-quality landscape photo or paste an image link."
              />

              <div>
                <label className="block text-white/70 font-medium mb-1.5">Description & Highlights</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Describe the magical experience and what makes this destination unique..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400 leading-relaxed"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="dest-featured"
                  checked={featured}
                  onChange={e => setFeatured(e.target.checked)}
                  className="w-4 h-4 rounded-sm border-white/20 text-amber-500 focus:ring-amber-500/50"
                />
                <label htmlFor="dest-featured" className="text-white/80 font-medium cursor-pointer">
                  Mark as Featured Destination (Promoted on showcase sections)
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  {editingItem ? 'Save Changes' : 'Create Destination'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-sm w-full p-6 space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-serif font-bold text-white">Delete Destination?</h3>
            <p className="text-xs text-white/70">
              Are you sure you want to delete <span className="font-bold text-white">"{deleteTarget.name}"</span>? This action cannot be undone.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-xs font-bold text-white"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
