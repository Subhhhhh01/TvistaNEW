import React, { useState } from 'react';
import { 
  Sparkles, Layers, Image as ImageIcon, Plus, Edit2, Trash2, 
  Save, Check, MapPin, Calendar, Clock, Star, ExternalLink, X, MessageSquare 
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { HomeHeroSlide, HomeFeaturedEscape, TestimonialItem, HomeSettings } from '../../data/homeData';
import ImageUploadField from './ImageUploadField';

export default function AdminHome() {
  const { 
    homeHeroCards, addHomeHeroCard, updateHomeHeroCard, deleteHomeHeroCard,
    homeFeaturedEscapes, addHomeFeaturedEscape, updateHomeFeaturedEscape, deleteHomeFeaturedEscape,
    testimonials, addTestimonial, updateTestimonial, deleteTestimonial,
    homeSettings, updateHomeSettings
  } = useData();

  const [activeSection, setActiveSection] = useState<'settings' | 'heroSlides' | 'featured' | 'testimonials'>('settings');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<HomeSettings>({ ...homeSettings });

  // Hero Slide Modal
  const [slideModalOpen, setSlideModalOpen] = useState(false);
  const [editingSlide, setEditingSlide] = useState<HomeHeroSlide | null>(null);
  const [slideTitle, setSlideTitle] = useState('');
  const [slideLocation, setSlideLocation] = useState('');
  const [slideImage, setSlideImage] = useState('');

  // Featured Escape Modal
  const [escapeModalOpen, setEscapeModalOpen] = useState(false);
  const [editingEscape, setEditingEscape] = useState<HomeFeaturedEscape | null>(null);
  const [escapeTitle, setEscapeTitle] = useState('');
  const [escapeDesc, setEscapeDesc] = useState('');
  const [escapeImage, setEscapeImage] = useState('');
  const [escapeBgImage, setEscapeBgImage] = useState('');
  const [escapeSeason, setEscapeSeason] = useState('');
  const [escapeDuration, setEscapeDuration] = useState('');
  const [escapePrice, setEscapePrice] = useState('');
  const [escapeRating, setEscapeRating] = useState('');

  // Testimonial Modal
  const [testimonialModalOpen, setTestimonialModalOpen] = useState(false);
  const [editingTestimonial, setEditingTestimonial] = useState<TestimonialItem | null>(null);
  const [testName, setTestName] = useState('');
  const [testRole, setTestRole] = useState('');
  const [testLocation, setTestLocation] = useState('');
  const [testQuote, setTestQuote] = useState('');
  const [testAvatar, setTestAvatar] = useState('');
  const [testRating, setTestRating] = useState('');

  // Delete target
  const [deleteTarget, setDeleteTarget] = useState<{ type: 'slide' | 'escape' | 'testimonial'; id: string | number; name: string } | null>(null);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateHomeSettings(settingsForm);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const openAddSlide = () => {
    setEditingSlide(null);
    setSlideTitle('');
    setSlideLocation('');
    setSlideImage('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop');
    setSlideModalOpen(true);
  };

  const openEditSlide = (slide: HomeHeroSlide) => {
    setEditingSlide(slide);
    setSlideTitle(slide.title);
    setSlideLocation(slide.location);
    setSlideImage(slide.image);
    setSlideModalOpen(true);
  };

  const handleSaveSlide = (e: React.FormEvent) => {
    e.preventDefault();
    if (!slideTitle || !slideLocation || !slideImage) return;

    if (editingSlide) {
      updateHomeHeroCard(editingSlide.id, {
        title: slideTitle,
        location: slideLocation,
        image: slideImage
      });
    } else {
      addHomeHeroCard({
        title: slideTitle,
        location: slideLocation,
        image: slideImage
      });
    }
    setSlideModalOpen(false);
  };

  const openAddEscape = () => {
    setEditingEscape(null);
    setEscapeTitle('');
    setEscapeDesc('');
    setEscapeImage('https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=1200&auto=format&fit=crop');
    setEscapeBgImage('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1200&auto=format&fit=crop');
    setEscapeSeason('May - September');
    setEscapeDuration('7 - 10 Days');
    setEscapePrice('₹2,20,000');
    setEscapeRating('4.9/5 (100+ Reviews)');
    setEscapeModalOpen(true);
  };

  const openEditEscape = (escape: HomeFeaturedEscape) => {
    setEditingEscape(escape);
    setEscapeTitle(escape.title);
    setEscapeDesc(escape.description);
    setEscapeImage(escape.image);
    setEscapeBgImage(escape.bgImage);
    setEscapeSeason(escape.season);
    setEscapeDuration(escape.duration);
    setEscapePrice(escape.price);
    setEscapeRating(escape.rating);
    setEscapeModalOpen(true);
  };

  const handleSaveEscape = (e: React.FormEvent) => {
    e.preventDefault();
    if (!escapeTitle || !escapeImage) return;

    if (editingEscape) {
      updateHomeFeaturedEscape(editingEscape.id, {
        title: escapeTitle,
        description: escapeDesc,
        image: escapeImage,
        bgImage: escapeBgImage,
        season: escapeSeason,
        duration: escapeDuration,
        price: escapePrice,
        rating: escapeRating
      });
    } else {
      addHomeFeaturedEscape({
        id: `escape-${Date.now()}`,
        title: escapeTitle,
        description: escapeDesc,
        image: escapeImage,
        bgImage: escapeBgImage,
        season: escapeSeason,
        duration: escapeDuration,
        price: escapePrice,
        rating: escapeRating
      });
    }
    setEscapeModalOpen(false);
  };

  // Testimonial handlers
  const openAddTestimonial = () => {
    setEditingTestimonial(null);
    setTestName('');
    setTestRole('Verified Traveler');
    setTestLocation('Delhi, India');
    setTestQuote('');
    setTestAvatar('https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop');
    setTestRating('5.0');
    setTestimonialModalOpen(true);
  };

  const openEditTestimonial = (item: TestimonialItem) => {
    setEditingTestimonial(item);
    setTestName(item.name);
    setTestRole(item.role);
    setTestLocation(item.location);
    setTestQuote(item.quote);
    setTestAvatar(item.avatar);
    setTestRating(item.rating);
    setTestimonialModalOpen(true);
  };

  const handleSaveTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testName || !testQuote) return;

    if (editingTestimonial) {
      updateTestimonial(editingTestimonial.id, {
        name: testName,
        role: testRole,
        location: testLocation,
        quote: testQuote,
        avatar: testAvatar,
        rating: testRating
      });
    } else {
      addTestimonial({
        id: `t_${Date.now()}`,
        name: testName,
        role: testRole,
        location: testLocation,
        quote: testQuote,
        avatar: testAvatar,
        rating: testRating
      });
    }
    setTestimonialModalOpen(false);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    if (deleteTarget.type === 'slide') {
      deleteHomeHeroCard(deleteTarget.id);
    } else if (deleteTarget.type === 'escape') {
      deleteHomeFeaturedEscape(String(deleteTarget.id));
    } else if (deleteTarget.type === 'testimonial') {
      deleteTestimonial(String(deleteTarget.id));
    }
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-6">
      {/* Sub-nav switcher */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-neutral-900/70 border border-white/10 rounded-2xl backdrop-blur-md">
        <button
          onClick={() => setActiveSection('settings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeSection === 'settings'
              ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
              : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Home Banner & Headlines</span>
        </button>

        <button
          onClick={() => setActiveSection('heroSlides')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeSection === 'heroSlides'
              ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
              : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Hero Carousel Cards ({homeHeroCards.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('featured')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeSection === 'featured'
              ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
              : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          <span>Featured Escapes ({homeFeaturedEscapes.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('testimonials')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeSection === 'testimonials'
              ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
              : 'text-white/70 hover:text-white hover:bg-white/5'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>Testimonials ({testimonials.length})</span>
        </button>
      </div>

      {/* 1. Home Settings Section */}
      {activeSection === 'settings' && (
        <div className="bg-neutral-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-md space-y-6 shadow-xl">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-base font-serif font-bold text-white">Homepage Content & Copy</h3>
              <p className="text-xs text-white/50">Edit primary marketing taglines and search labels.</p>
            </div>
            {savedSuccess && (
              <span className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                <Check className="w-3.5 h-3.5" /> Saved successfully!
              </span>
            )}
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-white/70 font-medium mb-1.5">Top Eyebrow Badge</label>
                <input
                  type="text"
                  value={settingsForm.badgeText}
                  onChange={e => setSettingsForm(prev => ({ ...prev, badgeText: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1.5">Hero Search Bar Placeholder</label>
                <input
                  type="text"
                  value={settingsForm.searchPlaceholder}
                  onChange={e => setSettingsForm(prev => ({ ...prev, searchPlaceholder: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-white/70 font-medium mb-1.5">Main Hero Headline</label>
              <input
                type="text"
                value={settingsForm.mainHeadline}
                onChange={e => setSettingsForm(prev => ({ ...prev, mainHeadline: e.target.value }))}
                className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white font-medium focus:outline-hidden focus:border-amber-400"
              />
            </div>

            <div>
              <label className="block text-white/70 font-medium mb-1.5">Hero Subtitle</label>
              <textarea
                rows={2}
                value={settingsForm.mainSubheadline}
                onChange={e => setSettingsForm(prev => ({ ...prev, mainSubheadline: e.target.value }))}
                className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400 leading-relaxed"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-white/10">
              <div>
                <label className="block text-white/70 font-medium mb-1.5">Featured Escapes Section Heading</label>
                <input
                  type="text"
                  value={settingsForm.featuredHeading}
                  onChange={e => setSettingsForm(prev => ({ ...prev, featuredHeading: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>
              <div>
                <label className="block text-white/70 font-medium mb-1.5">Featured Escapes Section Subtitle</label>
                <input
                  type="text"
                  value={settingsForm.featuredSubtitle}
                  onChange={e => setSettingsForm(prev => ({ ...prev, featuredSubtitle: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>
            </div>

            <div className="flex justify-end pt-3">
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>Save Homepage Content</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 2. Hero Slides Section */}
      {activeSection === 'heroSlides' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
            <div>
              <h3 className="text-sm font-serif font-bold text-white">Hero Interactive Slider Cards</h3>
              <p className="text-xs text-white/50">Card stack rendered in the 3D rotating hero header.</p>
            </div>
            <button
              onClick={openAddSlide}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Slide</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {homeHeroCards.map((slide, idx) => (
              <div 
                key={slide.id}
                className="bg-neutral-900/70 border border-white/10 rounded-2xl overflow-hidden group shadow-md flex flex-col justify-between"
              >
                <div className="relative h-44 w-full overflow-hidden bg-black/50">
                  <img 
                    src={slide.image} 
                    alt={slide.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] font-bold text-white/80">
                    Slide #{idx + 1}
                  </span>

                  <div className="absolute bottom-2.5 left-3 right-3">
                    <div className="flex items-center gap-1 text-[11px] text-amber-300 font-medium">
                      <MapPin className="w-3 h-3" />
                      <span>{slide.location}</span>
                    </div>
                    <h4 className="text-base font-serif font-bold text-white drop-shadow-md">
                      {slide.title}
                    </h4>
                  </div>
                </div>

                <div className="p-3 flex items-center justify-end gap-2 border-t border-white/5">
                  <button
                    onClick={() => openEditSlide(slide)}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs"
                    title="Edit Slide"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteTarget({ type: 'slide', id: slide.id, name: slide.title })}
                    className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs"
                    title="Delete Slide"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Featured Escapes Section */}
      {activeSection === 'featured' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
            <div>
              <h3 className="text-sm font-serif font-bold text-white">Featured Escapes Experience</h3>
              <p className="text-xs text-white/50">Full-screen scroll transitions showcasing signature luxury destinations.</p>
            </div>
            <button
              onClick={openAddEscape}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Featured Escape</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {homeFeaturedEscapes.map(escape => (
              <div 
                key={escape.id}
                className="bg-neutral-900/70 border border-white/10 rounded-2xl overflow-hidden group shadow-lg flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-48 w-full overflow-hidden bg-black/50">
                    <img 
                      src={escape.image} 
                      alt={escape.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                    
                    <div className="absolute top-3 left-3 flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md border border-white/15 text-[10px] text-amber-300 font-semibold">
                        {escape.season}
                      </span>
                    </div>

                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                      <h4 className="text-lg font-serif font-bold text-white">
                        {escape.title}
                      </h4>
                      <span className="text-xs font-bold text-amber-400 bg-black/60 px-2 py-1 rounded-md">
                        {escape.price}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 space-y-2 text-xs">
                    <p className="text-white/70 line-clamp-2 leading-relaxed">
                      {escape.description}
                    </p>
                    <div className="flex items-center justify-between text-[11px] text-white/50 pt-2 border-t border-white/5">
                      <span>Duration: <strong className="text-white">{escape.duration}</strong></span>
                      <span>Rating: <strong className="text-amber-300">{escape.rating}</strong></span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 flex items-center justify-end gap-2 border-t border-white/5 bg-black/20">
                  <button
                    onClick={() => openEditEscape(escape)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-xs text-white"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => setDeleteTarget({ type: 'escape', id: escape.id, name: escape.title })}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-xs text-red-300"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. Testimonials Section */}
      {activeSection === 'testimonials' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
            <div>
              <h3 className="text-sm font-serif font-bold text-white">Guest Testimonials & Traveler Reviews</h3>
              <p className="text-xs text-white/50">Manage Indian and International guest reviews displayed on the homepage slider.</p>
            </div>
            <button
              onClick={openAddTestimonial}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Testimonial</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {testimonials.map((item, idx) => (
              <div 
                key={item.id}
                className="bg-neutral-900/70 border border-white/10 rounded-2xl overflow-hidden group shadow-md flex flex-col justify-between p-4 space-y-3"
              >
                <div className="flex items-center gap-3">
                  <img 
                    src={item.avatar} 
                    alt={item.name} 
                    className="w-12 h-12 rounded-full object-cover border-2 border-white/20 shrink-0" 
                  />
                  <div className="overflow-hidden">
                    <h4 className="text-sm font-serif font-bold text-white truncate">{item.name}</h4>
                    <p className="text-xs text-cyan-400 truncate">{item.location}</p>
                    <span className="text-[10px] text-white/50">{item.role}</span>
                  </div>
                </div>

                <p className="text-xs text-white/70 italic line-clamp-3 leading-relaxed">
                  "{item.quote}"
                </p>

                <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-400 text-xs">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span className="font-mono text-white font-bold">{item.rating}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => openEditTestimonial(item)}
                      className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs"
                      title="Edit Testimonial"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteTarget({ type: 'testimonial', id: item.id, name: item.name })}
                      className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 text-xs"
                      title="Delete Testimonial"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Slide Modal */}
      {slideModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-serif font-bold text-white">
                {editingSlide ? 'Edit Hero Slide' : 'Add Hero Slide'}
              </h3>
              <button onClick={() => setSlideModalOpen(false)} className="text-white/60 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSlide} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 font-medium mb-1">Slide Title *</label>
                <input
                  type="text"
                  required
                  value={slideTitle}
                  onChange={e => setSlideTitle(e.target.value)}
                  placeholder="e.g. Tropical Beaches"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Location Tag *</label>
                <input
                  type="text"
                  required
                  value={slideLocation}
                  onChange={e => setSlideLocation(e.target.value)}
                  placeholder="e.g. Maldives"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <ImageUploadField
                label="Slide Card Image"
                required
                value={slideImage}
                onChange={setSlideImage}
                placeholder="https://images.unsplash.com/..."
                helperText="Upload a vibrant landscape photo or paste an image URL."
              />

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setSlideModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  Save Slide
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Featured Escape Modal */}
      {escapeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-lg w-full p-6 space-y-4 my-8 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-serif font-bold text-white">
                {editingEscape ? 'Edit Featured Escape' : 'Add Featured Escape'}
              </h3>
              <button onClick={() => setEscapeModalOpen(false)} className="text-white/60 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEscape} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Title & Location *</label>
                  <input
                    type="text"
                    required
                    value={escapeTitle}
                    onChange={e => setEscapeTitle(e.target.value)}
                    placeholder="e.g. Ubud, Bali"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Season</label>
                  <input
                    type="text"
                    value={escapeSeason}
                    onChange={e => setEscapeSeason(e.target.value)}
                    placeholder="e.g. May - September"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Duration</label>
                  <input
                    type="text"
                    value={escapeDuration}
                    onChange={e => setEscapeDuration(e.target.value)}
                    placeholder="e.g. 7 - 10 Days"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Price</label>
                  <input
                    type="text"
                    value={escapePrice}
                    onChange={e => setEscapePrice(e.target.value)}
                    placeholder="e.g. ₹2,20,000"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Rating</label>
                  <input
                    type="text"
                    value={escapeRating}
                    onChange={e => setEscapeRating(e.target.value)}
                    placeholder="e.g. 4.9/5"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <ImageUploadField
                label="Card Image"
                required
                value={escapeImage}
                onChange={setEscapeImage}
                placeholder="https://images.unsplash.com/..."
                helperText="Main showcase photo for this featured retreat."
              />

              <ImageUploadField
                label="Ambient Background Image (Optional)"
                value={escapeBgImage}
                onChange={setEscapeBgImage}
                placeholder="https://images.unsplash.com/..."
                helperText="Backdrop banner photo displayed when this card is highlighted."
              />

              <div>
                <label className="block text-white/70 font-medium mb-1">Description</label>
                <textarea
                  rows={3}
                  value={escapeDesc}
                  onChange={e => setEscapeDesc(e.target.value)}
                  placeholder="Immerse yourself in..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setEscapeModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  Save Escape
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Testimonial Modal */}
      {testimonialModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-md w-full p-6 space-y-4 my-8 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-serif font-bold text-white">
                {editingTestimonial ? 'Edit Testimonial' : 'Add Testimonial'}
              </h3>
              <button onClick={() => setTestimonialModalOpen(false)} className="text-white/60 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTestimonial} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-white/70 font-medium mb-1">Traveler / Guest Name *</label>
                <input
                  type="text"
                  required
                  value={testName}
                  onChange={e => setTestName(e.target.value)}
                  placeholder="e.g. Rohan & Priya Sharma"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Location / City *</label>
                  <input
                    type="text"
                    required
                    value={testLocation}
                    onChange={e => setTestLocation(e.target.value)}
                    placeholder="e.g. Delhi, India or London, UK"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Tag / Role</label>
                  <input
                    type="text"
                    value={testRole}
                    onChange={e => setTestRole(e.target.value)}
                    placeholder="e.g. Honeymooners, Luxury Traveler"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Rating</label>
                <input
                  type="text"
                  value={testRating}
                  onChange={e => setTestRating(e.target.value)}
                  placeholder="e.g. 5.0"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <ImageUploadField
                label="Avatar / Profile Photo"
                required
                value={testAvatar}
                onChange={setTestAvatar}
                placeholder="https://images.unsplash.com/..."
                helperText="Upload a clear square portrait of the traveler."
              />

              <div>
                <label className="block text-white/70 font-medium mb-1">Testimonial Quote *</label>
                <textarea
                  rows={4}
                  required
                  value={testQuote}
                  onChange={e => setTestQuote(e.target.value)}
                  placeholder="Tvista Holidays curated a dream vacation..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400 leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setTestimonialModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  Save Testimonial
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-sm w-full p-6 space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-serif font-bold text-white">Delete Item?</h3>
            <p className="text-xs text-white/70">
              Are you sure you want to delete <span className="font-bold text-white">"{deleteTarget.name}"</span>?
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-xs font-bold text-white"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
