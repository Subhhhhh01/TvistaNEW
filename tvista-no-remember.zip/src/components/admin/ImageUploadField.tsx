import React, { useState, useRef } from 'react';
import { Upload, Link as LinkIcon, Image as ImageIcon, X, AlertCircle, Check, Sparkles } from 'lucide-react';

export interface ImageUploadFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  theme?: 'dark' | 'light';
  required?: boolean;
  placeholder?: string;
  helperText?: string;
  previewHeight?: string;
  compact?: boolean;
}

// Client-side image optimization to prevent localStorage quota issues
function resizeImageFile(file: File, maxWidth = 1400, maxHeight = 1400, quality = 0.85): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.type === 'image/svg+xml' || file.type === 'image/gif') {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Failed to load image for processing'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

export default function ImageUploadField({
  label,
  value,
  onChange,
  theme = 'dark',
  required = false,
  placeholder = 'https://images.unsplash.com/...',
  helperText,
  previewHeight = 'h-32',
  compact = false
}: ImageUploadFieldProps) {
  const isDark = theme === 'dark';
  const [mode, setMode] = useState<'upload' | 'url'>('upload');
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProcessFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file (JPG, PNG, WebP, SVG, GIF)');
      return;
    }
    setError(null);
    setIsProcessing(true);
    try {
      const optimizedDataUrl = await resizeImageFile(file);
      onChange(optimizedDataUrl);
      setFileName(file.name);
    } catch {
      setError('Could not process this image. Please try another file or use a URL.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleProcessFile(file);
    }
  };

  const handleClear = () => {
    onChange('');
    setFileName(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-2">
      {/* Label and Mode Switcher */}
      <div className="flex items-center justify-between gap-2">
        <label className={`block font-medium text-xs ${isDark ? 'text-white/80' : 'text-stone-700'}`}>
          {label} {required && <span className="text-amber-500">*</span>}
        </label>

        <div className={`flex items-center gap-1 p-0.5 rounded-lg text-[11px] font-medium ${isDark ? 'bg-black/40 border border-white/10' : 'bg-stone-100 border border-stone-200'}`}>
          <button
            type="button"
            onClick={() => setMode('upload')}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md transition-all ${
              mode === 'upload'
                ? isDark ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'bg-white text-stone-900 font-bold shadow-xs'
                : isDark ? 'text-white/60 hover:text-white' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <Upload className="w-3 h-3" />
            <span>Upload File</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('url')}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-md transition-all ${
              mode === 'url'
                ? isDark ? 'bg-amber-500 text-stone-950 font-bold shadow-xs' : 'bg-white text-stone-900 font-bold shadow-xs'
                : isDark ? 'text-white/60 hover:text-white' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <LinkIcon className="w-3 h-3" />
            <span>Paste URL</span>
          </button>
        </div>
      </div>

      {/* Hidden Native File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileInput}
        accept="image/*"
        className="hidden"
      />

      {/* Content depending on mode */}
      {mode === 'upload' ? (
        <div>
          {/* Drag & Drop Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl ${compact ? 'p-3.5' : 'p-4'} text-center cursor-pointer transition-all duration-200 flex flex-col items-center justify-center gap-1.5 ${
              isDragging
                ? isDark 
                  ? 'border-amber-400 bg-amber-500/10 scale-[0.99]' 
                  : 'border-amber-500 bg-amber-50 scale-[0.99]'
                : isDark
                  ? 'border-white/15 hover:border-white/30 bg-black/30 hover:bg-black/50'
                  : 'border-stone-300 hover:border-stone-400 bg-stone-50/70 hover:bg-white'
            }`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              isDark ? 'bg-white/10 text-amber-400' : 'bg-amber-100 text-amber-700'
            }`}>
              <Upload className="w-4 h-4" />
            </div>

            <div>
              <p className={`text-xs font-semibold ${isDark ? 'text-white' : 'text-stone-800'}`}>
                {isProcessing
                  ? 'Processing image...'
                  : isDragging
                    ? 'Release to upload image'
                    : 'Click to browse or drag & drop image'}
              </p>
              <p className={`text-[10px] mt-0.5 ${isDark ? 'text-white/40' : 'text-stone-500'}`}>
                Supports JPG, PNG, WEBP, SVG, GIF (auto-optimized)
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className="relative">
            <input
              type="url"
              value={value}
              onChange={e => {
                onChange(e.target.value);
                setFileName(null);
                setError(null);
              }}
              placeholder={placeholder}
              className={`w-full px-3 py-2 rounded-xl text-xs focus:outline-hidden transition-colors ${
                isDark
                  ? 'bg-black/40 border border-white/15 text-white placeholder:text-white/30 focus:border-amber-400'
                  : 'bg-stone-50 border border-stone-200 text-stone-900 placeholder:text-stone-400 focus:bg-white focus:border-stone-400'
              }`}
            />
            {value && (
              <button
                type="button"
                onClick={handleClear}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <p className="text-[11px] text-rose-500 font-medium flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" />
          <span>{error}</span>
        </p>
      )}

      {/* Helper text if provided */}
      {helperText && !error && (
        <p className={`text-[10px] ${isDark ? 'text-white/40' : 'text-stone-400'}`}>
          {helperText}
        </p>
      )}

      {/* Preview Card */}
      {value && (
        <div className={`mt-2 p-2 rounded-xl border flex items-center gap-3 ${
          isDark ? 'bg-black/50 border-white/10' : 'bg-stone-100/70 border-stone-200'
        }`}>
          <div className={`w-16 ${compact ? 'h-12' : 'h-14'} rounded-lg overflow-hidden shrink-0 border relative ${
            isDark ? 'bg-neutral-800 border-white/10' : 'bg-stone-200 border-stone-300'
          }`}>
            <img
              src={value}
              alt="Preview"
              className="w-full h-full object-cover"
              onError={() => setError('Unable to load image preview from this URL or data.')}
              onLoad={() => setError(null)}
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
              <Check className="w-3 h-3" />
              <span>{fileName ? 'Image Uploaded' : 'Image Ready'}</span>
            </div>
            <p className={`text-[10px] truncate ${isDark ? 'text-white/60' : 'text-stone-500'}`}>
              {fileName || (value.startsWith('data:') ? 'Local file uploaded' : value)}
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className={`px-2 py-1 rounded-md text-[10px] font-medium transition-colors ${
                isDark ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200'
              }`}
            >
              Replace
            </button>
            <button
              type="button"
              onClick={handleClear}
              className={`p-1 rounded-md transition-colors ${
                isDark ? 'text-rose-400 hover:bg-rose-500/20' : 'text-rose-600 hover:bg-rose-50'
              }`}
              title="Remove image"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
