import React, { useState } from 'react';
import { 
  Tag, Plus, Edit2, Trash2, Search, Calendar, Check, Copy, 
  Percent, ShieldCheck, Clock, Sparkles, X, MapPin, IndianRupee 
} from 'lucide-react';
import { useData } from '../../context/DataContext';
import { PromoOffer, PROMO_CATEGORIES } from '../../data/promosData';
import ImageUploadField from './ImageUploadField';

export default function AdminPromos() {
  const { promos, addPromo, updatePromo, deletePromo } = useData();
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('All Offers');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<PromoOffer | null>(null);

  // Form fields
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [code, setCode] = useState('');
  const [discountBadge, setDiscountBadge] = useState('25% OFF');
  const [category, setCategory] = useState<PromoOffer['category']>('Luxury Beach');
  const [destination, setDestination] = useState('');
  const [country, setCountry] = useState('');
  const [image, setImage] = useState('');
  const [originalPrice, setOriginalPrice] = useState('₹2,50,000');
  const [promoPrice, setPromoPrice] = useState('₹1,90,000');
  const [savings, setSavings] = useState('Save ₹60,000');
  const [validUntil, setValidUntil] = useState('October 31, 2026');
  const [daysRemaining, setDaysRemaining] = useState(45);
  const [overview, setOverview] = useState('');
  const [inclusionsText, setInclusionsText] = useState('Private Pool Villa\nDaily Buffet Breakfast & Dinner\nSpeedboat Transfers');
  const [termsText, setTermsText] = useState('Valid for stays between specified dates.\nSubject to villa availability at time of booking.');
  const [featured, setFeatured] = useState(false);

  // Delete confirm
  const [deleteTarget, setDeleteTarget] = useState<PromoOffer | null>(null);

  const filtered = promos.filter(p => {
    const matchesSearch = 
      p.code.toLowerCase().includes(search.toLowerCase()) ||
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.destination.toLowerCase().includes(search.toLowerCase()) ||
      p.overview.toLowerCase().includes(search.toLowerCase());
    const matchesCat = filterCategory === 'All Offers' || p.category === filterCategory;
    return matchesSearch && matchesCat;
  });

  const handleCopy = (promoCode: string) => {
    navigator.clipboard.writeText(promoCode);
    setCopiedCode(promoCode);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const openAdd = () => {
    setEditingItem(null);
    setTitle('Swiss Alpine Panorama Summer Escape');
    setSubtitle('5-Star Mountain Resort with Unlimited First-Class Panoramic Train Passes');
    setCode('SWISS25');
    setDiscountBadge('25% OFF');
    setCategory('Alpine & Winter');
    setDestination('Zermatt & Lucerne');
    setCountry('Switzerland');
    setImage('https://images.unsplash.com/photo-1527668752968-14dc70a27c95?q=80&w=1200&auto=format&fit=crop');
    setOriginalPrice('₹3,20,000');
    setPromoPrice('₹2,40,000');
    setSavings('Save ₹80,000');
    setValidUntil('November 15, 2026');
    setDaysRemaining(60);
    setOverview('Experience the pinnacle of European mountain luxury with Matterhorn views.');
    setInclusionsText('5 Nights at The Omnia Zermatt\nSwiss Travel Pass 1st Class\nDaily Gourmet Breakfast');
    setTermsText('Non-refundable once flight tickets are issued.\nValid on selected summer and autumn departures.');
    setFeatured(true);
    setModalOpen(true);
  };

  const openEdit = (p: PromoOffer) => {
    setEditingItem(p);
    setTitle(p.title);
    setSubtitle(p.subtitle);
    setCode(p.code);
    setDiscountBadge(p.discountBadge);
    setCategory(p.category);
    setDestination(p.destination);
    setCountry(p.country);
    setImage(p.image);
    setOriginalPrice(p.originalPrice);
    setPromoPrice(p.promoPrice);
    setSavings(p.savings);
    setValidUntil(p.validUntil);
    setDaysRemaining(p.daysRemaining);
    setOverview(p.overview);
    setInclusionsText(p.inclusions?.join('\n') || '');
    setTermsText(p.terms?.join('\n') || '');
    setFeatured(!!p.featured);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !title || !promoPrice) return;

    const inclusions = inclusionsText.split('\n').map(t => t.trim()).filter(Boolean);
    const terms = termsText.split('\n').map(t => t.trim()).filter(Boolean);

    const payload: PromoOffer = {
      id: editingItem ? editingItem.id : `promo_${Date.now()}`,
      title,
      subtitle,
      code: code.toUpperCase().trim(),
      discountBadge,
      category,
      destination,
      country,
      image,
      originalPrice,
      promoPrice,
      savings,
      validUntil,
      daysRemaining: Number(daysRemaining) || 30,
      featured,
      inclusions,
      terms,
      overview
    };

    if (editingItem) {
      updatePromo(editingItem.id, payload);
    } else {
      addPromo(payload);
    }
    setModalOpen(false);
  };

  const confirmDelete = () => {
    if (deleteTarget) {
      deletePromo(deleteTarget.id);
      setDeleteTarget(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search and Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-64">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
            <input
              type="text"
              placeholder="Search coupon or destination..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder:text-white/40 focus:outline-hidden focus:border-amber-400/50"
            />
          </div>

          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10 text-xs overflow-x-auto max-w-full">
            {PROMO_CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1 rounded-lg transition-all whitespace-nowrap ${
                  filterCategory === cat
                    ? 'bg-amber-500 text-stone-950 font-bold'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={openAdd}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Promo Offer</span>
        </button>
      </div>

      {/* Promos Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(promo => (
          <div
            key={promo.id}
            className="bg-neutral-900/70 border border-white/10 hover:border-white/20 rounded-2xl overflow-hidden shadow-lg flex flex-col justify-between group transition-all"
          >
            <div>
              {/* Image banner */}
              <div className="relative h-44 w-full overflow-hidden bg-black/50">
                <img
                  src={promo.image}
                  alt={promo.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-bold shadow-md">
                    {promo.discountBadge}
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-black/60 text-[10px] text-white/80">
                    {promo.category}
                  </span>
                </div>

                {promo.featured && (
                  <div className="absolute top-3 right-3 flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/70 border border-amber-400/40 text-amber-300 text-[10px] font-bold">
                    <Sparkles className="w-3 h-3" />
                    <span>Featured</span>
                  </div>
                )}

                <div className="absolute bottom-2.5 left-3 flex items-center gap-1 text-[11px] text-white/80">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>{promo.destination}, {promo.country}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div
                    onClick={() => handleCopy(promo.code)}
                    className="cursor-pointer group/code flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono text-xs font-bold"
                  >
                    <span>{promo.code}</span>
                    {copiedCode === promo.code ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3 opacity-60 group-hover/code:opacity-100" />
                    )}
                  </div>

                  <span className="text-[11px] text-white/50 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {promo.daysRemaining} days left
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-serif font-bold text-white leading-snug line-clamp-1">
                    {promo.title}
                  </h4>
                  <p className="text-[11px] text-white/60 line-clamp-2 mt-0.5">
                    {promo.subtitle}
                  </p>
                </div>

                {/* Price block */}
                <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-white/40 line-through mr-1.5">{promo.originalPrice}</span>
                    <span className="text-sm font-bold text-emerald-400">{promo.promoPrice}</span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 font-semibold">
                    {promo.savings}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-3 border-t border-white/5 flex items-center justify-between bg-black/20 text-xs">
              <span className="text-[11px] text-white/40 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Valid till {promo.validUntil}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => openEdit(promo)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium"
                >
                  <Edit2 className="w-3 h-3" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => setDeleteTarget(promo)}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 font-medium"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="col-span-full py-16 text-center text-white/40 bg-neutral-900/40 rounded-2xl border border-white/5">
            <Tag className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No promotional offers found.</p>
          </div>
        )}
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-2xl w-full p-6 space-y-4 my-8 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-serif font-bold text-white">
                {editingItem ? 'Edit Promo Offer' : 'Create New Promo Offer'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-white/60 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Coupon Code *</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={e => setCode(e.target.value.toUpperCase())}
                    placeholder="e.g. BALI30"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white font-mono uppercase focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Discount Badge *</label>
                  <input
                    type="text"
                    required
                    value={discountBadge}
                    onChange={e => setDiscountBadge(e.target.value)}
                    placeholder="e.g. 25% OFF"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  >
                    <option value="Early Bird">Early Bird</option>
                    <option value="Luxury Beach">Luxury Beach</option>
                    <option value="Honeymoon">Honeymoon</option>
                    <option value="Alpine & Winter">Alpine & Winter</option>
                    <option value="Cultural Heritage">Cultural Heritage</option>
                    <option value="Family Specials">Family Specials</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Offer Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Maldives Overwater Lagoon Retreat"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Subtitle / Highlights</label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={e => setSubtitle(e.target.value)}
                  placeholder="e.g. Luxury Private Pool Villa with Complimentary Return Seaplane Transfers"
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Destination</label>
                  <input
                    type="text"
                    value={destination}
                    onChange={e => setDestination(e.target.value)}
                    placeholder="e.g. North Malé Atoll"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Country</label>
                  <input
                    type="text"
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    placeholder="e.g. Maldives"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <ImageUploadField
                label="Offer Cover Image"
                required
                value={image}
                onChange={setImage}
                placeholder="https://images.unsplash.com/..."
                helperText="Upload a scenic promotional cover or paste an image link."
              />

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Original Price</label>
                  <input
                    type="text"
                    value={originalPrice}
                    onChange={e => setOriginalPrice(e.target.value)}
                    placeholder="₹2,60,000"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Promo Price *</label>
                  <input
                    type="text"
                    required
                    value={promoPrice}
                    onChange={e => setPromoPrice(e.target.value)}
                    placeholder="₹1,95,000"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Savings Text</label>
                  <input
                    type="text"
                    value={savings}
                    onChange={e => setSavings(e.target.value)}
                    placeholder="Save ₹65,000"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Valid Until</label>
                  <input
                    type="text"
                    value={validUntil}
                    onChange={e => setValidUntil(e.target.value)}
                    placeholder="e.g. October 31, 2026"
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Days Remaining</label>
                  <input
                    type="number"
                    value={daysRemaining}
                    onChange={e => setDaysRemaining(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/70 font-medium mb-1">Overview Description</label>
                <textarea
                  rows={2}
                  value={overview}
                  onChange={e => setOverview(e.target.value)}
                  placeholder="Offer summary..."
                  className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white focus:outline-hidden focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-white/70 font-medium mb-1">Inclusions (One per line)</label>
                  <textarea
                    rows={3}
                    value={inclusionsText}
                    onChange={e => setInclusionsText(e.target.value)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white font-mono text-[11px] focus:outline-hidden focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-white/70 font-medium mb-1">Terms (One per line)</label>
                  <textarea
                    rows={3}
                    value={termsText}
                    onChange={e => setTermsText(e.target.value)}
                    className="w-full px-3 py-2 bg-black/40 border border-white/15 rounded-xl text-white font-mono text-[11px] focus:outline-hidden focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="promo-featured"
                  checked={featured}
                  onChange={e => setFeatured(e.target.checked)}
                  className="w-4 h-4 rounded-sm border-white/20 text-amber-500"
                />
                <label htmlFor="promo-featured" className="text-white/80 cursor-pointer">
                  Feature this promotion in spotlight banners
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold"
                >
                  Save Promo Offer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-neutral-900 border border-white/15 rounded-2xl max-w-sm w-full p-6 space-y-4 text-center shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-serif font-bold text-white">Delete Promo Offer?</h3>
            <p className="text-xs text-white/70">
              Are you sure you want to delete promo code <span className="font-bold text-amber-400">"{deleteTarget.code}"</span> ({deleteTarget.title})?
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteTarget(null)}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-xs font-bold text-white"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
