import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, MapPin, Clock, Star, MessageCircle, Compass, 
  Hotel, ShieldCheck, Info
} from 'lucide-react';
import { Package } from '../data/packagesData';
import { buildPackageWhatsAppMessage, openWhatsAppChat, TVISTA_WHATSAPP_NUMBER, TVISTA_WHATSAPP_DISPLAY } from '../utils/whatsapp';
import RichDescription from './RichDescription';

interface PackageModalProps {
  packageData: Package | null;
  onClose: () => void;
}

export default function PackageModal({ packageData, onClose }: PackageModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    travelDate: '',
    travelers: '2 Travelers (Couple)',
    notes: ''
  });

  if (!packageData) return null;

  const tags = Array.isArray(packageData.tags) && packageData.tags.length > 0 
    ? packageData.tags 
    : ['Luxury', 'Curated', 'Top Rated'];

  const handleWhatsAppDirect = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const waMsg = buildPackageWhatsAppMessage({
      title: packageData.title,
      duration: packageData.duration,
      price: packageData.price,
      location: packageData.location
    }, {
      name: formData.name || 'Guest Traveler',
      phone: 'Direct WhatsApp',
      travelDate: formData.travelDate,
      travelers: formData.travelers,
      notes: formData.notes
    });

    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, waMsg);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          onClick={e => e.stopPropagation()}
          className="bg-white/95 backdrop-blur-2xl border border-white/90 rounded-[2rem] sm:rounded-[2.5rem] max-w-3xl w-full overflow-hidden shadow-2xl relative my-6 text-[#1C1917] max-h-[92vh] flex flex-col"
        >
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-black/60 hover:bg-black/80 border border-white/30 text-white flex items-center justify-center backdrop-blur-md transition-all shadow-md"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Scrollable Content Container */}
          <div className="overflow-y-auto flex-1 custom-scrollbar">
            {/* Hero Image Header */}
            <div className="relative h-64 sm:h-80 bg-neutral-950 shrink-0">
              <img 
                src={packageData.image || 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800&auto=format&fit=crop'} 
                alt={packageData.title || 'Tour Package'} 
                onError={(e) => {
                  const target = e.currentTarget;
                  if (!target.dataset.fallback) {
                    target.dataset.fallback = 'true';
                    target.src = 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop';
                  }
                }}
                className="w-full h-full object-cover" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/95 via-neutral-950/50 to-transparent" />
              
              <div className="absolute top-4 left-4 z-10 flex flex-wrap gap-1.5 max-w-[80%]">
                {tags.map((tag) => (
                  <span 
                    key={tag} 
                    className="px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white text-[10px] font-bold uppercase tracking-wider shadow-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              <div className="absolute bottom-5 left-5 right-5 sm:bottom-6 sm:left-7 sm:right-7 text-white">
                <div className="flex items-center gap-1.5 mb-1.5 text-amber-300 text-xs font-bold uppercase tracking-wider">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{packageData.location || 'Worldwide Destination'}</span>
                </div>
                <h2 className="text-2xl sm:text-4xl font-serif font-bold text-white tracking-tight drop-shadow-sm">
                  {packageData.title || 'Curated Tour Package'}
                </h2>
                
                <div className="flex flex-wrap items-center gap-3 sm:gap-5 text-xs font-medium text-white/90 mt-3 pt-3 border-t border-white/15">
                  <span className="flex items-center gap-1.5 bg-white/15 px-3 py-1 rounded-full backdrop-blur-md">
                    <Clock className="w-3.5 h-3.5 text-amber-300" /> 
                    {packageData.duration || 'Flexible Duration'}
                  </span>
                  <span className="flex items-center gap-1.5 bg-white/15 px-3 py-1 rounded-full backdrop-blur-md">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> 
                    {packageData.rating || 4.8} ({packageData.reviews ?? 120} reviews)
                  </span>
                  <span className="text-white font-serif text-sm sm:text-base font-bold text-amber-200 ml-auto">
                    {packageData.price || 'Price on request'} <span className="text-xs font-sans font-normal text-white/70">/ guest</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Structured Body Content */}
            <div className="p-5 sm:p-8 space-y-7 text-stone-800">
              
              {/* 1. Overview Section - Structured Layout */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-stone-500 text-xs font-bold uppercase tracking-widest">
                    <Info className="w-4 h-4 text-amber-600" />
                    <span>Package Overview & Experience Details</span>
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-0.5 rounded-full bg-amber-100/70 text-amber-900 border border-amber-300/60">
                    Curated Itinerary
                  </span>
                </div>

                {/* Structured Overview Card */}
                <div className="bg-stone-50/80 border border-stone-200/90 rounded-2xl p-4 sm:p-6 space-y-4">
                  {/* Lead Narrative / Formatted Uploaded Description */}
                  <div className="relative pl-4 border-l-3 border-amber-500 bg-white/70 p-4 sm:p-6 rounded-r-2xl border-y border-r border-stone-200/70 shadow-2xs">
                    <RichDescription 
                      content={packageData.description || 'Experience an exceptionally planned itinerary with personalized concierge service, premium accommodations, and seamless transfers crafted by Tvista Holidays.'} 
                      theme="light"
                    />
                  </div>

                  {/* Travel Badges Row */}
                  <div className="pt-2 flex flex-wrap items-center gap-2 text-[11px] font-medium text-stone-600">
                    <span className="px-2.5 py-1 rounded-md bg-stone-200/70 text-stone-800">
                      📍 {packageData.location || 'Worldwide Destination'}
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-stone-200/70 text-stone-800">
                      ⏱ {packageData.duration || 'Flexible Pacing'}
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-stone-200/70 text-stone-800">
                      ⭐ {packageData.rating || 4.8} / 5.0 Rating
                    </span>
                  </div>
                </div>
              </div>

              {/* 2. Structured Key Specifications Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-stone-50/90 border border-stone-200/80 rounded-2xl p-4 sm:p-5">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-stone-500 font-bold block">Duration</span>
                  <p className="text-xs sm:text-sm font-semibold text-stone-900 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>{packageData.duration || 'Custom Pacing'}</span>
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-stone-500 font-bold block">Tour Type</span>
                  <p className="text-xs sm:text-sm font-semibold text-stone-900 flex items-center gap-1.5">
                    <Compass className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>Private / Tailored</span>
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-stone-500 font-bold block">Stay Quality</span>
                  <p className="text-xs sm:text-sm font-semibold text-stone-900 flex items-center gap-1.5">
                    <Hotel className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>4★ & 5★ Premium</span>
                  </p>
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-stone-500 font-bold block">Assistance</span>
                  <p className="text-xs sm:text-sm font-semibold text-stone-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>24/7 Concierge</span>
                  </p>
                </div>
              </div>

              {/* 3. WhatsApp Inquiry & Booking Section */}
              <div className="pt-2 border-t border-stone-200">
                <form onSubmit={handleWhatsAppDirect} className="space-y-4 bg-gradient-to-b from-stone-50 to-stone-100/80 border border-stone-200/90 rounded-2xl p-5 sm:p-6 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h3 className="text-base sm:text-lg font-serif font-bold text-[#1C1917]">
                        Book or Customize on WhatsApp
                      </h3>
                      <p className="text-xs text-stone-500">
                        Get an instant quote & personalized itinerary on {TVISTA_WHATSAPP_DISPLAY}
                      </p>
                    </div>
                    <span className="self-start sm:self-auto text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-3 py-1 rounded-full border border-emerald-300 flex items-center gap-1.5 shadow-xs">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      Direct WhatsApp Booking
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-bold">
                        Your Name (Optional)
                      </label>
                      <input 
                        type="text" 
                        placeholder="e.g. Rahul Sharma" 
                        value={formData.name}
                        onChange={e => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-white border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all shadow-xs" 
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-bold">
                        Preferred Travel Date
                      </label>
                      <input 
                        type="date" 
                        value={formData.travelDate}
                        onChange={e => setFormData({ ...formData, travelDate: e.target.value })}
                        className="w-full bg-white border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all shadow-xs" 
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-bold">
                        Number of Travelers
                      </label>
                      <select
                        value={formData.travelers}
                        onChange={e => setFormData({ ...formData, travelers: e.target.value })}
                        className="w-full bg-white border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all shadow-xs"
                      >
                        <option value="1 Solo Traveler">1 Solo Traveler</option>
                        <option value="2 Travelers (Couple)">2 Travelers (Couple)</option>
                        <option value="3-5 Travelers (Family)">3-5 Travelers (Family)</option>
                        <option value="Group Trip (6+)">Group Trip (6+)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-bold">
                        Special Notes & Customizations
                      </label>
                      <input 
                        type="text" 
                        placeholder="e.g. Flight inquiry, meal preferences..." 
                        value={formData.notes}
                        onChange={e => setFormData({ ...formData, notes: e.target.value })}
                        className="w-full bg-white border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-all shadow-xs" 
                      />
                    </div>
                  </div>

                  <button 
                    type="submit" 
                    className="w-full bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold py-3.5 sm:py-4 rounded-xl transition-all text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 mt-2 cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 fill-white text-emerald-600" />
                    <span>Inquire & Book on WhatsApp</span>
                  </button>
                </form>
              </div>

            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

