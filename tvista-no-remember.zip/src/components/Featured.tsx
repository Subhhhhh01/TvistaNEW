import React, { useState } from 'react';
import { motion, AnimatePresence, MotionValue, useMotionValue, useMotionValueEvent, useTransform, useSpring } from 'motion/react';
import { ArrowRight, Calendar, Clock, IndianRupee, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface FeaturedEscape {
  id: string;
  title: string;
  description: string;
  image: string;
  bgImage: string;
  season: string;
  duration: string;
  price: string;
  rating: string;
}

const FEATURED_ESCAPES: FeaturedEscape[] = [
  {
    id: 'bali',
    title: 'Ubud, Bali',
    description: 'Immerse yourself in the spiritual heart of Bali. From ancient emerald rice terraces to secluded jungle retreats, experience a transformative journey where luxury meets untouched nature.',
    image: 'https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop',
    season: 'May - September',
    duration: '10 - 14 Days',
    price: '₹1,95,000',
    rating: '4.9/5 (120+ Reviews)'
  },
  {
    id: 'santorini',
    title: 'Santorini, Greece',
    description: 'Witness the world\'s most breathtaking sunsets. Wander through iconic white-washed villages perched on volcanic cliffs overlooking the endless azure Aegean Sea.',
    image: 'https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=2021&auto=format&fit=crop',
    season: 'June - October',
    duration: '7 - 10 Days',
    price: '₹2,65,000',
    rating: '4.8/5 (200+ Reviews)'
  },
  {
    id: 'kyoto',
    title: 'Kyoto, Japan',
    description: 'Step back in time in Japan\'s cultural capital. Explore serene Zen gardens, magnificent temples, and traditional geisha districts wrapped in quiet elegance.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=2070&auto=format&fit=crop',
    bgImage: 'https://images.unsplash.com/photo-1526481280693-3bfa7568e0f3?q=80&w=2071&auto=format&fit=crop',
    season: 'March - May',
    duration: '14 - 21 Days',
    price: '₹3,40,000',
    rating: '4.9/5 (85+ Reviews)'
  }
];

interface FeaturedProps {
  progress?: MotionValue<number>;
}

function ThumbnailCard({
  escape,
  idx,
  total,
  activeEscape,
  progress,
  onClick
}: {
  escape: FeaturedEscape;
  idx: number;
  total: number;
  activeEscape: number;
  progress?: MotionValue<number>;
  onClick: () => void;
  key?: React.Key;
}) {
  const step = 1 / total;
  const cardCenter = (idx + 0.5) * step;

  const defaultProg = useMotionValue(0);
  const activeProg = progress || defaultProg;

  const domain = idx === 0
    ? [0, step * 0.5, step]
    : idx === total - 1
    ? [1 - step, 1 - step * 0.5, 1]
    : [Math.max(0, cardCenter - step * 0.5), cardCenter, Math.min(1, cardCenter + step * 0.5)];

  const progressScale = useTransform(activeProg, domain, [0.94, 1.05, 0.96]);
  const progressOpacity = useTransform(activeProg, domain, [0.6, 1, 0.65]);

  const isSelected = activeEscape === idx;
  const scale = progress ? progressScale : (isSelected ? 1.04 : 0.96);
  const opacity = progress ? progressOpacity : (isSelected ? 1 : 0.7);

  return (
    <motion.div
      style={{ scale, opacity }}
      onClick={onClick}
      className={`relative h-14 sm:h-24 flex-1 rounded-xl sm:rounded-2xl overflow-hidden cursor-pointer border-2 transition-colors duration-200 ${
        isSelected ? 'border-white shadow-[0_0_20px_rgba(255,255,255,0.4)]' : 'border-white/10 hover:border-white/40'
      }`}
    >
      <img src={escape.image} alt={escape.title} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]" />
      <div className="absolute bottom-1 sm:bottom-2 left-2 sm:left-3 right-2 sm:right-3 text-white">
        <p className="text-[8px] sm:text-[10px] font-bold uppercase tracking-wider opacity-80">{escape.id}</p>
        <p className="text-[10px] sm:text-xs font-serif font-bold truncate">{escape.title.split(',')[0]}</p>
      </div>
      {isSelected && (
        <div className="absolute inset-0 border-2 border-white rounded-xl sm:rounded-2xl pointer-events-none shadow-inner" />
      )}
    </motion.div>
  );
}

function StepIndicatorBar({
  idx,
  total,
  activeEscape,
  progress
}: {
  idx: number;
  total: number;
  activeEscape?: number;
  progress?: MotionValue<number>;
  key?: React.Key;
}) {
  const threshold = idx / total;
  const defaultProg = useMotionValue(0);
  const activeProg = progress || defaultProg;

  const scaleX = useTransform(
    activeProg,
    [Math.max(0, threshold - 0.1), (idx + 1) / total],
    [0, 1]
  );

  const isCompleted = activeEscape !== undefined ? idx <= activeEscape : false;

  return (
    <div className="flex-1 h-1.5 bg-white/20 rounded-full overflow-hidden relative">
      {progress ? (
        <motion.div
          style={{ scaleX, transformOrigin: 'left' }}
          className="h-full bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.8)]"
        />
      ) : (
        <div
          className={`h-full transition-all duration-300 rounded-full ${
            isCompleted ? 'bg-white w-full shadow-[0_0_10px_rgba(255,255,255,0.8)]' : 'bg-transparent w-0'
          }`}
        />
      )}
    </div>
  );
}

export default function Featured({ progress }: FeaturedProps) {
  const [activeEscape, setActiveEscape] = useState(0);
  const defaultProgress = useMotionValue(0);
  const activeProgress = progress || defaultProgress;

  useMotionValueEvent(activeProgress, 'change', (latest) => {
    if (progress) {
      const target = latest < 0.33 ? 0 : latest < 0.66 ? 1 : 2;
      setActiveEscape(prev => (prev !== target ? target : prev));
    }
  });

  const currentEscape = FEATURED_ESCAPES[activeEscape];

  // Scroll-driven enlarging effects for the left showcase container and image card
  const rawContainerScale = useTransform(
    activeProgress,
    [0, 0.4, 0.8, 1],
    [0.92, 1.0, 1.05, 1.08]
  );
  const containerScale = useSpring(rawContainerScale, { stiffness: 180, damping: 28 });

  const rawCardScale = useTransform(
    activeProgress,
    [0, 0.33, 0.35, 0.66, 0.68, 1],
    [0.95, 1.04, 0.97, 1.05, 0.98, 1.06]
  );
  const cardScale = useSpring(rawCardScale, { stiffness: 180, damping: 28 });

  const rawImageScale = useTransform(
    activeProgress,
    [0, 1],
    [1.0, 1.15]
  );
  const imageScale = useSpring(rawImageScale, { stiffness: 180, damping: 28 });

  return (
    <section className="relative py-4 sm:py-12 md:py-20 px-4 sm:px-8 lg:px-20 min-h-screen flex items-center overflow-hidden">
      {/* Background Image Overlay */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence>
          <motion.img 
            key={`bg-${activeEscape}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeInOut" }}
            src={currentEscape.bgImage} 
            alt="Background" 
            className="absolute inset-0 w-full h-full object-cover"
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-black/60 backdrop-blur-[4px] transition-colors duration-500"></div>
      </div>

      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-4 sm:gap-8 lg:gap-16 items-center relative z-10 w-full">
        
        {/* Left Column: Big Image Showcase & Thumbnails (Enlarging on Scroll) */}
        <motion.div 
          style={{ 
            scale: progress ? containerScale : 1 
          }}
          className="w-full lg:w-1/2 relative group perspective-1000 flex flex-col gap-2.5 sm:gap-6 origin-center will-change-transform"
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            style={{ 
              scale: progress ? cardScale : 1 
            }}
            className="h-36 sm:h-56 lg:h-auto lg:aspect-[4/3] rounded-2xl sm:rounded-[2rem] overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.5)] relative border border-white/20 group origin-center will-change-transform"
          >
            <AnimatePresence mode="wait">
              <motion.img 
                key={`img-${activeEscape}`}
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                style={{
                  scale: progress ? imageScale : 1
                }}
                src={currentEscape.image} 
                alt={currentEscape.title} 
                className="absolute inset-0 w-full h-full object-cover origin-center" 
              />
            </AnimatePresence>
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60"></div>
            
            {/* Overlay Title for Mobile */}
            <div className="absolute bottom-3 left-3 right-3 lg:hidden">
               <h3 className="text-white text-lg sm:text-2xl font-display leading-tight">{currentEscape.title}</h3>
            </div>
          </motion.div>
          
          {/* Scroll-Driven Thumbnails */}
          <div className="flex gap-2 sm:gap-4 overflow-x-auto pb-1">
            {FEATURED_ESCAPES.map((escape, idx) => (
              <ThumbnailCard
                key={escape.id}
                escape={escape}
                idx={idx}
                total={FEATURED_ESCAPES.length}
                activeEscape={activeEscape}
                progress={progress}
                onClick={() => setActiveEscape(idx)}
              />
            ))}
          </div>
        </motion.div>

        {/* Right Column: Hero Content & Stats Grid */}
        <div className="w-full lg:w-1/2">
          {/* Top Scroll Indicator Bars */}
          <div className="flex items-center gap-2 mb-2 sm:mb-6 max-w-xs">
            {FEATURED_ESCAPES.map((_, i) => (
              <StepIndicatorBar
                key={i}
                idx={i}
                total={FEATURED_ESCAPES.length}
                activeEscape={activeEscape}
                progress={progress}
              />
            ))}
          </div>

          <div className="relative overflow-hidden w-full">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeEscape}
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.02 }}
                transition={{ duration: 0.45, ease: "easeOut" }}
                className="w-full origin-center"
              >
                <div className="flex items-center gap-2 sm:gap-3 mb-1.5 sm:mb-4">
                   <span className="w-6 sm:w-8 h-[2px] bg-white/70"></span>
                   <p className="text-xs sm:text-sm font-bold tracking-widest uppercase text-white/90 drop-shadow-md flex items-center gap-1.5 sm:gap-2">
                     <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                     Featured Escapes (0{activeEscape + 1}/0{FEATURED_ESCAPES.length})
                   </p>
                </div>
                
                <h2 className="font-display text-2xl sm:text-4xl lg:text-6xl text-white drop-shadow-lg leading-tight mb-2 sm:mb-4">
                  {currentEscape.title}
                </h2>

                <p className="text-white/80 text-xs sm:text-base lg:text-lg leading-relaxed max-w-lg drop-shadow-sm mb-4 sm:mb-8 line-clamp-2 sm:line-clamp-none">
                  {currentEscape.description}
                </p>

                {/* 2x2 Stats Grid */}
                <div className="grid grid-cols-2 gap-2 sm:gap-5 mb-4 sm:mb-10">
                  <div className="flex gap-2.5 sm:gap-4 items-center sm:items-start p-2.5 sm:p-4 rounded-xl sm:rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer group">
                    <Calendar className="w-4 h-4 sm:w-6 sm:h-6 text-white/80 group-hover:scale-110 transition-transform shrink-0" />
                    <div>
                      <p className="text-[10px] sm:text-xs text-white/50 font-bold uppercase tracking-wider mb-0.5">Prime Season</p>
                      <p className="text-xs sm:text-base text-white font-medium">{currentEscape.season}</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 sm:gap-4 items-center sm:items-start p-2.5 sm:p-4 rounded-xl sm:rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer group">
                    <Clock className="w-4 h-4 sm:w-6 sm:h-6 text-white/80 group-hover:scale-110 transition-transform shrink-0" />
                    <div>
                      <p className="text-[10px] sm:text-xs text-white/50 font-bold uppercase tracking-wider mb-0.5">Duration</p>
                      <p className="text-xs sm:text-base text-white font-medium">{currentEscape.duration}</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 sm:gap-4 items-center sm:items-start p-2.5 sm:p-4 rounded-xl sm:rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer group">
                    <IndianRupee className="w-4 h-4 sm:w-6 sm:h-6 text-white/80 group-hover:scale-110 transition-transform shrink-0" />
                    <div>
                      <p className="text-[10px] sm:text-xs text-white/50 font-bold uppercase tracking-wider mb-0.5">Starting From</p>
                      <p className="text-xs sm:text-base text-white font-medium">{currentEscape.price}</p>
                    </div>
                  </div>
                  <div className="flex gap-2.5 sm:gap-4 items-center sm:items-start p-2.5 sm:p-4 rounded-xl sm:rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer group">
                    <div className="w-4 h-4 sm:w-6 sm:h-6 flex items-center justify-center border border-white/80 rounded-full text-white font-bold text-[10px] sm:text-xs group-hover:bg-white group-hover:text-neutral-950 transition-colors shrink-0">
                      ★
                    </div>
                    <div>
                      <p className="text-[10px] sm:text-xs text-white/50 font-bold uppercase tracking-wider mb-0.5">Rating</p>
                      <p className="text-xs sm:text-base text-white font-medium">{currentEscape.rating}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <Link
                    to="/packages"
                    className="group inline-flex items-center gap-2.5 sm:gap-3 bg-white text-neutral-950 px-6 py-2.5 sm:px-8 sm:py-4 rounded-full font-bold text-xs sm:text-base hover:bg-white/90 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.3)]"
                  >
                    Book This Experience
                    <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
