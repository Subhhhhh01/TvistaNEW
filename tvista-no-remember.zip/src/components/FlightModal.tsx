import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plane, Calendar, User, Clock, MessageCircle } from 'lucide-react';
import { buildFlightWhatsAppMessage, openWhatsAppChat, TVISTA_WHATSAPP_NUMBER, TVISTA_WHATSAPP_DISPLAY } from '../utils/whatsapp';

export interface FlightDeal {
  id: string;
  airline: string;
  airlineLogo?: string;
  from: string;
  fromCode: string;
  to: string;
  toCode: string;
  price: string;
  duration: string;
  type: string; // e.g. "Direct", "1 Stop"
  flightDate?: string; // YYYY-MM-DD
  popularTags?: string[];
  image: string;
}

interface FlightModalProps {
  flight: FlightDeal | null;
  onClose: () => void;
}

export default function FlightModal({ flight, onClose }: FlightModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    departDate: flight?.flightDate || '',
    returnDate: '',
    passengers: '1 Adult',
    classType: 'Economy',
    notes: ''
  });

  if (!flight) return null;

  const handleWhatsAppDirect = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const waMsg = buildFlightWhatsAppMessage(flight, {
      name: formData.name || 'Guest Traveler',
      phone: 'Direct WhatsApp',
      departDate: formData.departDate,
      returnDate: formData.returnDate,
      passengers: formData.passengers,
      classType: formData.classType,
      notes: formData.notes
    });

    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, waMsg);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 sm:p-6 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          onClick={e => e.stopPropagation()}
          className="bg-white/90 backdrop-blur-2xl border border-white/90 rounded-[2.5rem] max-w-2xl w-full overflow-hidden shadow-2xl relative my-8 text-[#1C1917]"
        >
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 z-10 w-10 h-10 rounded-full bg-white/80 hover:bg-white border border-stone-200 text-stone-700 flex items-center justify-center backdrop-blur-md transition-all shadow-sm"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Header Banner */}
          <div className="relative p-6 sm:p-8 bg-white/40 backdrop-blur-md border-b border-stone-200/80">
            <div className="flex items-center gap-3 mb-3">
              {flight.airlineLogo && (
                <div className="w-8 h-8 rounded-lg bg-white border border-stone-200 p-1 flex items-center justify-center shadow-sm shrink-0">
                  <img 
                    src={flight.airlineLogo} 
                    alt={flight.airline} 
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.currentTarget;
                      const cleanDomain = flight.airline.toLowerCase().replaceAll(' ', '');
                      target.src = "https://www.google.com/s2/favicons?domain=" + cleanDomain + ".com&sz=128";
                    }}
                    className="w-full h-full object-contain" 
                  />
                </div>
              )}
              <div>
                <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest block">Instant WhatsApp Airfare Booking</span>
                <span className="text-xs font-semibold text-stone-800">{flight.airline} • {flight.type}</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl sm:text-3xl font-serif text-[#1C1917] flex items-center gap-2">
                  <span>{flight.from}</span>
                  <Plane className="w-5 h-5 text-stone-500 rotate-90 sm:rotate-0" />
                  <span>{flight.to}</span>
                </h2>
                <p className="text-xs text-stone-600 mt-1 font-medium">{flight.duration} Duration</p>
              </div>
              <div className="text-left sm:text-right">
                <span className="text-xs text-stone-500 block">Fares starting from</span>
                <span className="text-xl sm:text-2xl font-serif font-bold text-[#1C1917]">{flight.price}</span>
              </div>
            </div>
          </div>

          {/* Modal Body / Instant WhatsApp Form */}
          <div className="p-6 sm:p-8">
            <p className="text-stone-600 text-xs sm:text-sm mb-6 leading-relaxed">
              Inquire for discounted airfares, seats, or cabin upgrades for <strong className="text-[#1C1917] font-semibold">{flight.from} ({flight.fromCode}) to {flight.to} ({flight.toCode})</strong> on WhatsApp ({TVISTA_WHATSAPP_DISPLAY}).
            </p>

            <form onSubmit={handleWhatsAppDirect} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Your Name (Optional)</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Rahul Sharma" 
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Departure Date</label>
                  <input 
                    type="date" 
                    value={formData.departDate}
                    onChange={e => setFormData({ ...formData, departDate: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Return Date</label>
                  <input 
                    type="date" 
                    value={formData.returnDate}
                    onChange={e => setFormData({ ...formData, returnDate: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Passengers</label>
                  <select 
                    value={formData.passengers}
                    onChange={e => setFormData({ ...formData, passengers: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm"
                  >
                    <option value="1 Adult">1 Adult</option>
                    <option value="2 Adults">2 Adults</option>
                    <option value="3+ Adults (Family)">3+ Adults (Family)</option>
                    <option value="Group Booking (9+)">Group Booking (9+)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Cabin Class</label>
                  <select 
                    value={formData.classType}
                    onChange={e => setFormData({ ...formData, classType: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm"
                  >
                    <option value="Economy">Economy</option>
                    <option value="Premium Economy">Premium Economy</option>
                    <option value="Business Class">Business Class</option>
                    <option value="First Class">First Class</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Special Requests / Preferences</label>
                <input 
                  type="text"
                  placeholder="Preferred airline, departure times, extra baggage..." 
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm"
                />
              </div>

              <button 
                type="submit" 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl transition-all text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 mt-2"
              >
                <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                <span>Get Airfare Quote on WhatsApp</span>
              </button>
            </form>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
