import React from 'react';

interface TvistaLogoProps {
  className?: string;
  height?: number | string;
  variant?: 'color' | 'light' | 'white' | 'on-dark';
}

export default function TvistaLogo({
  className = 'h-10 w-auto',
  variant = 'color'
}: TvistaLogoProps) {
  // Color palette matching the official brand identity
  const isWhite = variant === 'white';
  const isOnDark = variant === 'on-dark';

  const redColor = isWhite ? '#FFFFFF' : '#8B0000'; // Brand maroon / deep crimson 'T'
  const navyColor = isWhite ? '#FFFFFF' : (isOnDark ? '#FFFFFF' : '#14213D'); // Navy on light, white/light on dark
  const sunColor = isWhite ? '#FCD34D' : '#F59E0B'; // Golden sun
  const greenColor = isWhite ? '#34D399' : '#16A34A'; // Travel green
  const skyBuildingColor = isWhite ? '#93C5FD' : '#2563EB'; // Skyline blue
  const trailColor = isWhite ? '#E0E7FF' : '#3B82F6';

  return (
    <svg
      viewBox="0 0 400 220"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} ${isOnDark ? 'drop-shadow-[0_2px_12px_rgba(0,0,0,0.75)]' : 'drop-shadow-xs'}`}
      aria-label="Tvista Holidays Logo"
    >
      <defs>
        {/* Sun Gradient */}
        <linearGradient id="tvistaSunGlow" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#FBBF24" />
          <stop offset="100%" stopColor="#EA580C" />
        </linearGradient>
      </defs>

      {/* 1. RISING SUN GRAPHIC */}
      <g transform="translate(108, 38)">
        {/* Sun Semi-circle */}
        <path
          d="M 16 48 A 20 20 0 0 1 56 48 Z"
          fill={isWhite ? '#FCD34D' : 'url(#tvistaSunGlow)'}
        />
        <path
          d="M 22 48 A 14 14 0 0 1 50 48 Z"
          fill={isWhite ? '#FEF08A' : '#FDE047'}
        />
        {/* Sun Rays */}
        <line x1="8" y1="46" x2="0" y2="44" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="12" y1="36" x2="3" y2="30" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="18" y1="26" x2="10" y2="17" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="27" y1="18" x2="22" y2="7" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="36" y1="14" x2="36" y2="3" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="45" y1="18" x2="50" y2="7" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="54" y1="26" x2="62" y2="17" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
        <line x1="60" y1="36" x2="69" y2="30" stroke={sunColor} strokeWidth="3" strokeLinecap="round" />
      </g>

      {/* 2. CITY SKYLINE BUILDINGS */}
      <g transform="translate(168, 34)">
        {/* Left tower */}
        <rect x="0" y="8" width="16" height="38" fill={skyBuildingColor} rx="1" />
        <rect x="3" y="12" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="10" y="12" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="3" y="19" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="10" y="19" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="3" y="26" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="10" y="26" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="3" y="33" width="3" height="3" fill="#FFFFFF" opacity="0.9" />
        <rect x="10" y="33" width="3" height="3" fill="#FFFFFF" opacity="0.9" />

        {/* Middle high tower */}
        <rect x="8" y="0" width="18" height="46" fill={isOnDark ? '#1E293B' : '#0F172A'} rx="1" />
        {/* Grid windows */}
        <rect x="11" y="4" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="16" y="4" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="21" y="4" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="11" y="11" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="16" y="11" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="21" y="11" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="11" y="18" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="16" y="18" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="21" y="18" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="11" y="25" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="16" y="25" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="21" y="25" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="11" y="32" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="16" y="32" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
        <rect x="21" y="32" width="3" height="3" fill="#FFFFFF" opacity="0.95" />
      </g>

      {/* 3. TROPICAL PALM TREES */}
      <g transform="translate(194, 26)">
        {/* Left palm tree */}
        <path
          d="M 10 52 Q 13 36 9 20"
          stroke={greenColor}
          strokeWidth="3.5"
          fill="none"
          strokeLinecap="round"
        />
        {/* Left palm fronds */}
        <path d="M 9 20 Q 2 12 -4 19 Q 3 24 9 20 Z" fill={greenColor} />
        <path d="M 9 20 Q 3 4 8 -2 Q 13 8 9 20 Z" fill={greenColor} />
        <path d="M 9 20 Q 15 2 22 5 Q 18 14 9 20 Z" fill={greenColor} />
        <path d="M 9 20 Q 21 15 24 23 Q 16 26 9 20 Z" fill={greenColor} />
        <path d="M 9 20 Q 5 28 -2 30 Q 2 24 9 20 Z" fill={greenColor} />

        {/* Right taller palm tree */}
        <path
          d="M 28 54 Q 31 30 26 8"
          stroke={greenColor}
          strokeWidth="3.5"
          fill="none"
          strokeLinecap="round"
        />
        {/* Right palm fronds */}
        <path d="M 26 8 Q 14 0 7 7 Q 16 12 26 8 Z" fill={greenColor} />
        <path d="M 26 8 Q 21 -8 27 -13 Q 32 -4 26 8 Z" fill={greenColor} />
        <path d="M 26 8 Q 35 -6 44 -2 Q 38 7 26 8 Z" fill={greenColor} />
        <path d="M 26 8 Q 42 6 44 17 Q 35 17 26 8 Z" fill={greenColor} />
        <path d="M 26 8 Q 16 18 10 22 Q 18 14 26 8 Z" fill={greenColor} />
      </g>

      {/* 4. DUAL CURVED TRAVEL ARCS / SWOOSHES */}
      {/* Upper Maroon Arch */}
      <path
        d="M 98 94 C 130 68 220 54 285 94 C 235 68 150 78 98 94 Z"
        fill={redColor}
      />
      <path
        d="M 98 93 C 145 62 235 62 284 94 C 236 67 146 67 98 93 Z"
        fill={redColor}
      />

      {/* Lower Vibrant Green Arch with sharp upward dynamic sweep */}
      <path
        d="M 158 92 C 190 78 245 74 284 95 L 314 62 C 298 76 270 90 236 86 C 195 82 172 90 158 92 Z"
        fill={greenColor}
      />

      {/* Flight Speed Trail */}
      <circle cx="318" cy="56" r="2" fill={trailColor} />
      <circle cx="323" cy="51" r="2.2" fill={trailColor} />
      <circle cx="329" cy="45" r="2.5" fill={trailColor} />

      {/* 5. JETLINER AIRPLANE ASCENDING */}
      <g transform="translate(318, 30) rotate(-18)">
        <path
          d="M 0 12 L 18 12 L 28 0 L 33 0 L 26 12 L 48 12 C 54 12 58 14 58 16 C 58 18 54 20 48 20 L 26 20 L 33 32 L 28 32 L 18 20 L 6 20 L 0 26 L -3 26 L 0 19 L 0 13 Z"
          fill={isOnDark ? '#60A5FA' : '#1E3A8A'}
        />
        <ellipse cx="22" cy="7" rx="3" ry="1.2" fill={isOnDark ? '#93C5FD' : '#1E3A8A'} />
      </g>

      {/* 6. PRIMARY BRAND TYPOGRAPHY: "T VISTA" */}
      {/* Prominent Red / Burgundy Serif 'T' */}
      <g fill={redColor}>
        <rect x="16" y="54" width="76" height="19" rx="1.5" />
        <polygon points="16,54 16,77 22,77 22,54" />
        <polygon points="92,54 92,77 86,77 86,54" />
        <rect x="42" y="73" width="24" height="78" rx="1" />
        <polygon points="34,151 74,151 74,144 34,144" />
      </g>

      {/* Crisp Navy / White 'V I S T A' */}
      <text
        x="82"
        y="151"
        fill={navyColor}
        fontSize="76"
        fontWeight="900"
        fontFamily="system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
        letterSpacing="-0.02em"
      >
        VISTA
      </text>

      {/* 7. SUBTITLE TYPOGRAPHY: 'H O L I D A Y S' with wide tracking */}
      <text
        x="45"
        y="186"
        fill={isOnDark ? '#E2E8F0' : navyColor}
        fontSize="21"
        fontWeight="800"
        fontFamily="'Times New Roman', Times, 'Cormorant Garamond', Garamond, Georgia, serif"
        letterSpacing="0.44em"
      >
        HOLIDAYS
      </text>
    </svg>
  );
}
