import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, IndianRupee, Globe2, MessageCircle } from 'lucide-react';
import { buildVisaWhatsAppMessage, openWhatsAppChat, TVISTA_WHATSAPP_NUMBER, TVISTA_WHATSAPP_DISPLAY } from '../utils/whatsapp';

export interface VisaCountry {
  name: string;
  code: string;
  types: string[];
  processingTime: string;
  fee: string;
  details: string;
}

interface VisaModalProps {
  country: VisaCountry | null;
  onClose: () => void;
}

export default function VisaModal({ country, onClose }: VisaModalProps) {
  const [selectedType, setSelectedType] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    travelDate: '',
    nationality: 'Indian Passport',
    notes: ''
  });

  if (!country) return null;

  const handleWhatsAppDirect = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const waMsg = buildVisaWhatsAppMessage({
      name: country.name,
      types: selectedType ? [selectedType] : country.types,
      fee: country.fee,
      processingTime: country.processingTime
    }, {
      name: formData.name || 'Guest Applicant',
      phone: 'Direct WhatsApp',
      travelDate: formData.travelDate,
      nationality: formData.nationality,
      notes: formData.notes
    });

    openWhatsAppChat(TVISTA_WHATSAPP_NUMBER, waMsg);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 sm:p-6 overflow-y-auto"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.95, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.95, y: 20 }}
          onClick={e => e.stopPropagation()}
          className="bg-white/90 backdrop-blur-2xl border border-white/90 rounded-[2.5rem] max-w-2xl w-full overflow-hidden shadow-2xl relative my-8 text-[#1C1917]"
        >
          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 z-10 w-10 h-10 rounded-full bg-white/80 hover:bg-white border border-stone-200 text-stone-700 flex items-center justify-center backdrop-blur-md transition-all shadow-sm"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Header Banner */}
          <div className="relative p-6 sm:p-8 bg-white/40 backdrop-blur-md border-b border-stone-200/80">
            <div className="flex items-center gap-4 mb-3">
              <img 
                src={`https://flagcdn.com/w80/${country.code.toLowerCase()}.png`} 
                alt={`${country.name} flag`} 
                className="w-10 h-7 rounded object-cover shadow-sm border border-stone-200"
              />
              <div>
                <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest block">Instant WhatsApp Visa Assistance</span>
                <h2 className="text-2xl sm:text-3xl font-serif text-[#1C1917]">{country.name}</h2>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3 mt-3 border-t border-stone-200/80 text-xs">
              <div className="flex items-center gap-1.5 text-stone-700 font-medium">
                <Clock className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                <span>{country.processingTime}</span>
              </div>
              <div className="flex items-center gap-1.5 text-stone-700 font-medium">
                <IndianRupee className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                <span>{country.fee}</span>
              </div>
              <div className="flex items-center gap-1.5 text-stone-700 font-medium col-span-2 sm:col-span-1">
                <Globe2 className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                <span className="truncate">{country.types[0]}</span>
              </div>
            </div>
          </div>

          {/* Modal Body / Instant WhatsApp Form */}
          <div className="p-6 sm:p-8">
            <p className="text-stone-600 text-xs sm:text-sm mb-6 leading-relaxed">
              Connect directly with our visa document specialists for <strong className="text-[#1C1917] font-semibold">{country.name}</strong> on WhatsApp ({TVISTA_WHATSAPP_DISPLAY}).
            </p>

            <form onSubmit={handleWhatsAppDirect} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Your Name (Optional)</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Rahul Sharma" 
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Intended Travel Date</label>
                  <input 
                    type="date" 
                    value={formData.travelDate}
                    onChange={e => setFormData({ ...formData, travelDate: e.target.value })}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Visa Category / Type</label>
                  <select 
                    value={selectedType}
                    onChange={e => setSelectedType(e.target.value)}
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm"
                  >
                    <option value="">Select Visa Type...</option>
                    {country.types.map(t => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Passport Nationality</label>
                  <input 
                    type="text" 
                    value={formData.nationality}
                    onChange={e => setFormData({ ...formData, nationality: e.target.value })}
                    placeholder="e.g. Indian Passport" 
                    className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm" 
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-stone-600 mb-1.5 font-semibold">Additional Details / Remarks</label>
                <input 
                  type="text"
                  placeholder="Number of applicants, urgent assistance..." 
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full bg-white/80 border border-stone-200 rounded-xl px-4 py-3 text-sm text-[#1C1917] placeholder:text-stone-400 focus:outline-none focus:border-emerald-600 focus:bg-white transition-all shadow-sm"
                />
              </div>

              <button 
                type="submit" 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-4 rounded-xl transition-all text-xs uppercase tracking-wider shadow-lg flex items-center justify-center gap-2 mt-2"
              >
                <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
                <span>Chat Visa Desk on WhatsApp</span>
              </button>
            </form>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
