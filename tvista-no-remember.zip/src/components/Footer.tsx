import React from 'react';
import { Link } from 'react-router-dom';
import { Plane, Mail, Phone, MapPin, Instagram, Facebook, Twitter, Globe } from 'lucide-react';
import TvistaLogo from './TvistaLogo';

interface FooterProps {
  theme?: 'dark' | 'light';
}

export default function Footer({ theme = 'dark' }: FooterProps) {
  const isLight = theme === 'light';

  return (
    <footer className={`border-t backdrop-blur-2xl transition-all relative z-20 ${
      isLight 
        ? 'bg-white/40 text-stone-900 border-stone-200/50' 
        : 'bg-white/5 text-white border-white/10 shadow-[0_-10px_30px_rgba(0,0,0,0.3)]'
    }`}>
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-20 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <Link to="/" className="inline-flex items-center cursor-pointer group">
              <TvistaLogo 
                className="h-11 w-auto object-contain" 
                variant={isLight ? 'color' : 'on-dark'} 
              />
            </Link>
            <p className={`text-sm leading-relaxed ${isLight ? 'text-stone-600' : 'text-white/70'}`}>
              Crafting extraordinary luxury journeys, bespoke holiday packages, and seamless visa assistance worldwide.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a href="#" aria-label="Instagram" className={`w-9 h-9 rounded-full flex items-center justify-center border transition-colors ${isLight ? 'border-stone-300 text-stone-700 hover:bg-stone-200' : 'border-white/20 text-white/80 hover:bg-white/10'}`}>
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" aria-label="Facebook" className={`w-9 h-9 rounded-full flex items-center justify-center border transition-colors ${isLight ? 'border-stone-300 text-stone-700 hover:bg-stone-200' : 'border-white/20 text-white/80 hover:bg-white/10'}`}>
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" aria-label="Twitter" className={`w-9 h-9 rounded-full flex items-center justify-center border transition-colors ${isLight ? 'border-stone-300 text-stone-700 hover:bg-stone-200' : 'border-white/20 text-white/80 hover:bg-white/10'}`}>
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-widest mb-6 ${isLight ? 'text-stone-900' : 'text-white'}`}>
              Navigation
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Home
                </Link>
              </li>
              <li>
                <Link to="/destinations" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Destinations
                </Link>
              </li>
              <li>
                <Link to="/packages" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Tour Packages
                </Link>
              </li>
              <li>
                <Link to="/promos" className={`transition-colors flex items-center gap-1.5 ${isLight ? 'text-amber-700 hover:text-stone-900 font-medium' : 'text-amber-300 hover:text-amber-200 font-medium'}`}>
                  <span>Promos &amp; Offers</span>
                  <span className="text-[10px] px-1.5 py-0.2 bg-amber-400/20 text-amber-300 rounded-full border border-amber-400/30">Hot</span>
                </Link>
              </li>
              <li>
                <Link to="/news" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Travel News &amp; Journal
                </Link>
              </li>
              <li>
                <Link to="/flights" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Flight Tickets
                </Link>
              </li>
              <li>
                <Link to="/visa" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Visa Assistance
                </Link>
              </li>
              <li>
                <Link to="/gallery" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Photo Gallery
                </Link>
              </li>
            </ul>
          </div>

          {/* Quick Services */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-widest mb-6 ${isLight ? 'text-stone-900' : 'text-white'}`}>
              Popular Regions
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/packages?category=Beach" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Maldives & Island Escapes
                </Link>
              </li>
              <li>
                <Link to="/packages?category=Adventure" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Swiss Alps & Europe Tours
                </Link>
              </li>
              <li>
                <Link to="/packages?category=Culture" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Kyoto & Japan Heritage
                </Link>
              </li>
              <li>
                <Link to="/packages?category=Luxury" className={`transition-colors ${isLight ? 'text-stone-600 hover:text-stone-900' : 'text-white/70 hover:text-white'}`}>
                  Dubai Desert & City Luxury
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h4 className={`text-xs font-bold uppercase tracking-widest mb-6 ${isLight ? 'text-stone-900' : 'text-white'}`}>
              Contact Us
            </h4>
            <ul className="space-y-4 text-sm">
              <li className={`flex items-start gap-3 ${isLight ? 'text-stone-600' : 'text-white/70'}`}>
                <MapPin className="w-4 h-4 mt-0.5 shrink-0" />
                <span>7, Ganpat Bagla Road, Swastik Enclave, Block- B, 2nd Floor, Kolkata 700007</span>
              </li>
              <li className={`flex items-center gap-3 ${isLight ? 'text-stone-600' : 'text-white/70'}`}>
                <Phone className="w-4 h-4 shrink-0" />
                <span>+91 98307 12357</span>
              </li>
              <li className={`flex items-center gap-3 ${isLight ? 'text-stone-600' : 'text-white/70'}`}>
                <Mail className="w-4 h-4 shrink-0" />
                <span>support@tvistaholidays.com</span>
              </li>
            </ul>
          </div>

        </div>

        <div className={`pt-8 border-t text-xs flex flex-col sm:flex-row items-center justify-between gap-4 ${
          isLight ? 'border-stone-200 text-stone-500' : 'border-white/10 text-white/50'
        }`}>
          <p>© {new Date().getFullYear()} Tvista Holidays. All rights reserved.</p>
          <div className="flex gap-6 items-center">
            <Link to="/contact" className="hover:underline">Privacy Policy</Link>
            <Link to="/contact" className="hover:underline">Terms of Service</Link>
            <Link to="/contact" className="hover:underline">Inquire</Link>
            <span className="opacity-30">|</span>
            <Link to="/admin" className="hover:underline opacity-60 hover:opacity-100 transition-opacity">Admin Desk</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
