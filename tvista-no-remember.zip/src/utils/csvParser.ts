import { FlightDeal } from '../components/FlightModal';

/**
 * Returns today's date in YYYY-MM-DD string format
 */
export function getTodayDateString(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, '0');
  const day = String(today.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Normalizes date string to YYYY-MM-DD format if possible
 */
export function normalizeDateString(dateStr: string): string {
  if (!dateStr) return '';
  const trimmed = dateStr.trim();
  
  // Check if already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return trimmed;
  }

  // Check DD/MM/YYYY or DD-MM-YYYY
  const ddmmyyyy = trimmed.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
  if (ddmmyyyy) {
    const day = ddmmyyyy[1].padStart(2, '0');
    const month = ddmmyyyy[2].padStart(2, '0');
    const year = ddmmyyyy[3];
    return `${year}-${month}-${day}`;
  }

  // Fallback date parsing
  const d = new Date(trimmed);
  if (!isNaN(d.getTime())) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  return trimmed;
}

/**
 * Checks if a flight is expired (flightDate is earlier than today's date)
 */
export function isFlightExpired(flightDate?: string): boolean {
  if (!flightDate) return false; // If no specific date is set, keep as perpetual deal
  const normalized = normalizeDateString(flightDate);
  const today = getTodayDateString();
  return normalized < today;
}

/**
 * Parse a raw CSV row into string values handling quotes and escaped commas
 */
export function parseCsvRow(rowText: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < rowText.length; i++) {
    const char = rowText[i];
    if (char === '"' || char === "'") {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim().replace(/^["']|["']$/g, ''));
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim().replace(/^["']|["']$/g, ''));
  return result;
}

/**
 * Parses CSV text into array of FlightDeal objects (omitting 'id')
 */
export function parseFlightCsv(csvText: string): Omit<FlightDeal, 'id'>[] {
  const lines = csvText
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(line => line.length > 0);

  if (lines.length < 2) return [];

  // Header line
  const headers = parseCsvRow(lines[0]).map(h => h.toLowerCase().replace(/[^a-z0-9_]/g, ''));

  // Helper to find index matching keywords
  const findIndex = (keywords: string[]) => {
    return headers.findIndex(h => keywords.some(k => h.includes(k)));
  };

  const airlineIdx = findIndex(['airline', 'carrier', 'flightname']);
  const airlineLogoIdx = findIndex(['airlinelogo', 'logo', 'carrierlogo']);
  const fromIdx = findIndex(['from', 'origin', 'departurecity', 'depcity']);
  const fromCodeIdx = findIndex(['fromcode', 'origincode', 'depcode']);
  const toIdx = findIndex(['to', 'destination', 'arrivalcity', 'arrcity']);
  const toCodeIdx = findIndex(['tocode', 'destcode', 'arrcode']);
  const priceIdx = findIndex(['price', 'fare', 'cost', 'amount']);
  const durationIdx = findIndex(['duration', 'flighttime', 'time']);
  const typeIdx = findIndex(['type', 'stops', 'flighttype']);
  const flightDateIdx = findIndex(['flightdate', 'date', 'departuredate', 'dateflight']);
  const tagsIdx = findIndex(['tags', 'populartags']);
  const imageIdx = findIndex(['image', 'photo', 'picture', 'bgimage']);

  const flights: Omit<FlightDeal, 'id'>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const row = parseCsvRow(lines[i]);
    if (row.length === 0 || row.every(val => val === '')) continue;

    const getVal = (idx: number, fallback: string = '') => (idx >= 0 && row[idx] ? row[idx] : fallback);

    const airline = getVal(airlineIdx, 'Indigo');
    const from = getVal(fromIdx, 'New Delhi');
    const to = getVal(toIdx, 'Dubai');
    const fromCode = getVal(fromCodeIdx, from.slice(0, 3).toUpperCase());
    const toCode = getVal(toCodeIdx, to.slice(0, 3).toUpperCase());
    const rawPrice = getVal(priceIdx, '₹18,500');
    const price = rawPrice.startsWith('₹') 
      ? rawPrice 
      : rawPrice.startsWith('$') 
        ? rawPrice.replace('$', '₹') 
        : `₹${rawPrice}`;
    const duration = getVal(durationIdx, '3h 30m');
    const type = getVal(typeIdx, 'Non-stop');
    const rawDate = getVal(flightDateIdx, '');
    const flightDate = rawDate ? normalizeDateString(rawDate) : '';
    const rawTags = getVal(tagsIdx, 'Best Seller, Quick Flight');
    const popularTags = rawTags ? rawTags.split(';').flatMap(t => t.split(',')).map(t => t.trim()).filter(Boolean) : ['CSV Import'];
    
    let airlineLogo = getVal(airlineLogoIdx, '');
    if (!airlineLogo) {
      airlineLogo = `https://logo.clearbit.com/${airline.toLowerCase().replace(/\s+/g, '')}.com`;
    }

    let image = getVal(imageIdx, '');
    if (!image) {
      image = 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=800&auto=format&fit=crop';
    }

    flights.push({
      airline,
      airlineLogo,
      from,
      fromCode,
      to,
      toCode,
      price,
      duration,
      type,
      flightDate,
      popularTags,
      image
    });
  }

  return flights;
}

/**
 * Generates sample CSV string for users to download
 */
export function generateSampleFlightCsv(): string {
  const headers = ['Airline', 'AirlineLogo', 'From', 'FromCode', 'To', 'ToCode', 'Price', 'Duration', 'Type', 'FlightDate', 'PopularTags', 'Image'];
  
  const today = new Date();
  const addDays = (d: number) => {
    const next = new Date(today);
    next.setDate(today.getDate() + d);
    const year = next.getFullYear();
    const month = String(next.getMonth() + 1).padStart(2, '0');
    const day = String(next.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const rows = [
    ['Emirates', 'https://logo.clearbit.com/emirates.com', 'New Delhi', 'DEL', 'Dubai', 'DXB', '₹22,499*', '3h 50m', 'Non-stop', addDays(1), 'Popular, Luxury Service', 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=800&auto=format&fit=crop'],
    ['Singapore Airlines', 'https://logo.clearbit.com/singaporeair.com', 'Mumbai', 'BOM', 'Singapore', 'SIN', '₹28,900*', '5h 15m', 'Non-stop', addDays(3), '5-Star Airline, Family Choice', 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?q=80&w=800&auto=format&fit=crop'],
    ['British Airways', 'https://logo.clearbit.com/britishairways.com', 'New Delhi', 'DEL', 'London', 'LHR', '₹54,200*', '9h 10m', 'Direct', addDays(5), 'Europe Best, Free Extra Baggage', 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=800&auto=format&fit=crop'],
    ['Qatar Airways', 'https://logo.clearbit.com/qatarairways.com', 'Bengaluru', 'BLR', 'Paris', 'CDG', '₹48,800*', '11h 25m', '1 Stop', addDays(8), 'Award Winning, Best Business Class', 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=800&auto=format&fit=crop'],
    ['Garuda Indonesia', 'https://logo.clearbit.com/garuda-indonesia.com', 'Mumbai', 'BOM', 'Bali', 'DPS', '₹31,500*', '7h 40m', '1 Stop', addDays(12), 'Honeymoon Route, Tropical Getaway', 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop'],
    ['Air India', 'https://logo.clearbit.com/airindia.com', 'New Delhi', 'DEL', 'New York', 'JFK', '₹68,900*', '15h 30m', 'Non-stop', addDays(15), 'Direct USA Flight, Generous Baggage', 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=800&auto=format&fit=crop']
  ];

  const csvContent = [
    headers.join(','),
    ...rows.map(r => r.map(cell => `"${cell.replace(/"/g, '""')}"`).join(','))
  ].join('\n');

  return csvContent;
}
