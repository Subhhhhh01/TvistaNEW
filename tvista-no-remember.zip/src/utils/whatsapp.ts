// WhatsApp Helper Utilities for Tvista Holidays

export const TVISTA_WHATSAPP_NUMBER = '919830712357';
export const TVISTA_WHATSAPP_DISPLAY = '+91 98307 12357';

export function cleanPhoneNumber(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (!digits) return TVISTA_WHATSAPP_NUMBER;
  // If user entered 10 digits without country code in India, prepend 91
  if (digits.length === 10) {
    return `91${digits}`;
  }
  return digits;
}

export function createWhatsAppUrl(phone: string, text: string): string {
  const cleanPhone = cleanPhoneNumber(phone);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

export function openWhatsAppChat(phone: string, text: string) {
  const url = createWhatsAppUrl(phone, text);
  window.open(url, '_blank', 'noopener,noreferrer');
}

export function buildFlightWhatsAppMessage(flight: {
  airline: string;
  from: string;
  fromCode: string;
  to: string;
  toCode: string;
  price: string;
  type?: string;
}, customer: {
  name: string;
  phone: string;
  email?: string;
  departDate?: string;
  returnDate?: string;
  passengers?: string;
  classType?: string;
  notes?: string;
}): string {
  let msg = `*NEW FLIGHT INQUIRY - TVISTA HOLIDAYS*\n\n`;
  msg += `✈️ *Route:* ${flight.from} (${flight.fromCode}) ➔ ${flight.to} (${flight.toCode})\n`;
  msg += `🏢 *Airline:* ${flight.airline} (${flight.type || 'Flight'})\n`;
  msg += `🏷️ *Est. Fare:* ${flight.price}\n\n`;
  msg += `👤 *Customer Name:* ${customer.name}\n`;
  msg += `📞 *Phone:* ${customer.phone}\n`;
  if (customer.email) msg += `📧 *Email:* ${customer.email}\n`;
  if (customer.departDate) msg += `📅 *Departure Date:* ${customer.departDate}\n`;
  if (customer.returnDate) msg += `🔄 *Return Date:* ${customer.returnDate}\n`;
  if (customer.passengers) msg += `👥 *Passengers:* ${customer.passengers}\n`;
  if (customer.classType) msg += `💺 *Cabin Class:* ${customer.classType}\n`;
  if (customer.notes) msg += `💬 *Notes:* ${customer.notes}\n`;
  msg += `\nPlease provide best available fares and flight options. Thank you!`;
  return msg;
}

export function buildPackageWhatsAppMessage(pkg: {
  title: string;
  duration?: string;
  price?: string;
  location?: string;
}, customer: {
  name: string;
  phone: string;
  email?: string;
  travelDate?: string;
  travelers?: string;
  notes?: string;
}): string {
  let msg = `*HOLIDAY PACKAGE INQUIRY - TVISTA HOLIDAYS*\n\n`;
  msg += `🏝️ *Package:* ${pkg.title}\n`;
  if (pkg.location) msg += `📍 *Destination:* ${pkg.location}\n`;
  if (pkg.duration) msg += `⏱️ *Duration:* ${pkg.duration}\n`;
  if (pkg.price) msg += `💰 *Price:* ${pkg.price}\n\n`;
  msg += `👤 *Customer Name:* ${customer.name}\n`;
  msg += `📞 *Phone:* ${customer.phone}\n`;
  if (customer.email) msg += `📧 *Email:* ${customer.email}\n`;
  if (customer.travelDate) msg += `📅 *Preferred Travel Date:* ${customer.travelDate}\n`;
  if (customer.travelers) msg += `👥 *Travelers:* ${customer.travelers}\n`;
  if (customer.notes) msg += `💬 *Special Requests:* ${customer.notes}\n`;
  msg += `\nPlease send customized itinerary options and details. Thank you!`;
  return msg;
}

export function buildVisaWhatsAppMessage(visa: {
  name: string;
  types?: string[];
  fee?: string;
  processingTime?: string;
}, customer: {
  name: string;
  phone: string;
  email?: string;
  travelDate?: string;
  nationality?: string;
  notes?: string;
}): string {
  let msg = `*VISA ASSISTANCE INQUIRY - TVISTA HOLIDAYS*\n\n`;
  msg += `🛂 *Country:* ${visa.name} Visa Assistance\n`;
  if (visa.fee) msg += `💵 *Est. Fee:* ${visa.fee}\n`;
  if (visa.processingTime) msg += `⏱️ *Processing Time:* ${visa.processingTime}\n\n`;
  msg += `👤 *Customer Name:* ${customer.name}\n`;
  msg += `📞 *Phone:* ${customer.phone}\n`;
  if (customer.email) msg += `📧 *Email:* ${customer.email}\n`;
  if (customer.travelDate) msg += `📅 *Travel Date:* ${customer.travelDate}\n`;
  if (customer.nationality) msg += `🛂 *Passport / Nationality:* ${customer.nationality}\n`;
  if (customer.notes) msg += `💬 *Notes:* ${customer.notes}\n`;
  msg += `\nPlease provide document checklist and visa appointment guidance. Thank you!`;
  return msg;
}

export function buildGeneralWhatsAppMessage(customer: {
  name: string;
  phone?: string;
  email?: string;
  message: string;
}): string {
  let msg = `*GENERAL TRAVEL INQUIRY - TVISTA HOLIDAYS*\n\n`;
  msg += `👤 *Customer Name:* ${customer.name}\n`;
  if (customer.phone) msg += `📞 *Phone:* ${customer.phone}\n`;
  if (customer.email) msg += `📧 *Email:* ${customer.email}\n`;
  msg += `💬 *Message:* ${customer.message}\n\n`;
  msg += `Hello Tvista Holidays, I would like to get assistance for my travel plans.`;
  return msg;
}

export function buildAdminWhatsAppReplyMessage(enquiry: {
  name: string;
  titleOrSubject?: string;
  type: string;
}): string {
  const greeting = `Hello ${enquiry.name || 'there'}! 👋\n\nGreetings from *Tvista Holidays*! 🌟\n\nWe received your inquiry regarding *${enquiry.titleOrSubject || enquiry.type.toUpperCase() + ' Booking'}*. Our travel specialist is ready to assist you with flight fares, package customization, and visa support.\n\nHow can we help you today?`;
  return greeting;
}
