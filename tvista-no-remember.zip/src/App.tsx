import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import WhatsAppButton from './components/WhatsAppButton';
import Home from './pages/Home';
import DestinationsPage from './pages/DestinationsPage';
import PackagesPage from './pages/PackagesPage';
import PromoPage from './pages/PromoPage';
import NewsPage from './pages/NewsPage';
import FlightPage from './pages/FlightPage';
import VisaPage from './pages/VisaPage';
import GalleryPage from './pages/GalleryPage';
import ContactPage from './pages/ContactPage';
import AdminPage from './pages/AdminPage';
import { DataProvider } from './context/DataContext';

export default function App() {
  return (
    <DataProvider>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/destinations" element={<DestinationsPage />} />
          <Route path="/packages" element={<PackagesPage />} />
          <Route path="/promos" element={<PromoPage />} />
          <Route path="/promo" element={<PromoPage />} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/flights" element={<FlightPage />} />
          <Route path="/visa" element={<VisaPage />} />
          <Route path="/gallery" element={<GalleryPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/admin" element={<AdminPage />} />
        </Routes>
        <WhatsAppButton />
      </Router>
    </DataProvider>
  );
}

