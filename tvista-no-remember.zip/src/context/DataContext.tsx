import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { PACKAGES, Package } from '../data/packagesData';
import { FlightDeal } from '../components/FlightModal';
import { parseFlightCsv, isFlightExpired } from '../utils/csvParser';
import { DestinationItem, DEFAULT_DESTINATIONS } from '../data/destinationsData';
import { 
  HomeHeroSlide, 
  HomeFeaturedEscape, 
  TestimonialItem,
  HomeSettings, 
  DEFAULT_HERO_SLIDES, 
  DEFAULT_FEATURED_ESCAPES, 
  DEFAULT_TESTIMONIALS,
  DEFAULT_HOME_SETTINGS 
} from '../data/homeData';
import { PromoOffer, PROMO_OFFERS } from '../data/promosData';
import { NewsArticle, NEWS_ARTICLES } from '../data/newsData';
import { GalleryItemType, DEFAULT_GALLERY_ITEMS } from '../data/galleryData';

export interface AirlinePartner {
  name: string;
  country: string;
  rating: string;
  logo: string;
  domain: string;
  region: string;
  perks: string;
}

export interface VisaCountryItem {
  name: string;
  code: string;
  types: string[];
  processingTime: string;
  fee: string;
  details: string;
  flagUrl?: string;
}

const DEFAULT_FLIGHT_DEALS: FlightDeal[] = [
  {
    id: 'f1',
    airline: 'Emirates',
    airlineLogo: 'https://logo.clearbit.com/emirates.com',
    from: 'New Delhi',
    fromCode: 'DEL',
    to: 'Dubai',
    toCode: 'DXB',
    price: '₹22,499*',
    duration: '3h 50m',
    type: 'Non-stop',
    flightDate: '2026-08-08',
    popularTags: ['Popular', 'Luxury Service'],
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'f2',
    airline: 'Singapore Airlines',
    airlineLogo: 'https://logo.clearbit.com/singaporeair.com',
    from: 'Mumbai',
    fromCode: 'BOM',
    to: 'Singapore',
    toCode: 'SIN',
    price: '₹28,900*',
    duration: '5h 15m',
    type: 'Non-stop',
    flightDate: '2026-08-10',
    popularTags: ['5-Star Airline', 'Family Choice'],
    image: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'f3',
    airline: 'British Airways',
    airlineLogo: 'https://logo.clearbit.com/britishairways.com',
    from: 'New Delhi',
    fromCode: 'DEL',
    to: 'London',
    toCode: 'LHR',
    price: '₹54,200*',
    duration: '9h 10m',
    type: 'Direct',
    flightDate: '2026-08-12',
    popularTags: ['Europe Best', 'Free Extra Baggage'],
    image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'f4',
    airline: 'Qatar Airways',
    airlineLogo: 'https://logo.clearbit.com/qatarairways.com',
    from: 'Bengaluru',
    fromCode: 'BLR',
    to: 'Paris',
    toCode: 'CDG',
    price: '₹48,800*',
    duration: '11h 25m',
    type: '1 Stop',
    flightDate: '2026-08-15',
    popularTags: ['Award Winning', 'Best Business Class'],
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'f5',
    airline: 'Garuda Indonesia',
    airlineLogo: 'https://logo.clearbit.com/garuda-indonesia.com',
    from: 'Mumbai',
    fromCode: 'BOM',
    to: 'Bali',
    toCode: 'DPS',
    price: '₹31,500*',
    duration: '7h 40m',
    type: '1 Stop',
    flightDate: '2026-08-18',
    popularTags: ['Honeymoon Route', 'Tropical Getaway'],
    image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'f6',
    airline: 'Air India',
    airlineLogo: 'https://logo.clearbit.com/airindia.com',
    from: 'New Delhi',
    fromCode: 'DEL',
    to: 'New York',
    toCode: 'JFK',
    price: '₹68,900*',
    duration: '15h 30m',
    type: 'Non-stop',
    flightDate: '2026-08-20',
    popularTags: ['Direct USA Flight', 'Generous Baggage'],
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=800&auto=format&fit=crop'
  }
];

const DEFAULT_AIRLINE_PARTNERS: AirlinePartner[] = [
  { name: 'Emirates', country: 'UAE', rating: '5.0 ★', logo: 'https://logo.clearbit.com/emirates.com', domain: 'emirates.com', region: 'Middle East', perks: 'First Class Suites & Chauffeur Drive' },
  { name: 'Singapore Airlines', country: 'Singapore', rating: '5.0 ★', logo: 'https://logo.clearbit.com/singaporeair.com', domain: 'singaporeair.com', region: 'Asia Pacific', perks: 'World’s Best Cabin Crew & KrisWorld' },
  { name: 'Qatar Airways', country: 'Qatar', rating: '5.0 ★', logo: 'https://logo.clearbit.com/qatarairways.com', domain: 'qatarairways.com', region: 'Middle East', perks: 'Qsuite Business Class & Hamad Lounge' },
  { name: 'Etihad Airways', country: 'UAE', rating: '4.8 ★', logo: 'https://logo.clearbit.com/etihad.com', domain: 'etihad.com', region: 'Middle East', perks: 'Abu Dhabi Hub Transit & Premium Service' },
  { name: 'Air India', country: 'India', rating: '4.5 ★', logo: 'https://logo.clearbit.com/airindia.com', domain: 'airindia.com', region: 'Asia Pacific', perks: 'Non-stop USA & Europe Direct Flights' },
  { name: 'Lufthansa', country: 'Germany', rating: '4.7 ★', logo: 'https://logo.clearbit.com/lufthansa.com', domain: 'lufthansa.com', region: 'Europe & Americas', perks: 'Frankfurt/Munich Seamless Connections' },
  { name: 'British Airways', country: 'UK', rating: '4.6 ★', logo: 'https://logo.clearbit.com/britishairways.com', domain: 'britishairways.com', region: 'Europe & Americas', perks: 'London Heathrow Terminal 5 Priority' },
  { name: 'Cathay Pacific', country: 'Hong Kong', rating: '4.8 ★', logo: 'https://logo.clearbit.com/cathaypacific.com', domain: 'cathaypacific.com', region: 'Asia Pacific', perks: 'Premium Economy & Dragonair Network' },
  { name: 'Thai Airways', country: 'Thailand', rating: '4.6 ★', logo: 'https://logo.clearbit.com/thaiairways.com', domain: 'thaiairways.com', region: 'Asia Pacific', perks: 'Royal Silk Business & Island Transit' },
  { name: 'Turkish Airlines', country: 'Turkey', rating: '4.8 ★', logo: 'https://logo.clearbit.com/turkishairlines.com', domain: 'turkishairlines.com', region: 'Europe & Americas', perks: 'Fly To More Countries Than Any Airline' },
  { name: 'Qantas', country: 'Australia', rating: '4.7 ★', logo: 'https://logo.clearbit.com/qantas.com', domain: 'qantas.com', region: 'Asia Pacific', perks: 'Non-stop Australia Routes & Lounges' },
  { name: 'Malaysia Airlines', country: 'Malaysia', rating: '4.5 ★', logo: 'https://logo.clearbit.com/malaysiaairlines.com', domain: 'malaysiaairlines.com', region: 'Asia Pacific', perks: 'KLIA Hub & Hospitality Focus' }
];

const DEFAULT_VISA_COUNTRIES: VisaCountryItem[] = [
  {
    name: 'United States',
    code: 'us',
    types: ['B1/B2 Tourist/Business', 'F1 Student Visa', 'H1B Work Visa'],
    processingTime: '4-6 Weeks',
    fee: 'From ₹15,500',
    details: 'Interview required for first-time applicants. Extensive documentation needed.',
  },
  {
    name: 'United Kingdom',
    code: 'gb',
    types: ['Standard Visitor Visa', 'Student Visa', 'Skilled Worker'],
    processingTime: '3-4 Weeks',
    fee: 'From ₹12,000',
    details: 'Biometrics appointment mandatory. Financial proof is strictly checked.',
  },
  {
    name: 'Schengen Area',
    code: 'eu',
    types: ['Tourist Visa (Type C)', 'Business Visa', 'Transit'],
    processingTime: '2-3 Weeks',
    fee: 'From ₹7,800',
    details: 'Covers 27 European countries. Travel insurance required.',
  },
  {
    name: 'Australia',
    code: 'au',
    types: ['Visitor Visa (Subclass 600)', 'eVisitor', 'ETA'],
    processingTime: '1-4 Weeks',
    fee: 'From ₹9,500',
    details: 'Online application available for Indian passport holders.',
  },
  {
    name: 'Japan',
    code: 'jp',
    types: ['Short-Term Stay', 'Work Visa', 'Student'],
    processingTime: '1-2 Weeks',
    fee: 'From ₹2,500',
    details: 'E-visa available for qualified Indian tourists. Detailed itinerary required.',
  },
  {
    name: 'United Arab Emirates',
    code: 'ae',
    types: ['Tourist Visa (30/60 Days)', 'Transit Visa', 'Golden Visa'],
    processingTime: '3-5 Days',
    fee: 'From ₹6,500',
    details: 'Fast-track processing available. Can be sponsored by airlines.',
  },
  {
    name: 'Canada',
    code: 'ca',
    types: ['Visitor Visa', 'Study Permit', 'eTA'],
    processingTime: '2-4 Weeks',
    fee: 'From ₹6,800',
    details: 'Biometrics usually required. Online application is the fastest method.',
  },
  {
    name: 'New Zealand',
    code: 'nz',
    types: ['Visitor Visa', 'NZeTA', 'Student Visa'],
    processingTime: '2-4 Weeks',
    fee: 'From ₹12,500',
    details: 'Online application available. International Visitor Conservation levy applies.',
  },
  {
    name: 'Singapore',
    code: 'sg',
    types: ['Tourist Visa', 'e-Visa', 'Business Visa'],
    processingTime: '3-5 Days',
    fee: 'From ₹2,200',
    details: 'SG Arrival Card must be completed within 3 days before arrival.',
  },
  {
    name: 'China',
    code: 'cn',
    types: ['L Visa (Tourist)', 'M Visa (Business)', 'X Visa (Student)'],
    processingTime: '1-2 Weeks',
    fee: 'From ₹5,500',
    details: 'Biometrics required at VFS center. Detailed itinerary needed.',
  },
  {
    name: 'India (Domestic / OCI)',
    code: 'in',
    types: ['OCI Card', 'Entry Visa', 'Domestic Assistance'],
    processingTime: '3-5 Days',
    fee: 'From ₹1,500',
    details: 'Assistance for OCI registration, re-issue, and domestic travel documentation.',
  },
  {
    name: 'South Korea',
    code: 'kr',
    types: ['C-3 Tourist Visa', 'Student Visa', 'Business Visa'],
    processingTime: '1-2 Weeks',
    fee: 'From ₹3,500',
    details: 'Visa application submitted via designated VFS centers in India.',
  },
  {
    name: 'Turkey',
    code: 'tr',
    types: ['e-Visa', 'Sticker Visa', 'Transit'],
    processingTime: '1-3 Days',
    fee: 'From ₹4,200',
    details: 'Instant e-visa for valid US/UK/Schengen visa holders.',
  }
];

interface DataContextType {
  packages: Package[];
  flightDeals: FlightDeal[];
  activeFlightDeals: FlightDeal[];
  airlinePartners: AirlinePartner[];
  visaCountries: VisaCountryItem[];
  destinations: DestinationItem[];
  homeHeroCards: HomeHeroSlide[];
  homeFeaturedEscapes: HomeFeaturedEscape[];
  testimonials: TestimonialItem[];
  homeSettings: HomeSettings;
  promos: PromoOffer[];
  newsArticles: NewsArticle[];
  galleryItems: GalleryItemType[];
  
  // Package actions
  addPackage: (pkg: Omit<Package, 'id'>) => void;
  updatePackage: (id: number, pkg: Partial<Package>) => void;
  deletePackage: (id: number | string) => void;

  // Flight actions
  addFlightDeal: (deal: Omit<FlightDeal, 'id'>) => void;
  updateFlightDeal: (id: string, deal: Partial<FlightDeal>) => void;
  deleteFlightDeal: (id: string) => void;
  uploadFlightCsvData: (csvText: string, appendMode?: boolean) => { count: number; activeCount: number; expiredCount: number };
  purgeExpiredFlights: () => number;

  addAirlinePartner: (partner: AirlinePartner) => void;
  updateAirlinePartner: (name: string, partner: Partial<AirlinePartner>) => void;
  deleteAirlinePartner: (name: string) => void;

  // Visa actions
  addVisaCountry: (visa: VisaCountryItem) => void;
  updateVisaCountry: (code: string, visa: Partial<VisaCountryItem>) => void;
  deleteVisaCountry: (code: string) => void;

  // Destination actions
  addDestination: (dest: Omit<DestinationItem, 'id'>) => void;
  updateDestination: (id: number | string, dest: Partial<DestinationItem>) => void;
  deleteDestination: (id: number | string) => void;

  // Home actions
  addHomeHeroCard: (card: Omit<HomeHeroSlide, 'id'>) => void;
  updateHomeHeroCard: (id: number | string, card: Partial<HomeHeroSlide>) => void;
  deleteHomeHeroCard: (id: number | string) => void;
  addHomeFeaturedEscape: (escape: HomeFeaturedEscape) => void;
  updateHomeFeaturedEscape: (id: string, escape: Partial<HomeFeaturedEscape>) => void;
  deleteHomeFeaturedEscape: (id: string) => void;

  // Testimonials actions
  addTestimonial: (item: TestimonialItem) => void;
  updateTestimonial: (id: string, item: Partial<TestimonialItem>) => void;
  deleteTestimonial: (id: string) => void;

  updateHomeSettings: (settings: Partial<HomeSettings>) => void;

  // Promo actions
  addPromo: (promo: PromoOffer) => void;
  updatePromo: (id: string, promo: Partial<PromoOffer>) => void;
  deletePromo: (id: string) => void;

  // News actions
  addNewsArticle: (article: NewsArticle) => void;
  updateNewsArticle: (id: string, article: Partial<NewsArticle>) => void;
  deleteNewsArticle: (id: string) => void;

  // Gallery actions
  addGalleryItem: (item: Omit<GalleryItemType, 'id'>) => void;
  updateGalleryItem: (id: number | string, item: Partial<GalleryItemType>) => void;
  deleteGalleryItem: (id: number | string) => void;

  // Admin / Backup utilities
  resetToDefaults: () => void;
  exportDataJson: () => string;
  importDataJson: (jsonString: string) => boolean;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [packages, setPackages] = useState<Package[]>([]);
  const [flightDeals, setFlightDeals] = useState<FlightDeal[]>(DEFAULT_FLIGHT_DEALS);
  const [airlinePartners, setAirlinePartners] = useState<AirlinePartner[]>(DEFAULT_AIRLINE_PARTNERS);
  const [visaCountries, setVisaCountries] = useState<VisaCountryItem[]>(DEFAULT_VISA_COUNTRIES);
  const [destinations, setDestinations] = useState<DestinationItem[]>(DEFAULT_DESTINATIONS);
  const [homeHeroCards, setHomeHeroCards] = useState<HomeHeroSlide[]>(DEFAULT_HERO_SLIDES);
  const [homeFeaturedEscapes, setHomeFeaturedEscapes] = useState<HomeFeaturedEscape[]>(DEFAULT_FEATURED_ESCAPES);
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>(DEFAULT_TESTIMONIALS);
  const [homeSettings, setHomeSettings] = useState<HomeSettings>(DEFAULT_HOME_SETTINGS);
  const [promos, setPromos] = useState<PromoOffer[]>(PROMO_OFFERS);
  const [newsArticles, setNewsArticles] = useState<NewsArticle[]>(NEWS_ARTICLES);
  const [galleryItems, setGalleryItems] = useState<GalleryItemType[]>(DEFAULT_GALLERY_ITEMS);

  const [isInitialized, setIsInitialized] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  // Load website data from MySQL on mount
  useEffect(() => {
    const loadFromMySql = async () => {
      try {
        const res = await fetch('/api/website-data');
        const result = await res.json();
        if (result.success && result.exists && result.data) {
          const d = result.data;
          if (d.packages && Array.isArray(d.packages)) setPackages(d.packages);
          if (d.flightDeals && Array.isArray(d.flightDeals)) setFlightDeals(d.flightDeals);
          if (d.airlinePartners && Array.isArray(d.airlinePartners)) setAirlinePartners(d.airlinePartners);
          if (d.visaCountries && Array.isArray(d.visaCountries)) setVisaCountries(d.visaCountries);
          if (d.destinations && Array.isArray(d.destinations)) setDestinations(d.destinations);
          if (d.homeHeroCards && Array.isArray(d.homeHeroCards)) setHomeHeroCards(d.homeHeroCards);
          if (d.homeFeaturedEscapes && Array.isArray(d.homeFeaturedEscapes)) setHomeFeaturedEscapes(d.homeFeaturedEscapes);
          if (d.testimonials && Array.isArray(d.testimonials)) setTestimonials(d.testimonials);
          if (d.homeSettings && typeof d.homeSettings === 'object') setHomeSettings(d.homeSettings);
          if (d.promos && Array.isArray(d.promos)) setPromos(d.promos);
          if (d.newsArticles && Array.isArray(d.newsArticles)) setNewsArticles(d.newsArticles);
          if (d.galleryItems && Array.isArray(d.galleryItems)) setGalleryItems(d.galleryItems);
          console.log('Successfully synchronized database settings with MySQL.');
        }
      } catch (err) {
        console.error('Failed to load website configuration from MySQL, using local fallback:', err);
      } finally {
        setIsInitialized(true);
      }
    };
    loadFromMySql();
  }, []);

  // Sync changes directly to MySQL in real-time
  useEffect(() => {
    if (!isInitialized || !hasChanges) return;

    const token = sessionStorage.getItem('tvista_admin_token') || localStorage.getItem('tvista_admin_token');
    if (!token) return;

    const syncData = async () => {
      try {
        const res = await fetch('/api/website-data', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            packages,
            flightDeals,
            airlinePartners,
            visaCountries,
            destinations,
            homeHeroCards,
            homeFeaturedEscapes,
            testimonials,
            homeSettings,
            promos,
            newsArticles,
            galleryItems
          })
        });
        const result = await res.json();
        if (result.success) {
          setHasChanges(false);
          console.log('Successfully synchronized database settings with MySQL.');
        } else {
          console.error('Failed to sync general database changes to MySQL:', result.message);
        }
      } catch (err) {
        console.error('Failed to sync general database changes to MySQL:', err);
      }
    };

    const delayDebounceFn = setTimeout(() => {
      syncData();
    }, 1000);

    return () => clearTimeout(delayDebounceFn);
  }, [
    isInitialized,
    hasChanges,
    packages,
    flightDeals,
    airlinePartners,
    visaCountries,
    destinations,
    homeHeroCards,
    homeFeaturedEscapes,
    testimonials,
    homeSettings,
    promos,
    newsArticles,
    galleryItems
  ]);

  // localStorage removed — all data is stored in MySQL only

  // Package handlers
  const addPackage = (newPkg: Omit<Package, 'id'>) => {
    const nextId = packages.length > 0 ? Math.max(...packages.map(p => p.id)) + 1 : 1;
    setPackages(prev => [{ ...newPkg, id: nextId }, ...prev]);
    setHasChanges(true);
  };

  const updatePackage = (id: number, updatedFields: Partial<Package>) => {
    setPackages(prev => prev.map(p => p.id === id ? { ...p, ...updatedFields } : p));
    setHasChanges(true);
  };

  const deletePackage = (id: number | string) => {
    setPackages(prev => prev.filter(p => String(p.id) !== String(id)));
    setHasChanges(true);
  };

  // Computed active non-expired flights
  const activeFlightDeals = useMemo(() => {
    return flightDeals.filter(f => !isFlightExpired(f.flightDate));
  }, [flightDeals]);

  // Flight Deal handlers
  const addFlightDeal = (newDeal: Omit<FlightDeal, 'id'>) => {
    const nextId = `f_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    setFlightDeals(prev => [{ ...newDeal, id: nextId }, ...prev]);
    setHasChanges(true);
  };

  const updateFlightDeal = (id: string, updatedFields: Partial<FlightDeal>) => {
    setFlightDeals(prev => prev.map(f => f.id === id ? { ...f, ...updatedFields } : f));
    setHasChanges(true);
  };

  const deleteFlightDeal = (id: string) => {
    setFlightDeals(prev => prev.filter(f => f.id !== id));
    setHasChanges(true);
  };

  const uploadFlightCsvData = (csvText: string, appendMode: boolean = false) => {
    const parsedDeals = parseFlightCsv(csvText);
    if (parsedDeals.length === 0) {
      return { count: 0, activeCount: 0, expiredCount: 0 };
    }

    const formattedDeals: FlightDeal[] = parsedDeals.map((deal, idx) => ({
      ...deal,
      id: `csv_f_${Date.now()}_${idx}`
    }));

    let activeCount = 0;
    let expiredCount = 0;
    formattedDeals.forEach(f => {
      if (isFlightExpired(f.flightDate)) {
        expiredCount++;
      } else {
        activeCount++;
      }
    });

    if (appendMode) {
      setFlightDeals(prev => [...formattedDeals, ...prev]);
    } else {
      setFlightDeals(formattedDeals);
    }

    setHasChanges(true);

    return {
      count: formattedDeals.length,
      activeCount,
      expiredCount
    };
  };

  const purgeExpiredFlights = () => {
    const active = flightDeals.filter(f => !isFlightExpired(f.flightDate));
    const purgedCount = flightDeals.length - active.length;
    setFlightDeals(active);
    setHasChanges(true);
    return purgedCount;
  };

  // Airline Partner handlers
  const addAirlinePartner = (partner: AirlinePartner) => {
    setAirlinePartners(prev => [partner, ...prev]);
    setHasChanges(true);
  };

  const updateAirlinePartner = (name: string, updatedFields: Partial<AirlinePartner>) => {
    setAirlinePartners(prev => prev.map(ap => ap.name === name ? { ...ap, ...updatedFields } : ap));
    setHasChanges(true);
  };

  const deleteAirlinePartner = (name: string) => {
    setAirlinePartners(prev => prev.filter(ap => ap.name !== name));
    setHasChanges(true);
  };

  // Visa handlers
  const addVisaCountry = (visa: VisaCountryItem) => {
    setVisaCountries(prev => [visa, ...prev]);
    setHasChanges(true);
  };

  const updateVisaCountry = (code: string, updatedFields: Partial<VisaCountryItem>) => {
    setVisaCountries(prev => prev.map(v => v.code === code ? { ...v, ...updatedFields } : v));
    setHasChanges(true);
  };

  const deleteVisaCountry = (code: string) => {
    setVisaCountries(prev => prev.filter(v => v.code !== code));
    setHasChanges(true);
  };

  // Destination handlers
  const addDestination = (dest: Omit<DestinationItem, 'id'>) => {
    const nextId = destinations.length > 0 ? Math.max(...destinations.map(d => Number(d.id) || 0)) + 1 : 1;
    setDestinations(prev => [{ ...dest, id: nextId }, ...prev]);
    setHasChanges(true);
  };

  const updateDestination = (id: number | string, updatedFields: Partial<DestinationItem>) => {
    setDestinations(prev => prev.map(d => String(d.id) === String(id) ? { ...d, ...updatedFields } : d));
    setHasChanges(true);
  };

  const deleteDestination = (id: number | string) => {
    setDestinations(prev => prev.filter(d => String(d.id) !== String(id)));
    setHasChanges(true);
  };

  // Home handlers
  const addHomeHeroCard = (card: Omit<HomeHeroSlide, 'id'>) => {
    const nextId = homeHeroCards.length > 0 ? Math.max(...homeHeroCards.map(c => Number(c.id) || 0)) + 1 : 1;
    setHomeHeroCards(prev => [...prev, { ...card, id: nextId }]);
    setHasChanges(true);
  };

  const updateHomeHeroCard = (id: number | string, card: Partial<HomeHeroSlide>) => {
    setHomeHeroCards(prev => prev.map(c => String(c.id) === String(id) ? { ...c, ...card } : c));
    setHasChanges(true);
  };

  const deleteHomeHeroCard = (id: number | string) => {
    setHomeHeroCards(prev => prev.filter(c => String(c.id) !== String(id)));
    setHasChanges(true);
  };

  const addHomeFeaturedEscape = (escape: HomeFeaturedEscape) => {
    setHomeFeaturedEscapes(prev => [...prev, escape]);
    setHasChanges(true);
  };

  const updateHomeFeaturedEscape = (id: string, escape: Partial<HomeFeaturedEscape>) => {
    setHomeFeaturedEscapes(prev => prev.map(e => e.id === id ? { ...e, ...escape } : e));
    setHasChanges(true);
  };

  const deleteHomeFeaturedEscape = (id: string) => {
    setHomeFeaturedEscapes(prev => prev.filter(e => e.id !== id));
    setHasChanges(true);
  };

  // Testimonials handlers
  const addTestimonial = (item: TestimonialItem) => {
    setTestimonials(prev => [...prev, item]);
    setHasChanges(true);
  };

  const updateTestimonial = (id: string, item: Partial<TestimonialItem>) => {
    setTestimonials(prev => prev.map(t => t.id === id ? { ...t, ...item } : t));
    setHasChanges(true);
  };

  const deleteTestimonial = (id: string) => {
    setTestimonials(prev => prev.filter(t => t.id !== id));
    setHasChanges(true);
  };

  const updateHomeSettings = (settings: Partial<HomeSettings>) => {
    setHomeSettings(prev => ({ ...prev, ...settings }));
    setHasChanges(true);
  };

  // Promo handlers
  const addPromo = (promo: PromoOffer) => {
    setPromos(prev => [promo, ...prev]);
    setHasChanges(true);
  };

  const updatePromo = (id: string, promo: Partial<PromoOffer>) => {
    setPromos(prev => prev.map(p => p.id === id ? { ...p, ...promo } : p));
    setHasChanges(true);
  };

  const deletePromo = (id: string) => {
    setPromos(prev => prev.filter(p => p.id !== id));
    setHasChanges(true);
  };

  // News handlers
  const addNewsArticle = (article: NewsArticle) => {
    setNewsArticles(prev => [article, ...prev]);
    setHasChanges(true);
  };

  const updateNewsArticle = (id: string, article: Partial<NewsArticle>) => {
    setNewsArticles(prev => prev.map(a => a.id === id ? { ...a, ...article } : a));
    setHasChanges(true);
  };

  const deleteNewsArticle = (id: string) => {
    setNewsArticles(prev => prev.filter(a => a.id !== id));
    setHasChanges(true);
  };

  // Gallery handlers
  const addGalleryItem = (item: Omit<GalleryItemType, 'id'>) => {
    const nextId = galleryItems.length > 0 ? Math.max(...galleryItems.map(g => Number(g.id) || 0)) + 1 : 1;
    setGalleryItems(prev => [{ ...item, id: nextId }, ...prev]);
    setHasChanges(true);
  };

  const updateGalleryItem = (id: number | string, item: Partial<GalleryItemType>) => {
    setGalleryItems(prev => prev.map(g => String(g.id) === String(id) ? { ...g, ...item } : g));
    setHasChanges(true);
  };

  const deleteGalleryItem = (id: number | string) => {
    setGalleryItems(prev => prev.filter(g => String(g.id) !== String(id)));
    setHasChanges(true);
  };

  // Utilities
  const resetToDefaults = () => {
    setPackages(PACKAGES);
    setFlightDeals(DEFAULT_FLIGHT_DEALS);
    setAirlinePartners(DEFAULT_AIRLINE_PARTNERS);
    setVisaCountries(DEFAULT_VISA_COUNTRIES);
    setDestinations(DEFAULT_DESTINATIONS);
    setHomeHeroCards(DEFAULT_HERO_SLIDES);
    setHomeFeaturedEscapes(DEFAULT_FEATURED_ESCAPES);
    setTestimonials(DEFAULT_TESTIMONIALS);
    setHomeSettings(DEFAULT_HOME_SETTINGS);
    setPromos(PROMO_OFFERS);
    setNewsArticles(NEWS_ARTICLES);
    setGalleryItems(DEFAULT_GALLERY_ITEMS);
    localStorage.removeItem(`${STORAGE_KEY}_packages`);
    localStorage.removeItem(`${STORAGE_KEY}_flightDeals`);
    localStorage.removeItem(`${STORAGE_KEY}_airlinePartners`);
    localStorage.removeItem(`${STORAGE_KEY}_visaCountries`);
    localStorage.removeItem(`${STORAGE_KEY}_destinations`);
    localStorage.removeItem(`${STORAGE_KEY}_homeHeroCards`);
    localStorage.removeItem(`${STORAGE_KEY}_homeFeaturedEscapes`);
    localStorage.removeItem(`${STORAGE_KEY}_testimonials`);
    localStorage.removeItem(`${STORAGE_KEY}_homeSettings`);
    localStorage.removeItem(`${STORAGE_KEY}_promos`);
    localStorage.removeItem(`${STORAGE_KEY}_newsArticles`);
    localStorage.removeItem(`${STORAGE_KEY}_galleryItems`);
    setHasChanges(true);
  };

  const exportDataJson = () => {
    const data = {
      packages,
      flightDeals,
      airlinePartners,
      visaCountries,
      destinations,
      homeHeroCards,
      homeFeaturedEscapes,
      testimonials,
      homeSettings,
      promos,
      newsArticles,
      galleryItems,
      exportedAt: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  };

  const importDataJson = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.packages && Array.isArray(parsed.packages)) setPackages(parsed.packages);
      if (parsed.flightDeals && Array.isArray(parsed.flightDeals)) setFlightDeals(parsed.flightDeals);
      if (parsed.airlinePartners && Array.isArray(parsed.airlinePartners)) setAirlinePartners(parsed.airlinePartners);
      if (parsed.visaCountries && Array.isArray(parsed.visaCountries)) setVisaCountries(parsed.visaCountries);
      if (parsed.destinations && Array.isArray(parsed.destinations)) setDestinations(parsed.destinations);
      if (parsed.homeHeroCards && Array.isArray(parsed.homeHeroCards)) setHomeHeroCards(parsed.homeHeroCards);
      if (parsed.homeFeaturedEscapes && Array.isArray(parsed.homeFeaturedEscapes)) setHomeFeaturedEscapes(parsed.homeFeaturedEscapes);
      if (parsed.testimonials && Array.isArray(parsed.testimonials)) setTestimonials(parsed.testimonials);
      if (parsed.homeSettings && typeof parsed.homeSettings === 'object') setHomeSettings(parsed.homeSettings);
      if (parsed.promos && Array.isArray(parsed.promos)) setPromos(parsed.promos);
      if (parsed.newsArticles && Array.isArray(parsed.newsArticles)) setNewsArticles(parsed.newsArticles);
      if (parsed.galleryItems && Array.isArray(parsed.galleryItems)) setGalleryItems(parsed.galleryItems);
      setHasChanges(true);
      return true;
    } catch (e) {
      console.error('Failed to import JSON data', e);
      return false;
    }
  };

  return (
    <DataContext.Provider value={{
      packages,
      flightDeals,
      activeFlightDeals,
      airlinePartners,
      visaCountries,
      destinations,
      homeHeroCards,
      homeFeaturedEscapes,
      testimonials,
      homeSettings,
      promos,
      newsArticles,
      galleryItems,
      addPackage,
      updatePackage,
      deletePackage,
      addFlightDeal,
      updateFlightDeal,
      deleteFlightDeal,
      uploadFlightCsvData,
      purgeExpiredFlights,
      addAirlinePartner,
      updateAirlinePartner,
      deleteAirlinePartner,
      addVisaCountry,
      updateVisaCountry,
      deleteVisaCountry,
      addDestination,
      updateDestination,
      deleteDestination,
      addHomeHeroCard,
      updateHomeHeroCard,
      deleteHomeHeroCard,
      addHomeFeaturedEscape,
      updateHomeFeaturedEscape,
      deleteHomeFeaturedEscape,
      addTestimonial,
      updateTestimonial,
      deleteTestimonial,
      updateHomeSettings,
      addPromo,
      updatePromo,
      deletePromo,
      addNewsArticle,
      updateNewsArticle,
      deleteNewsArticle,
      addGalleryItem,
      updateGalleryItem,
      deleteGalleryItem,
      resetToDefaults,
      exportDataJson,
      importDataJson
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
