// server.ts
import express from "express";
import mysql from "mysql2/promise";
import dotenv from "dotenv";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import crypto from "crypto";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(process.cwd(), ".env"), override: true });
async function startServer() {
  const app = express();
  app.use(express.json({ limit: "25mb" }));
  app.use(express.urlencoded({ extended: true, limit: "25mb" }));
  const poolConfig = {
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 3306,
    database: process.env.DB_NAME || "tvista",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    connectTimeout: 1e4,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  };
  if (process.env.DB_SSL === "true") {
    poolConfig.ssl = {
      rejectUnauthorized: false
    };
  }
  const pool = mysql.createPool(poolConfig);
  let isMySqlConnected = false;
  let mysqlError = null;
  if (!process.env.DB_HOST) {
    console.log("[Database Notice]: DB_HOST environment variable not set. Operating in high-performance Demo Sandbox mode (localStorage sync).");
  } else {
    try {
      const connection = await pool.getConnection();
      console.log("Connected to MySQL database successfully");
      isMySqlConnected = true;
      mysqlError = null;
      await connection.query(`
        CREATE TABLE IF NOT EXISTS website_data (
          id INT PRIMARY KEY,
          data LONGTEXT NOT NULL,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
      `);
      await connection.query(`
        CREATE TABLE IF NOT EXISTS partners (
          id INT AUTO_INCREMENT PRIMARY KEY,
          companyName VARCHAR(255) NOT NULL,
          address1 TEXT NOT NULL,
          address2 TEXT,
          country VARCHAR(255) NOT NULL,
          state VARCHAR(255) NOT NULL,
          city VARCHAR(255) NOT NULL,
          pinCode VARCHAR(50) NOT NULL,
          referredBy VARCHAR(255),
          companyAddressProofDoc LONGTEXT,
          hasGst VARCHAR(50) NOT NULL,
          gstNumber VARCHAR(100),
          gstName VARCHAR(255),
          gstMobile VARCHAR(100),
          gstEmail VARCHAR(255),
          gstCertificateDoc LONGTEXT,
          companyPanNumber VARCHAR(100) NOT NULL,
          companyMonthlySalesVolume VARCHAR(255),
          companyPanHolderName VARCHAR(255) NOT NULL,
          companyPanDoc LONGTEXT,
          firstName VARCHAR(255) NOT NULL,
          lastName VARCHAR(255) NOT NULL,
          personalEmail VARCHAR(255) NOT NULL,
          personalMobile VARCHAR(255) NOT NULL,
          personalAddressProofType VARCHAR(255) NOT NULL,
          personalAddressProofDoc LONGTEXT,
          personalPanNumber VARCHAR(100) NOT NULL,
          personalMonthlySalesVolume VARCHAR(255),
          personalPanHolderName VARCHAR(255) NOT NULL,
          personalPanDoc LONGTEXT,
          submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      connection.release();
    } catch (err) {
      mysqlError = err.message || String(err);
      isMySqlConnected = false;
      console.log("[Database Notice]: Unable to connect to MySQL host (" + (process.env.DB_HOST || "localhost") + "). Operating in Demo Sandbox mode.");
    }
  }
  function generateToken() {
    const secret = process.env.ADMIN_SESSION_SECRET || "fallback_secret";
    const expiresAt = Date.now() + 12 * 60 * 60 * 1e3;
    const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
    const payload = Buffer.from(JSON.stringify({ role: "admin", exp: expiresAt })).toString("base64url");
    const signatureInput = `${header}.${payload}`;
    const signature = crypto.createHmac("sha256", secret).update(signatureInput).digest("base64url");
    return `${header}.${payload}.${signature}`;
  }
  function verifyToken(token) {
    if (!token) return false;
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const [header, payload, signature] = parts;
    const secret = process.env.ADMIN_SESSION_SECRET || "fallback_secret";
    const expectedSignature = crypto.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
    if (signature !== expectedSignature) return false;
    try {
      const decodedPayload = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
      if (Date.now() > decodedPayload.exp) {
        return false;
      }
      return decodedPayload.role === "admin";
    } catch {
      return false;
    }
  }
  const signupLimiter = /* @__PURE__ */ new Map();
  app.get("/api/database-status", (req, res) => {
    res.json({
      success: true,
      connected: isMySqlConnected,
      mode: isMySqlConnected ? "MySQL Production" : "Demo Mode (Local Memory/Storage Fallback)",
      error: mysqlError,
      hasUri: !!process.env.DB_HOST
    });
  });
  app.get("/api/health", (req, res) => {
    res.json({
      ok: true,
      mysqlConnected: isMySqlConnected,
      error: mysqlError
    });
  });
  app.post("/api/admin/login", (req, res) => {
    const { password } = req.body;
    const correctPassword = process.env.ADMIN_PASSWORD || "admin123";
    if (password === correctPassword) {
      const token = generateToken();
      return res.json({ success: true, token });
    }
    return res.status(401).json({ success: false, message: "Incorrect passcode" });
  });
  app.get("/api/website-data", async (req, res) => {
    try {
      if (isMySqlConnected) {
        const [rows] = await pool.query("SELECT data FROM website_data WHERE id = 1");
        if (rows.length === 0) {
          return res.json({ success: true, exists: false, data: null });
        }
        const data = JSON.parse(rows[0].data);
        return res.json({ success: true, exists: true, data });
      }
      return res.json({ success: false, message: "Database not connected", exists: false, data: null });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });
  app.post("/api/website-data", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      const token = authHeader?.startsWith("Bearer ") ? authHeader.substring(7) : void 0;
      if (!verifyToken(token)) {
        return res.status(401).json({ success: false, message: "Unauthorized. Invalid or expired token." });
      }
      if (isMySqlConnected) {
        const body = req.body;
        if (body.packages && Array.isArray(body.packages)) {
          const uploadsDir2 = path.resolve(process.cwd(), "uploads");
          if (!fs.existsSync(uploadsDir2)) fs.mkdirSync(uploadsDir2, { recursive: true });
          body.packages = body.packages.map((pkg) => {
            if (pkg.image && typeof pkg.image === "string" && pkg.image.startsWith("data:")) {
              try {
                const matches = pkg.image.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
                if (matches) {
                  const ext = matches[1].split("/")[1]?.replace("jpeg", "jpg") || "jpg";
                  const fname = `pkg-${pkg.id || Date.now()}.${ext}`;
                  fs.writeFileSync(path.join(uploadsDir2, fname), Buffer.from(matches[2], "base64"));
                  return { ...pkg, image: `/uploads/${fname}` };
                }
              } catch (_) {
              }
            }
            return pkg;
          });
        }
        const payload = JSON.stringify(body);
        await pool.query(
          "INSERT INTO website_data (id, data) VALUES (1, ?) ON DUPLICATE KEY UPDATE data = ?",
          [payload, payload]
        );
        return res.json({ success: true, message: "Website content synchronized with MySQL!", data: body });
      }
      return res.status(503).json({ success: false, message: "Database not connected" });
    } catch (err) {
      res.status(500).json({ success: false, error: err.message });
    }
  });
  const uploadsDir = path.resolve(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
  app.use("/uploads", express.static(uploadsDir));
  app.post("/api/partner/signup", async (req, res) => {
    try {
      const ip = req.ip || req.headers["x-forwarded-for"] || "unknown";
      const now = Date.now();
      const oneHour = 60 * 60 * 1e3;
      const limitInfo = signupLimiter.get(String(ip));
      if (limitInfo) {
        if (now - limitInfo.firstRequestTime < oneHour) {
          if (limitInfo.count >= 5) {
            return res.status(429).json({
              success: false,
              message: "Too many signup requests from this IP. Please try again in an hour."
            });
          }
          limitInfo.count++;
        } else {
          signupLimiter.set(String(ip), { count: 1, firstRequestTime: now });
        }
      } else {
        signupLimiter.set(String(ip), { count: 1, firstRequestTime: now });
      }
      const requiredFields = [
        "companyName",
        "address1",
        "country",
        "state",
        "city",
        "pinCode",
        "hasGst",
        "companyPanNumber",
        "companyPanHolderName",
        "firstName",
        "lastName",
        "personalEmail",
        "personalMobile",
        "personalAddressProofType",
        "personalPanNumber",
        "personalPanHolderName"
      ];
      for (const field of requiredFields) {
        if (!req.body[field] || typeof req.body[field] !== "string" || req.body[field].trim() === "") {
          return res.status(400).json({
            success: false,
            message: `Missing or invalid required field: ${field}`
          });
        }
      }
      for (const key of Object.keys(req.body)) {
        const val = req.body[key];
        if (typeof val === "string") {
          if (!key.endsWith("Doc") && val.length > 2e3) {
            return res.status(400).json({
              success: false,
              message: `Field ${key} exceeds maximum safe length.`
            });
          }
          if (key.endsWith("Doc") && val.length > 25 * 1024 * 1024) {
            return res.status(400).json({
              success: false,
              message: `Document attachment ${key} exceeds maximum allowed size.`
            });
          }
        }
      }
      if (isMySqlConnected) {
        const {
          companyName,
          address1,
          address2,
          country,
          state,
          city,
          pinCode,
          referredBy,
          companyAddressProofDoc,
          hasGst,
          gstNumber,
          gstName,
          gstMobile,
          gstEmail,
          gstCertificateDoc,
          companyPanNumber,
          companyMonthlySalesVolume,
          companyPanHolderName,
          companyPanDoc,
          firstName,
          lastName,
          personalEmail,
          personalMobile,
          personalAddressProofType,
          personalAddressProofDoc,
          personalPanNumber,
          personalMonthlySalesVolume,
          personalPanHolderName,
          personalPanDoc
        } = req.body;
        const [result] = await pool.query(
          `INSERT INTO partners (
            companyName, address1, address2, country, state, city, pinCode, referredBy,
            companyAddressProofDoc, hasGst, gstNumber, gstName, gstMobile, gstEmail, gstCertificateDoc,
            companyPanNumber, companyMonthlySalesVolume, companyPanHolderName, companyPanDoc,
            firstName, lastName, personalEmail, personalMobile, personalAddressProofType, personalAddressProofDoc,
            personalPanNumber, personalMonthlySalesVolume, personalPanHolderName, personalPanDoc
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            companyName,
            address1,
            address2 || null,
            country,
            state,
            city,
            pinCode,
            referredBy || null,
            companyAddressProofDoc ? JSON.stringify(companyAddressProofDoc) : null,
            hasGst,
            gstNumber || null,
            gstName || null,
            gstMobile || null,
            gstEmail || null,
            gstCertificateDoc ? JSON.stringify(gstCertificateDoc) : null,
            companyPanNumber,
            companyMonthlySalesVolume || null,
            companyPanHolderName,
            companyPanDoc ? JSON.stringify(companyPanDoc) : null,
            firstName,
            lastName,
            personalEmail,
            personalMobile,
            personalAddressProofType,
            personalAddressProofDoc ? JSON.stringify(personalAddressProofDoc) : null,
            personalPanNumber,
            personalMonthlySalesVolume || null,
            personalPanHolderName,
            personalPanDoc ? JSON.stringify(personalPanDoc) : null
          ]
        );
        return res.status(201).json({
          success: true,
          message: "Partner registration application successfully connected and saved to MySQL!",
          id: result.insertId
        });
      } else {
        console.log("[Demo Mode Fallback] New Agent Registration:", req.body.companyName);
        return res.status(201).json({
          success: true,
          message: "Saved successfully in high-fidelity Demo Mode! (Configure MySQL to persist directly to your MySQL database)",
          id: `DEMO-${Date.now()}`
        });
      }
    } catch (error) {
      console.error("Error saving agent registration application to database:", error);
      res.status(500).json({
        success: false,
        message: "Database storage error occurred.",
        error: error.message
      });
    }
  });
  const isProd = process.env.NODE_ENV === "production";
  if (!isProd) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom"
    });
    app.use(vite.middlewares);
    app.use("*", async (req, res, next) => {
      const url = req.originalUrl;
      try {
        const templateHtml = fs.readFileSync(path.resolve(__dirname, "index.html"), "utf-8");
        const template = await vite.transformIndexHtml(url, templateHtml);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.resolve(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(__dirname, "dist/index.html"));
    });
  }
  const PORT = Number(process.env.PORT) || 3e3;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}
startServer();
